package kr.aka.nakin.config;

import kr.aka.nakin.aggregate.DailyAggregator;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** YACL 없이 동작하는 윤띵 자체 설정 화면. */
public final class DtConfigScreen extends Screen {
    private static final int BG = 0xE6121010;
    private static final int TEXT = 0xFFF1E5C8;
    private static final int MUTED = 0xFFB5A98F;
    private final DtConfig config;
    private final DailyAggregator aggregator;
    private final Screen parent;
    private final int originalResetHour;
    private Button hudButton, transferButton, vaultButton, transferRowsButton;
    private Button incomeRowsButton, expenseRowsButton, resetHourButton;

    private DtConfigScreen(DtConfig config, DailyAggregator aggregator, Screen parent) {
        super(Component.literal("윤띵 설정"));
        this.config = config;
        this.aggregator = aggregator;
        this.parent = parent;
        this.originalResetHour = config.dayResetHour;
    }

    public static Screen create(DtConfig config, DailyAggregator aggregator, Screen parent) {
        return new DtConfigScreen(config, aggregator, parent);
    }

    @Override protected void init() {
        int w = 280, x = (width - w) / 2, y = Math.max(46, height / 2 - 130);
        hudButton = addRenderableWidget(button(x, y, w, () -> { config.hudEnabled = !config.hudEnabled; refreshLabels(); }));
        incomeRowsButton = addRenderableWidget(button(x, y + 26, w, () -> { config.hudIncomeRows = nextRows(config.hudIncomeRows); refreshLabels(); }));
        expenseRowsButton = addRenderableWidget(button(x, y + 52, w, () -> { config.hudExpenseRows = nextRows(config.hudExpenseRows); refreshLabels(); }));
        transferRowsButton = addRenderableWidget(button(x, y + 78, w, () -> { config.showTransfers = !config.showTransfers; refreshLabels(); }));
        transferButton = addRenderableWidget(button(x, y + 104, w, () -> { config.transferExcludedFromPnl = !config.transferExcludedFromPnl; refreshLabels(); }));
        vaultButton = addRenderableWidget(button(x, y + 130, w, () -> { config.villageVaultAsTransfer = !config.villageVaultAsTransfer; refreshLabels(); }));
        resetHourButton = addRenderableWidget(button(x, y + 156, w, () -> { config.dayResetHour = (config.dayResetHour + 1) % 24; refreshLabels(); }));
        addRenderableWidget(Button.builder(Component.literal("완료"), b -> onClose()).bounds(x + 90, y + 194, 100, 20).build());
        refreshLabels();
    }

    private Button button(int x, int y, int w, Runnable action) {
        return Button.builder(Component.empty(), b -> action.run()).bounds(x, y, w, 20).build();
    }
    private static int nextRows(int v) { if (v == 0) return 1; if (v >= 1 && v < 10) return v + 1; if (v == 10) return -1; return 0; }
    private static String rowsText(int v) { return v < 0 ? "전체" : v == 0 ? "숨김" : v + "개"; }
    private static String onOff(boolean v) { return v ? "켜짐" : "꺼짐"; }
    private void refreshLabels() {
        hudButton.setMessage(Component.literal("영수증 HUD: " + onOff(config.hudEnabled)));
        incomeRowsButton.setMessage(Component.literal("수입 분야 표시: " + rowsText(config.hudIncomeRows)));
        expenseRowsButton.setMessage(Component.literal("지출 분야 표시: " + rowsText(config.hudExpenseRows)));
        transferRowsButton.setMessage(Component.literal("이체 내역 표시: " + onOff(config.showTransfers)));
        transferButton.setMessage(Component.literal("이체를 손익에서 제외: " + onOff(config.transferExcludedFromPnl)));
        vaultButton.setMessage(Component.literal("마을 금고를 이체로 분류: " + onOff(config.villageVaultAsTransfer)));
        resetHourButton.setMessage(Component.literal("하루 기준 시각: " + config.dayResetHour + "시"));
    }

    @Override public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, BG);
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        String title = "윤띵 설정";
        ctx.text(font, title, (width - font.width(title)) / 2, 20, TEXT, false);
        String hint = "버튼을 눌러 값을 변경하세요 · YACL 없이 동작합니다";
        ctx.text(font, hint, (width - font.width(hint)) / 2, 33, MUTED, false);
    }

    @Override public void onClose() {
        config.save();
        if (aggregator != null && originalResetHour != config.dayResetHour) aggregator.rebuild();
        if (minecraft != null) minecraft.gui.setScreen(parent);
    }
}

package kr.aka.nakin.config;

import kr.aka.nakin.aggregate.DailyAggregator;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;

/** 네 영역을 제공하는 YACL 없는 윤띵 설정 화면. */
public final class DtConfigScreen extends Screen {
    private static final int BG = 0xE6121010, TEXT = 0xFFF1E5C8, MUTED = 0xFFB5A98F;
    private final Screen parent;
    private final LedgerSettings settings;
    private final List<Button> pageButtons = new ArrayList<>(), entryButtons = new ArrayList<>();
    private int page;

    private DtConfigScreen(DtConfig config, DailyAggregator aggregator, Screen parent) {
        super(Component.literal("윤띵 설정"));
        this.parent = parent;
        this.settings = new LedgerSettings(config, aggregator);
    }

    public static Screen create(DtConfig config, DailyAggregator aggregator, Screen parent) {
        return new DtConfigScreen(config, aggregator, parent);
    }

    @Override protected void init() {
        pageButtons.clear(); entryButtons.clear();
        int totalW = Math.min(520, width - 24), tabW = totalW / LedgerSettings.PAGES.size();
        int x = (width - totalW) / 2;
        for (int i = 0; i < LedgerSettings.PAGES.size(); i++) {
            final int target = i;
            Button b = addRenderableWidget(Button.builder(Component.literal(LedgerSettings.PAGES.get(i)), it -> {
                page = target;
                rebuildWidgets();
            }).bounds(x + i * tabW, 42, tabW - 3, 20).build());
            pageButtons.add(b);
        }
        buildEntries();
        addRenderableWidget(Button.builder(Component.literal("완료"), b -> onClose())
                .bounds((width - 100) / 2, Math.min(height - 30, 224), 100, 20).build());
        refreshLabels();
    }

    private void buildEntries() {
        int w = Math.min(420, width - 30), x = (width - w) / 2, y = 76;
        List<LedgerSettings.Entry> entries = settings.page(page);
        for (int i = 0; i < entries.size(); i++) {
            LedgerSettings.Entry entry = entries.get(i);
            Button b = addRenderableWidget(Button.builder(Component.empty(), it -> {
                entry.next();
                refreshLabels();
            }).bounds(x, y + i * 27, w, 21).build());
            entryButtons.add(b);
        }
    }

    private void refreshLabels() {
        for (int i = 0; i < pageButtons.size(); i++)
            pageButtons.get(i).setMessage(Component.literal((i == page ? "▶ " : "") + LedgerSettings.PAGES.get(i)));
        List<LedgerSettings.Entry> entries = settings.page(page);
        for (int i = 0; i < entryButtons.size() && i < entries.size(); i++) {
            LedgerSettings.Entry e = entries.get(i);
            entryButtons.get(i).setMessage(Component.literal(e.label + ": " + e.value()));
        }
    }

    @Override public void extractRenderState(GuiGraphicsExtractor ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, BG);
        super.extractRenderState(ctx, mouseX, mouseY, delta);
        String title = "윤띵 설정 · " + LedgerSettings.PAGES.get(page);
        ctx.text(font, title, (width - font.width(title)) / 2, 18, TEXT, false);
        String hint = "버튼을 눌러 값을 변경합니다 · 설정은 즉시 저장됩니다";
        ctx.text(font, hint, (width - font.width(hint)) / 2, 30, MUTED, false);
        List<LedgerSettings.Entry> entries = settings.page(page);
        for (int i = 0; i < entries.size(); i++) {
            if (mouseY >= 76 + i * 27 && mouseY < 97 + i * 27) {
                String desc = entries.get(i).error() == null ? entries.get(i).description : entries.get(i).error();
                ctx.text(font, desc, (width - font.width(desc)) / 2, Math.min(height - 43, 207), MUTED, false);
            }
        }
    }

    @Override public void onClose() {
        if (minecraft != null) minecraft.gui.setScreen(parent);
    }
}

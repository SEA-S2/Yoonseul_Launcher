package kr.aka.nakin.core;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class GirinParsersTest {
    @Test void parsesKnownShapesWithoutEnablingTracking() {
        assertEquals(12345L, QuestRewardTracker.parseReward("보상: 12,345 쿠키"));
        assertTrue(QuestRewardTracker.parseProgressDone("진행도: 5 / 5"));
        assertEquals(9000L, SkillCostLore.parseCost("소모 재화: 9,000 쿠키"));
        assertEquals(500L, RepairCostLore.parseRepairCost("수리 소모 쿠키: 500 쿠키"));
        assertEquals(3, SeaBlessingTracker.parseLevel("파도 (+3)"));
    }
    @Test void classifiesSales() {
        assertEquals("재배전문가", SaleCategory.of("토마토", ""));
        assertEquals("해양전문가", SaleCategory.of("진주", ""));
    }
}

package kr.aka.nakin.aggregate;

import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class HudCategoriesTest {
    @Test void ranksAndLimits() {
        var rows = HudCategories.ranked(Map.of("농사", 10L, "낚시", 30L, "없음", 0L), 1);
        assertEquals(1, rows.size()); assertEquals("낚시", rows.getFirst().getKey());
    }
    @Test void supportsAllAndHidden() {
        assertEquals(2, HudCategories.ranked(Map.of("a", 1L, "b", 2L), -1).size());
        assertTrue(HudCategories.ranked(Map.of("a", 1L), 0).isEmpty());
    }
}

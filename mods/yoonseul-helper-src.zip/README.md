# 윤슬 장부 0.2.0

낙인(Nakin) 0.1.2 MIT 공개 소스를 기반으로 Minecraft Java 26.2에 맞게 포팅한 윤슬 서버용 클라이언트 장부 모드입니다.

## 현재 동작하는 기능

- `/낙인` 정산 창과 HUD
- 수동 수입·지출 기록
- 오늘·주간·기간별 통계와 카테고리 보기
- 내역 수정·삭제
- 정산문 복사
- CSV/XLSX 내보내기
- 활동 로그와 진단 기반

서버 재화 단위와 알림 문구가 확정되지 않았으므로 `automaticCurrencyTracking`의 기본값은 `false`입니다. 따라서 채팅·잔고·GUI 비용의 자동 해석은 아직 실행되지 않습니다.

## 빌드

Java 25에서 `gradlew.bat :fabric:build`(Windows) 또는 `./gradlew :fabric:build`를 실행합니다. 결과 JAR은 `fabric/build/libs/yoonseul-ledger-fabric-0.2.0.jar`입니다.

## 서버 공개 후 할 일

1. 재화 단위와 잔고 표시 위치를 확인합니다.
2. 수입·지출·강화·상점·보상 문구의 원문 표본을 수집합니다.
3. 파서와 로그 재생 테스트를 윤슬 문구로 바꿉니다.
4. 실제 서버에서 읽기 전용 동작을 검증한 뒤 자동 감지를 켭니다.

## 라이선스와 출처

- 원작: https://github.com/kpar03004-droid/nakin
- 라이선스: MIT (`LICENSE`)
- 원작 변경 내역은 `CHANGELOG.md`, 상세 기능 설명은 `docs/사용_설명서.md`에 보존되어 있습니다.

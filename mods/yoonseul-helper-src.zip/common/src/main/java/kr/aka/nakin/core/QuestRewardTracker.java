package kr.aka.nakin.core;

import java.util.regex.Pattern;

/** 의뢰 GUI에서 보상·진행·수령 여부를 읽는다. 실제 연결은 검증 설정을 켠 경우에만 한다. */
public final class QuestRewardTracker {
    public static final String GUI_SIGNATURE = "의뢰";
    public static final String CLAIMED_MARKER = "이미 완료한 의뢰";
    private static final Pattern REWARD = Pattern.compile("보상\\s*[:：]\\s*([\\d,]+)\\s*(?:쿠키|골드)?");
    private static final Pattern PROGRESS = Pattern.compile("진행도\\s*[:：]\\s*([\\d,]+)\\s*/\\s*([\\d,]+)");
    private QuestRewardTracker() {}
    public static long parseReward(String line) { return number(REWARD, line); }
    public static Boolean parseProgressDone(String line) {
        if (line == null) return null; var m = PROGRESS.matcher(line); if (!m.find()) return null;
        long done = parse(m.group(1)), goal = parse(m.group(2)); return goal > 0 && done >= goal;
    }
    public static boolean isClaimedLine(String line) { return line != null && line.contains(CLAIMED_MARKER); }
    public static String questLabel(String raw) { return raw == null ? "" : raw.replaceAll("§.", "").trim().replaceFirst("^\\[\\s*", "").replaceFirst("\\s*]$", "").trim().replaceAll("\\s+", " "); }
    private static long number(Pattern p, String line) { if (line == null) return 0; var m = p.matcher(line); return m.find() ? parse(m.group(1)) : 0; }
    private static long parse(String s) { try { return Long.parseLong(s.replace(",", "")); } catch (Exception e) { return 0; } }
}

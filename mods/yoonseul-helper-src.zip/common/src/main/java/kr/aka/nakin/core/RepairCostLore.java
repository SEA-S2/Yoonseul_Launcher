package kr.aka.nakin.core;

import java.util.regex.Pattern;

/** 기린월드 GUI 문구 검증 뒤 연결할 수리·회복·강화·각인 비용 파서. */
public final class RepairCostLore {
    private RepairCostLore() {}
    private static final Pattern REPAIR = Pattern.compile("수리\\s*소모\\s*(?:쿠키|재화)\\s*[:：]\\s*([\\d,]+)");
    private static final Pattern RESTORE = Pattern.compile("회복\\s*비용\\s*[:：]\\s*([\\d,]+)");
    private static final Pattern ENHANCE = Pattern.compile("강화\\s*비용\\s*[:：]\\s*([\\d,]+)");
    private static final Pattern ENGRAVE = Pattern.compile("각인\\s*비용\\s*[:：]\\s*([\\d,]+)");
    public static Long parseRepairCost(String s) { return first(REPAIR, s); }
    public static Long parseRestoreCost(String s) { return first(RESTORE, s); }
    public static Long parseEnhanceCost(String s) { return first(ENHANCE, s); }
    public static Long parseEngraveCost(String s) { return first(ENGRAVE, s); }
    private static Long first(Pattern p, String s) {
        if (s == null) return null;
        var m = p.matcher(s);
        if (!m.find()) return null;
        try { return Long.parseLong(m.group(1).replace(",", "")); } catch (NumberFormatException e) { return null; }
    }
}

package kr.aka.nakin.core;

import java.util.regex.Pattern;

/** 스킬 GUI 설명의 비용과 이름을 안전하게 읽는 순수 파서. */
public final class SkillCostLore {
    public static final String SIGNATURE = "소모 스킬 포인트";
    private static final Pattern COST = Pattern.compile("소모\\s*재화\\s*[:：]\\s*([\\d,]+)\\s*(?:쿠키|골드)?");
    private SkillCostLore() {}
    public static Long parseCost(String line) {
        if (line == null) return null;
        var m = COST.matcher(line); if (!m.find()) return null;
        try { return Long.parseLong(m.group(1).replace(",", "")); } catch (NumberFormatException e) { return null; }
    }
    public static boolean isSignature(String line) { return line != null && line.contains(SIGNATURE); }
    public static String skillName(String raw) {
        if (raw == null) return "";
        return raw.replaceAll("§.", "").replaceFirst("^\\s*\\[[^]]*]\\s*", "")
                .replaceFirst("\\s*\\([^)]*\\)\\s*$", "").replaceFirst("^[^\\p{IsHangul}A-Za-z0-9]+", "").trim().replaceAll("\\s+", " ");
    }
    public static boolean matchesLabel(String skill, String label) { return skill != null && !skill.isBlank() && label != null && label.startsWith(skill); }
}

package kr.aka.nakin.core;

import java.util.function.LongConsumer;

/** 플리마켓 금고의 추적 잔액과 서버 실측 잔액을 동기화한다. */
public final class VaultTracker {
    public static final long DEFAULT_LIMIT = 20_000_000L;
    public static final String NOTE_VAULT_SYNC = "금고 실측 잔액과의 차액 자동 보정";
    private final long limit; private final LongConsumer persist; private long balance; private String warning;
    public VaultTracker(long initial, long limit, LongConsumer persist) {
        this.limit = limit > 0 ? limit : DEFAULT_LIMIT; this.balance = initial < 0 ? -1 : Math.min(initial, this.limit); this.persist = persist;
    }
    public boolean isSet() { return balance >= 0; }
    public long balance() { return Math.max(balance, 0); }
    public long limit() { return limit; }
    public double fillRatio() { return isSet() ? (double) balance() / limit : 0; }
    public String warning() { return warning; }
    public void set(long value) { balance = Math.max(0, Math.min(value, limit)); warning = null; persist.accept(balance); }
    public long syncFromServer(long actual) { boolean set = isSet(); long old = balance(); set(actual); return set ? balance() - old : 0; }
    public static TransactionRecord missedRecord(long diff, long ts) {
        boolean income = diff > 0;
        return new TransactionRecord(ts, income ? TransactionRecord.Kind.INCOME : TransactionRecord.Kind.EXPENSE,
                Math.abs(diff), "플리마켓", income ? "잠수 중 판매(금고 보정)" : "잠수 중 구매(금고 보정)", 0, true,
                TransactionRecord.Confidence.MEDIUM, false, NOTE_VAULT_SYNC);
    }
    public void onRecord(TransactionRecord r) {
        if (!isSet()) return; long delta = deltaOf(r); if (delta == 0) return;
        long next = balance + delta;
        if (next < 0) { next = 0; warning = "계산상 잔액이 음수 — 재동기화 필요"; }
        else if (next > limit) { next = limit; warning = "계산상 한도 초과 — 재동기화 필요"; }
        balance = next; persist.accept(balance);
    }
    static long deltaOf(TransactionRecord r) {
        if ("플리마켓 판매".equals(r.category)) return r.amount;
        if ("플리마켓 구매".equals(r.category)) return -r.amount;
        if ("플리마켓 금고".equals(r.category)) return r.kind == TransactionRecord.Kind.TRANSFER_OUT ? r.amount : -r.amount;
        return 0;
    }
}

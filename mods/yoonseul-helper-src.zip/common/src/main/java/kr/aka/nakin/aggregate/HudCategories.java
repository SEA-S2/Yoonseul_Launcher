package kr.aka.nakin.aggregate;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** HUD 카테고리를 금액순으로 정렬하고 표시 개수를 적용한다. */
public final class HudCategories {
    private HudCategories() {}

    public static List<Map.Entry<String, Long>> ranked(Map<String, Long> amounts, int limit) {
        long count = limit == -1 ? amounts.size() : Math.max(0, limit);
        return amounts.entrySet().stream()
                .filter(e -> e.getValue() > 0)
                .sorted(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
                        .thenComparing(Map.Entry.comparingByKey()))
                .limit(count)
                .toList();
    }
}

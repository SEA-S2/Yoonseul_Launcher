package kr.aka.nakin.core;

/** 플리마켓 품목명을 직업/활동별 수입 분야로 분류한다. */
public final class SaleCategory {
    private SaleCategory() {}
    private static final String[] MINING = {"광석","주괴","정동석","보석","원석","드릴","강화석","석유"};
    private static final String[] HUNT = {"가죽","상아","송곳니","깃털","영혼","각인석","사냥"};
    private static final String[] FARM = {"토마토","양파","마늘","감자","당근","옥수수","밀","딸기","사과","작물","씨앗","베리"};
    private static final String[] OCEAN = {"굴","소라","문어","미역","성게","조개","전복","산호","해파리","진주","해산"};
    private static final String[] COOK = {"스파게티","케이크","수프","파스타","샌드위치","리조또","튀김","요리","치즈","밀가루","버터"};
    private static final String[] CAFE = {"커피","모카","아메리카노","라떼","카푸치노","프라페","브루","에스프레소","원두"};
    private static final String[] ALCHEMY = {"엘릭서","영약","에센스","정수","연금","비약"};
    public static String of(String label, String context) {
        String s = (label == null ? "" : label) + " " + (context == null ? "" : context);
        if (s.contains("무역")) return "무역";
        if (any(s, ALCHEMY)) return "연금";
        if (any(s, CAFE)) return "바리스타";
        if (any(s, MINING)) return "채광전문가";
        if (any(s, HUNT)) return "사냥전문가";
        if (any(s, COOK)) return "요리";
        if (any(s, OCEAN) || s.contains("★")) return "해양전문가";
        if (any(s, FARM)) return "재배전문가";
        return "판매";
    }
    private static boolean any(String s, String[] keys) { for (String k : keys) if (s.contains(k)) return true; return false; }
}

package kr.aka.nakin.core;

import java.util.regex.Pattern;

/** 바다의 가호 GUI 비용/능력 이름 파서. 서버 확인 전에는 설정상 비활성이다. */
public final class SeaBlessingTracker {
    public static final String GUI_SIGNATURE = "낚시 능력치";
    private static final Pattern COST = Pattern.compile("소모\\s*재화\\s*[:：]\\s*([\\d,]+)\\s*(?:쿠키|골드)?");
    private static final Pattern LEVEL = Pattern.compile("\\(\\s*\\+\\s*(\\d+)\\s*\\)\\s*$");
    private SeaBlessingTracker() {}
    public static long parseCost(String line) { if (line == null) return 0; var m = COST.matcher(line); if (!m.find()) return 0; try { return Long.parseLong(m.group(1).replace(",", "")); } catch (Exception e) { return 0; } }
    public static String abilityLabel(String raw) { return raw == null ? "" : raw.replaceAll("§.", "").trim().replaceFirst("^\\[[^]]*]\\s*", "").replaceFirst("\\s*\\(\\s*[+-]?\\d+\\s*\\)\\s*$", "").trim(); }
    public static int parseLevel(String raw) { if (raw == null) return -1; var m = LEVEL.matcher(raw.replaceAll("§.", "").trim()); try { return m.find() ? Integer.parseInt(m.group(1)) : -1; } catch (Exception e) { return -1; } }
}

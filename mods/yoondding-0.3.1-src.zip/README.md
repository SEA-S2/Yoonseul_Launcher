# 윤띵 0.3.1

Minecraft 26.2 / Fabric / Java 25.

This release adds four selectable receipt themes (rabbit, bear, cat, giraffe)
alongside the original theme, and conditional transfer totals in daily/weekly
clipboard summaries. Theme selection is persisted independently in
`config/yoondding/appearance.properties`; existing `classic` and `rabbit`
settings remain compatible.

Run `python build.py` with `JAVA_HOME` pointing to Java 25. It downloads the
pinned Minecraft libraries/Fabric API, compiles the changed sources, runs the
headless appearance/share checks, assembles the final JAR, and repeats the
checks using that distributable. Output is in `build/`.

The published 0.3.0 JAR is retained in `baseline/` with a SHA-256 check. It keeps
existing parser, storage, export, config migration and runtime behavior intact;
only the provided GUI classes and `aggregate.ShareText` are replaced. Baseline
upstream release: https://github.com/SEA-S2/Yoonseul_Launcher/releases/tag/yoondding-v0.3.0

The tests use actual Minecraft classes and a recording drawing target; they do
not launch a window. They cover all five design choices, persistence/cycling,
all ledger tabs, large monetary amounts, HUD scaling/bounds, conditional transfer
copy blocks, and unchanged profit calculations. The user tested all mascot
designs, persistence across game restarts, and transfer copies in game before
release. Actual server transaction wording remains subject to OBT validation.

Mascots were generated for this project using the approved cute pixel receipt
art direction: warm brown stepped outlines, pastel coloring, front-facing
peeking bear/cat/giraffe/bunny faces and two little paws. UI widget textures and
stretchable borders are code-authored assets, bundled at game resolution.

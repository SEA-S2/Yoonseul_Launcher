package kr.aka.nakin.ui;

import java.nio.file.*;
import java.util.*;
import kr.aka.nakin.config.DtConfig;
import kr.aka.nakin.aggregate.DailyAggregator;
import kr.aka.nakin.store.LedgerStore;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2fStack;

/** Runs the compiled HUD against the real Minecraft API with a recording draw target. */
public final class ReceiptDesignsCheck {
    static class TestFont extends Font {
        TestFont() { super(null); }
        @Override public int width(String s) {
            return s.codePoints().map(c -> c > 127 ? 9 : 6).sum();
        }
        @Override public String plainSubstrByWidth(String s,int w) { return s.substring(0,Math.min(s.length(),Math.max(0,w/9))); }
    }
    static class Draw extends GuiGraphicsExtractor {
        Draw() { super(null,null,0,0); }
        List<String> sprites;
        List<int[]> texts;
        Matrix3x2fStack matrix;
        @Override public Matrix3x2fStack pose() { return matrix; }
        @Override public void blitSprite(RenderPipeline p,Identifier id,int x,int y,int w,int h) {
            blitSprite(p,id,x,y,w,h,0xFFFFFFFF);
        }
        @Override public void blitSprite(RenderPipeline p,Identifier id,int x,int y,int w,int h,int argb) {
            sprites.add(id.getPath());
            if(w<=0 || h<=0) throw new AssertionError("Nonpositive sprite size");
        }
        @Override public void text(Font f,String s,int x,int y,int color,boolean shadow) {
            texts.add(new int[]{x,y,f.width(s)});
        }
        @Override public void text(Font f,net.minecraft.network.chat.Component s,int x,int y,int color,boolean shadow) {
            text(f,s.getString(),x,y,color,shadow);
        }
        @Override public void enableScissor(int a,int b,int c,int d) {}
        @Override public void disableScissor() {}
        @Override public void fill(int x,int y,int right,int bottom,int color) {}
    }
    static void check(boolean b,String message) { if(!b)throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        var ufield=sun.misc.Unsafe.class.getDeclaredField("theUnsafe");ufield.setAccessible(true);
        var unsafe=(sun.misc.Unsafe)ufield.get(null);
        Draw draw=(Draw)unsafe.allocateInstance(Draw.class);
        draw.sprites=new ArrayList<>();draw.texts=new ArrayList<>();draw.matrix=new Matrix3x2fStack(16);
        Path dir=Files.createTempDirectory("yoondding-appearance-check-");
        Path settings=dir.resolve("config/yoondding/appearance.properties");
        ReceiptTheme.load(settings);check(ReceiptTheme.decorated(),"test default is rabbit");
        check(ReceiptTheme.save(settings),"save rabbit");ReceiptTheme.load(settings);
        check(ReceiptTheme.decorated(),"reload rabbit");
        Files.writeString(settings,"receiptTheme=classic\n");ReceiptTheme.load(settings);
        check(!ReceiptTheme.decorated(),"reload classic");
        check(ReceiptTheme.save(settings),"save classic");ReceiptTheme.load(settings);
        check(!ReceiptTheme.decorated(),"classic persisted");

        DtConfig cfg=new DtConfig();cfg.hudOpacity=0.6f;
        var agg=new DailyAggregator(cfg,new LedgerStore(dir.resolve("ledger")));
        var b=agg.today();b.income=15904;b.expense=86000;
        b.incomeByCategory.put("플리마켓",15904L);b.expenseByCategory.put("거래소",40000L);
        var hud=new LedgerHud(cfg,agg);Font font=new TestFont();
        for(String theme:new String[]{"classic","rabbit","bear","cat","giraffe"}) {
            Files.writeString(settings,"receiptTheme="+theme+"\n");ReceiptTheme.load(settings);
            for(long amount:new long[]{0,15904,999999999999L}) {
                b.income=amount;draw.sprites.clear();draw.texts.clear();
                int[] measure=hud.measure(font);int[] actual=hud.draw(draw,font,0,0);
                check(Arrays.equals(measure,actual),"measure/draw agree");
                check(draw.sprites.contains(theme.equals("classic")?"panel_light":theme+"_panel_light"),"correct panel");
                check(draw.sprites.contains(theme+"_mascot")==!theme.equals("classic"),"mascot follows theme");
                for(int[] t:draw.texts) {
                    check(t[0]>=0 && t[1]>=0 && t[0]+t[2]<=measure[0] && t[1]+font.lineHeight<=measure[1],"text inside HUD");
                }
                for(float scale:new float[]{0.5f,1f,1.5f,2f}) {
                    cfg.hudScale=scale;
                    check(Arrays.equals(hud.measureScaled(font),hud.drawScaledHud(draw,font,0,0)),"scaled hitbox agrees");
                }
            }
        }
        // Exercise the real settings widget callback and persist its selected appearance.
        var mc=(net.minecraft.client.Minecraft)unsafe.allocateInstance(net.minecraft.client.Minecraft.class);
        var mcClass=net.minecraft.client.Minecraft.class;
        unsafe.putObject(mc,unsafe.objectFieldOffset(mcClass.getDeclaredField("font")),font);
        unsafe.putObject(mc,unsafe.objectFieldOffset(mcClass.getDeclaredField("gameDirectory")),dir.toFile());
        var instance=mcClass.getDeclaredField("instance");instance.setAccessible(true);instance.set(null,mc);
        cfg.lastSeenWhatsNew="0.1.2";
        var screen=new DtStatScreen(cfg,agg,r->{},hud);screen.width=480;screen.height=320;
        var init=DtStatScreen.class.getDeclaredMethod("init");init.setAccessible(true);init.invoke(screen);
        var switchTab=DtStatScreen.class.getDeclaredMethod("switchTab",int.class);switchTab.setAccessible(true);
        var themeField=DtStatScreen.class.getDeclaredField("sTheme");themeField.setAccessible(true);
        TexButton button=(TexButton)themeField.get(screen);
        for(int tab=0;tab<5;tab++) {
            switchTab.invoke(screen,tab);check(button.visible==(tab==4),"theme button only in settings");
            draw.sprites.clear();draw.texts.clear();screen.extractBackground(draw,0,0,0);
        }
        var seen=new java.util.HashSet<String>();
        for(int i=0;i<5;i++) {
            String before=ReceiptTheme.current();seen.add(before);button.onPress(null);
            String after=ReceiptTheme.current();check(!after.equals(before),"settings callback switches theme");
            check(Files.readString(settings).contains(after),"settings callback saves choice");
            ReceiptTheme.load(settings);check(ReceiptTheme.current().equals(after),"choice survives reload");
            for(int tab=0;tab<5;tab++) {
                switchTab.invoke(screen,tab);draw.sprites.clear();draw.texts.clear();
                screen.extractBackground(draw,0,0,0);
                if(!after.equals("classic"))check(draw.sprites.contains(after+"_tex_page"),"large panel follows theme");
            }
        }
        check(seen.size()==5,"all five designs selectable");
        Files.writeString(settings,"receiptTheme=unknown\n");ReceiptTheme.load(settings);
        check(ReceiptTheme.current().equals("rabbit"),"unknown theme falls back safely");

        var day=new kr.aka.nakin.aggregate.DailyBucket(java.time.LocalDate.of(2026,11,21));
        String zero=kr.aka.nakin.aggregate.ShareText.day(day);
        check(!zero.contains("이체"),"no transfer lines on day without transfers");
        day.transferIn=145500;day.transferOut=1740000;
        String text=kr.aka.nakin.aggregate.ShareText.day(day);
        check(text.contains("이체 들어옴 +145,500 쿠키"),"incoming amount in copy");
        check(text.contains("이체 나감 −1,740,000 쿠키"),"outgoing amount in copy");
        check(text.contains("※ 이체는 순익에서 제외됩니다."),"pnl explanation");
        check(text.contains("순익 +0 쿠키  (수입 0 / 지출 0)"),"transfer does not change profit");
        day.transferIn=0;check(kr.aka.nakin.aggregate.ShareText.day(day).contains("이체 들어옴 +0 쿠키"),"both rows for one-sided transfer");
        var other=new kr.aka.nakin.aggregate.DailyBucket(java.time.LocalDate.of(2026,11,20));
        other.transferIn=200;other.transferOut=500;
        String week=kr.aka.nakin.aggregate.ShareText.week(List.of(day,other));
        check(week.contains("이체 들어옴 +200 쿠키") && week.contains("이체 나감 −1,740,500 쿠키"),"weekly transfer sums");
        check(!kr.aka.nakin.aggregate.ShareText.week(List.of(new kr.aka.nakin.aggregate.DailyBucket(day.date))).contains("이체"),"no weekly zero-transfer block");
        day.income=1000;day.expense=200;
        check(kr.aka.nakin.aggregate.ShareText.day(day).contains("순익 +800 쿠키"),"normal profit unchanged");
        System.out.println("PASS: all 5 design save/reload/cycle callbacks, every large ledger tab, legacy/unknown theme compatibility.");
        System.out.println("PASS: conditional daily/weekly transfer copy, both directions and one-sided records, amounts, exclusion note, unchanged profit.");
        System.out.println("PASS: appearance save/reload, classic/rabbit sprite selection, empty/normal/large amounts, HUD bounds, opacity and scaled hitboxes.");
        System.out.println("PASS: all five ledger tabs draw, theme button visibility and actual click callback, persisted selected theme.");
    }
}

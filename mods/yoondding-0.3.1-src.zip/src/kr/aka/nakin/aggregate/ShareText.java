package kr.aka.nakin.aggregate;

import kr.aka.nakin.util.GoldFormat;

import java.util.List;
import java.util.Map;

/** 정산 결과를 디스코드 등에 붙일 평문으로 — 오늘/주간 탭에서 Ctrl+C·복사 버튼. 클립보드로만 나간다. */
public final class ShareText {
    private ShareText() {}

    public static String day(DailyBucket b) {
        StringBuilder sb = new StringBuilder("📒 윤띵 · ").append(b.date).append('\n');
        sb.append("순익 ").append(GoldFormat.signed(b.netPnl())).append(" 쿠키  (")
                .append("수입 ").append(GoldFormat.format(b.income))
                .append(" / 지출 ").append(GoldFormat.format(b.expense)).append(")\n");
        top(sb, "수입", b.incomeByCategory);
        top(sb, "지출", b.expenseByCategory);
        transfers(sb, b.transferIn, b.transferOut);
        return sb.toString().stripTrailing();
    }

    /** @param days 최신이 앞(DailyAggregator.lastDays 순서) */
    public static String week(List<DailyBucket> days) {
        StringBuilder sb = new StringBuilder("📒 윤띵 · 최근 ").append(days.size()).append("일\n");
        long in = 0, out = 0, transferIn = 0, transferOut = 0;
        for (DailyBucket d : days) {
            in += d.income;
            out += d.expense;
            transferIn += d.transferIn;
            transferOut += d.transferOut;
            sb.append(d.date.getMonthValue()).append('/').append(d.date.getDayOfMonth()).append("  ")
                    .append(GoldFormat.signed(d.netPnl())).append('\n');
        }
        sb.append("합계 ").append(GoldFormat.signed(in - out)).append(" 쿠키  (수입 ")
                .append(GoldFormat.format(in)).append(" / 지출 ").append(GoldFormat.format(out)).append(')');
        transfers(sb, transferIn, transferOut);
        return sb.toString().stripTrailing();
    }

    private static void transfers(StringBuilder sb, long in, long out) {
        if (in <= 0 && out <= 0) return;
        if (!sb.isEmpty() && sb.charAt(sb.length() - 1) != '\n') sb.append('\n');
        sb.append('\n').append("이체 들어옴 +").append(GoldFormat.format(in)).append(" 쿠키\n")
                .append("이체 나감 −").append(GoldFormat.format(out)).append(" 쿠키\n")
                .append("※ 이체는 순익에서 제외됩니다.\n");
    }

    private static void top(StringBuilder sb, String title, Map<String, Long> m) {
        if (m.isEmpty()) return;
        sb.append(title).append(" 상위: ");
        m.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue(), a.getValue()))
                .limit(3)
                .forEach(e -> sb.append(e.getKey()).append(' ').append(GoldFormat.format(e.getValue())).append(" · "));
        sb.setLength(sb.length() - 3);
        sb.append('\n');
    }
}

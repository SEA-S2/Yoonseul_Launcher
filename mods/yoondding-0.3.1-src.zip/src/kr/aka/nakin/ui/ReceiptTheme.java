package kr.aka.nakin.ui;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import net.minecraft.client.Minecraft;

/** Appearance is separate from ledger data and can be switched without restarting. */
public final class ReceiptTheme {
    private ReceiptTheme() {}
    private static final String[] IDS = {"classic", "rabbit", "bear", "cat", "giraffe"};
    private static final String[] NAMES = {"기본", "토끼", "곰", "고양이", "기린"};
    private static int selected = -1;
    private static boolean saveFailed;

    static Path settingsPath() {
        return Minecraft.getInstance().gameDirectory.toPath()
                .resolve("config/yoondding/appearance.properties");
    }

    public static String current() {
        if (selected < 0) load(settingsPath());
        return IDS[selected];
    }

    public static boolean decorated() { return !current().equals("classic"); }

    public static String prefix() { return current() + "_"; }

    static void load(Path path) {
        Properties p = new Properties();
        if (Files.isRegularFile(path)) {
            try (Reader r = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { p.load(r); }
            catch (IOException e) { System.err.println("[윤띵] 디자인 설정 읽기 실패: " + e); }
        }
        String requested = p.getProperty("receiptTheme", "rabbit");
        selected = 1;
        for (int i = 0; i < IDS.length; i++) {
            if (IDS[i].equals(requested)) { selected = i; break; }
        }
    }

    public static void toggle() {
        current();
        selected = (selected + 1) % IDS.length;
        saveFailed = !save(settingsPath());
        GuiTex.refreshTheme();
    }

    static boolean save(Path path) {
        try {
            Files.createDirectories(path.getParent());
            Path tmp = Files.createTempFile(path.getParent(), "appearance-", ".tmp");
            try {
                Properties p = new Properties();
                p.setProperty("receiptTheme", current());
                try (Writer w = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
                    p.store(w, "Yoondding receipt appearance");
                }
                try { Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (java.nio.file.AtomicMoveNotSupportedException e) {
                    Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally { Files.deleteIfExists(tmp); }
            return true;
        } catch (IOException e) {
            System.err.println("[윤띵] 디자인 설정 저장 실패: " + e);
            return false;
        }
    }

    public static String label() {
        current();
        return "영수증 디자인: " + NAMES[selected] + "  [변경]";
    }

    public static String status() {
        return saveFailed ? "설정 저장 실패 · 폴더 쓰기 권한을 확인해 주세요." : "작은 HUD와 큰 장부에 함께 적용됩니다.";
    }
}

package kr.girinworld.core.features.timer;

import kr.girinworld.core.Config;

public final class Timer {
   private static final long BLINK_PERIOD = 250000000L;
   private static final long SOUND_REPEAT = 1000000000L;
   private final boolean countdown;
   private final long duration;
   private String name;
   private int color;
   private Timer.State state = Timer.State.RUNNING;
   private long endNanos;
   private long remainingAtPause;
   private long startNanos;
   private long elapsedAtPause;
   private long finishedAtNanos;
   private long lastSoundNanos;

   public Timer(boolean countdown, long durationNanos, String name, int color) {
      this.countdown = countdown;
      this.duration = durationNanos;
      this.name = name == null ? "" : name;
      this.color = color;
      long now = System.nanoTime();
      if (countdown) {
         this.endNanos = now + durationNanos;
      } else {
         this.startNanos = now;
      }
   }

   public synchronized void pause() {
      if (this.state == Timer.State.RUNNING) {
         long now = System.nanoTime();
         if (this.countdown) {
            this.remainingAtPause = Math.max(0L, this.endNanos - now);
         } else {
            this.elapsedAtPause = now - this.startNanos;
         }

         this.state = Timer.State.PAUSED;
      }
   }

   public synchronized void resume() {
      if (this.state == Timer.State.PAUSED) {
         long now = System.nanoTime();
         if (this.countdown) {
            this.endNanos = now + this.remainingAtPause;
         } else {
            this.startNanos = now - this.elapsedAtPause;
         }

         this.state = Timer.State.RUNNING;
      }
   }

   public synchronized void resetToFullPaused() {
      if (this.countdown) {
         this.remainingAtPause = this.duration;
      } else {
         this.elapsedAtPause = 0L;
      }

      this.state = Timer.State.PAUSED;
   }

   public synchronized void togglePause() {
      if (this.state == Timer.State.RUNNING) {
         this.pause();
      } else if (this.state == Timer.State.PAUSED) {
         this.resume();
      }
   }

   synchronized boolean update(long now) {
      if (this.state == Timer.State.RUNNING && this.countdown && now >= this.endNanos) {
         this.state = Timer.State.FINISHED;
         this.finishedAtNanos = now;
         this.lastSoundNanos = now;
         TimerSound.playFinish();
      } else if (this.state == Timer.State.FINISHED) {
         if (now - this.finishedAtNanos > alarmNanos()) {
            return true;
         }

         if (now - this.lastSoundNanos >= 1000000000L) {
            this.lastSoundNanos = now;
            TimerSound.playFinish();
         }
      }

      return false;
   }

   public synchronized Timer.State state() {
      return this.state;
   }

   public boolean isCountdown() {
      return this.countdown;
   }

   public long durationNanos() {
      return this.duration;
   }

   public synchronized String name() {
      return this.name;
   }

   public synchronized void setName(String n) {
      this.name = n == null ? "" : n;
   }

   public synchronized int color() {
      return this.color;
   }

   public synchronized void setColor(int c) {
      this.color = c;
   }

   public synchronized long displayNanos() {
      long now = System.nanoTime();

      return switch (this.state) {
         case RUNNING -> this.countdown ? Math.max(0L, this.endNanos - now) : now - this.startNanos;
         case PAUSED -> this.countdown ? this.remainingAtPause : this.elapsedAtPause;
         case FINISHED -> 0L;
      };
   }

   private static long alarmNanos() {
      return Math.max(1, Math.min(60, Config.get().timer.alarmSeconds)) * 1000000000L;
   }

   public synchronized boolean blinkHidden() {
      if (this.state != Timer.State.FINISHED) {
         return false;
      }

      long since = System.nanoTime() - this.finishedAtNanos;
      return since > alarmNanos() ? false : since / 250000000L % 2L == 1L;
   }

   public enum State {
      RUNNING,
      PAUSED,
      FINISHED;
   }
}

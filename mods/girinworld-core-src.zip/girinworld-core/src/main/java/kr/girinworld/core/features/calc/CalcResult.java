package kr.girinworld.core.features.calc;

import java.math.BigDecimal;

public final class CalcResult {
   public final boolean ok;
   public final BigDecimal value;
   public final String errorMessage;

   private CalcResult(boolean ok, BigDecimal value, String errorMessage) {
      this.ok = ok;
      this.value = value;
      this.errorMessage = errorMessage;
   }

   public static CalcResult ok(BigDecimal value) {
      return new CalcResult(true, value, null);
   }

   public static CalcResult error(String message) {
      return new CalcResult(false, null, message);
   }

   @Override
   public String toString() {
      return this.ok ? "CalcResult{ok, value=" + this.value + "}" : "CalcResult{error, message=" + this.errorMessage + "}";
   }
}

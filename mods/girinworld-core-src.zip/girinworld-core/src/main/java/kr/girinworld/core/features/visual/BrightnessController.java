package kr.girinworld.core.features.visual;

import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;

public final class BrightnessController {
   private static Double savedGamma;

   private BrightnessController() {
   }

   public static boolean isActive() {
      return Config.get().brightness.enabled;
   }

   public static void setActive(boolean on) {
      if (on != isActive()) {
         toggle();
      }
   }

   public static void toggle() {
      boolean on = !isActive();
      Config.get().brightness.enabled = on;
      Config.get().save();
      boolean shaders = ShaderState.shaderPackInUse();
      CoreLog.info(
         "brightness toggle: active=" + on + " level=" + Config.get().brightness.level + " shaderPack=" + shaders + " iris=" + ShaderState.irisPresent()
      );
      if (on && shaders) {
         applyGamma();
      } else {
         restoreGamma();
      }
   }

   public static float targetBrightness() {
      return (float)(1.0 + Config.get().brightness.level / 100.0);
   }

   private static void applyGamma() {
      try {
         Minecraft mc = Minecraft.getInstance();
         if (mc == null || mc.options == null) {
            return;
         }

         if (savedGamma == null) {
            savedGamma = (Double)mc.options.gamma().get();
         }

         double level = Config.get().brightness.level;
         double t = Math.max(0.0, Math.min(1.0, level / 1000.0));
         mc.options.gamma().set(Math.max(savedGamma, t));
      } catch (Throwable t) {
         CoreLog.error("gamma apply failed", t);
      }
   }

   private static void restoreGamma() {
      try {
         if (savedGamma != null) {
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && mc.options != null) {
               mc.options.gamma().set(savedGamma);
            }

            return;
         }
      } catch (Throwable t) {
         CoreLog.error("gamma restore failed", t);
         return;
      } finally {
         savedGamma = null;
      }
   }
}

package kr.girinworld.core.features.visual;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.CriterionProgress;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

public final class AdvancementDetailScreen extends CoreScreen {
   private static final int ROW_H = 11;
   private static final int COL_GAP = 12;
   private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault());
   private final Screen parent;
   private final DisplayInfo display;
   private final List<Component> left = new ArrayList<>();
   private final List<Component> done = new ArrayList<>();
   private final Instant achievedAt;
   private final List<AdvancementDetailScreen.Row> rows = new ArrayList<>();
   private List<FormattedCharSequence> descLines = List.of();
   private int panelLeft;
   private int panelWidth;
   private int colWidth;
   private int listTop;
   private int listBottom;
   private int scroll;

   AdvancementDetailScreen(Screen parent, DisplayInfo display, AdvancementProgress progress) {
      super(display.getTitle());
      this.parent = parent;
      this.display = display;
      progress.getRemainingCriteria().forEach(kx -> this.left.add(AdvancementDetails.displayName(kx).copy().withStyle(ChatFormatting.WHITE)));
      Instant last = null;

      for (String k : progress.getCompletedCriteria()) {
         this.done.add(Component.literal("✔ ").append(AdvancementDetails.displayName(k)).withStyle(ChatFormatting.DARK_GRAY));
         CriterionProgress c = progress.getCriterion(k);
         Instant t = c == null ? null : c.getObtained();
         if (t != null && (last == null || t.isAfter(last))) {
            last = t;
         }
      }

      this.achievedAt = this.left.isEmpty() ? last : null;
   }

   protected void init() {
      Font f = this.font;
      this.panelWidth = Math.min(this.width - 40, 440);
      this.panelLeft = (this.width - this.panelWidth) / 2;
      this.descLines = f.split(this.display.getDescription(), this.panelWidth);
      this.listTop = 34 + this.descLines.size() * 10 + 6 + 14;
      this.listBottom = this.height - 34;
      int widest = 0;

      for (Component c : this.left) {
         widest = Math.max(widest, f.width(c));
      }

      for (Component c : this.done) {
         widest = Math.max(widest, f.width(c));
      }

      this.colWidth = Math.min(this.panelWidth, widest + 12);
      int cols = Math.max(1, this.panelWidth / this.colWidth);
      this.rows.clear();
      this.addSection(Component.literal("남은 조건 (" + this.left.size() + ")").withStyle(ChatFormatting.YELLOW), this.left, cols);
      this.addSection(Component.literal("완료 (" + this.done.size() + ")").withStyle(ChatFormatting.GREEN), this.done, cols);
      this.scroll = Math.min(this.scroll, this.maxScroll());
      this.addRenderableWidget(Button.builder(Component.literal("뒤로"), b -> this.onClose()).bounds(this.width / 2 - 50, this.height - 26, 100, 20).build());
   }

   private void addSection(Component header, List<Component> names, int cols) {
      if (!names.isEmpty()) {
         if (!this.rows.isEmpty()) {
            this.rows.add(new AdvancementDetailScreen.Row(null, List.of()));
         }

         this.rows.add(new AdvancementDetailScreen.Row(header, List.of()));
         int i = 0;

         while (i < names.size()) {
            this.rows.add(new AdvancementDetailScreen.Row(null, names.subList(i, Math.min(names.size(), i + cols))));
            i += cols;
         }
      }
   }

   private int visibleRows() {
      return Math.max(1, (this.listBottom - this.listTop) / 11);
   }

   private int maxScroll() {
      return Math.max(0, this.rows.size() - this.visibleRows());
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      this.scroll = Math.max(0, Math.min(this.maxScroll(), this.scroll - (int)Math.signum(scrollY) * 3));
      return true;
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      Font f = this.font;
      int y = 20;
      g.centeredText(f, this.display.getTitle().copy().withStyle(ChatFormatting.GOLD), this.width / 2, y, -1);
      y += 14;

      for (FormattedCharSequence line : this.descLines) {
         g.text(f, line, this.panelLeft, y, -5592406);
         y += 10;
      }

      y += 6;
      String status = "조건 "
         + this.done.size()
         + " / "
         + (this.done.size() + this.left.size())
         + (this.achievedAt != null ? "   달성: " + DATE.format(this.achievedAt) : "");
      g.text(f, status, this.panelLeft, y, -1);
      int visible = this.visibleRows();

      for (int i = 0; i < visible && this.scroll + i < this.rows.size(); i++) {
         AdvancementDetailScreen.Row r = this.rows.get(this.scroll + i);
         int ry = this.listTop + i * 11;
         if (r.header() != null) {
            g.text(f, r.header(), this.panelLeft, ry, -1);
         }

         for (int c = 0; c < r.cells().size(); c++) {
            g.text(f, r.cells().get(c), this.panelLeft + c * this.colWidth, ry, -1);
         }
      }

      if (this.maxScroll() > 0) {
         int trackH = this.listBottom - this.listTop;
         int barH = Math.max(10, trackH * visible / this.rows.size());
         int barY = this.listTop + (trackH - barH) * this.scroll / this.maxScroll();
         int x = this.panelLeft + this.panelWidth + 6;
         g.fill(x, this.listTop, x + 2, this.listBottom, 1090519039);
         g.fill(x, barY, x + 2, barY + barH, -1056964609);
      }
   }

   public void onClose() {
      AdvancementDetails.back(this.parent);
   }

   private record Row(Component header, List<Component> cells) {
   }
}

package kr.girinworld.core.features.settings;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

final class Opt {
   static final int[] PALETTE = new int[]{-1, -4473925, -16777216, -43691, -22016, -171, -11141291, -11141121, -11184641, -43521};
   final Opt.Kind kind;
   final String label;
   final DoubleSupplier get;
   final DoubleConsumer set;
   final double min;
   final double max;
   final double step;
   final String[] choices;
   final Supplier<String> valueText;
   final Runnable action;
   private BooleanSupplier usableWhen;

   private Opt(
      Opt.Kind kind,
      String label,
      DoubleSupplier get,
      DoubleConsumer set,
      double min,
      double max,
      double step,
      String[] choices,
      Supplier<String> valueText,
      Runnable action
   ) {
      this.kind = kind;
      this.label = label;
      this.get = get;
      this.set = set;
      this.min = min;
      this.max = max;
      this.step = step;
      this.choices = choices;
      this.valueText = valueText;
      this.action = action;
   }

   Opt usableWhen(BooleanSupplier cond) {
      this.usableWhen = cond;
      return this;
   }

   boolean usable() {
      return this.usableWhen == null || this.usableWhen.getAsBoolean();
   }

   static Opt toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
      return new Opt(Opt.Kind.TOGGLE, label, () -> get.getAsBoolean() ? 1.0 : 0.0, v -> set.accept(v >= 0.5), 0.0, 1.0, 1.0, null, null, null);
   }

   static Opt slider(String label, double min, double max, double step, DoubleSupplier get, DoubleConsumer set, Supplier<String> valueText) {
      return new Opt(Opt.Kind.SLIDER, label, get, set, min, max, step, null, valueText, null);
   }

   static Opt percent(String label, DoubleSupplier get, DoubleConsumer set) {
      return slider(label, 0.0, 1.0, 0.0, get, set, () -> Math.round(get.getAsDouble() * 100.0) + "%");
   }

   static Opt cycle(String label, String[] choices, IntSupplier get, IntConsumer set) {
      return new Opt(Opt.Kind.CYCLE, label, () -> get.getAsInt(), v -> set.accept((int)Math.round(v)), 0.0, choices.length - 1, 1.0, choices, null, null);
   }

   static Opt color(String label, IntSupplier get, IntConsumer set) {
      return new Opt(Opt.Kind.COLOR, label, () -> get.getAsInt() & 4294967295L, v -> set.accept((int)((long)v)), 0.0, 0.0, 0.0, null, null, null);
   }

   static Opt action(String label, Runnable action) {
      return new Opt(Opt.Kind.ACTION, label, null, null, 0.0, 0.0, 0.0, null, null, action);
   }

   double value() {
      return this.get == null ? 0.0 : this.get.getAsDouble();
   }

   double fraction() {
      return this.max > this.min ? clamp01((this.value() - this.min) / (this.max - this.min)) : 0.0;
   }

   void setFraction(double t) {
      double v = this.min + clamp01(t) * (this.max - this.min);
      if (this.step > 0.0) {
         v = this.min + Math.round((v - this.min) / this.step) * this.step;
      }

      this.set.accept(v);
   }

   void advance() {
      switch (this.kind) {
         case TOGGLE:
            this.set.accept(this.value() >= 0.5 ? 0.0 : 1.0);
         case SLIDER:
         default:
            break;
         case CYCLE:
            this.set.accept((Math.round(this.value()) + 1L) % this.choices.length);
            break;
         case COLOR:
            this.set.accept(PALETTE[(indexOfColor((int)((long)this.value())) + 1) % PALETTE.length]);
      }
   }

   String display() {
      if (this.valueText != null) {
         return this.valueText.get();
      }

      return switch (this.kind) {
         case SLIDER -> this.step >= 1.0 ? Long.toString(Math.round(this.value())) : String.format("%.2f", this.value());
         case CYCLE -> this.choices[Math.max(0, Math.min(this.choices.length - 1, (int)Math.round(this.value())))];
         default -> "";
      };
   }

   private static int indexOfColor(int argb) {
      for (int i = 0; i < PALETTE.length; i++) {
         if (PALETTE[i] == argb) {
            return i;
         }
      }

      return -1;
   }

   private static double clamp01(double v) {
      return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v);
   }

   enum Kind {
      TOGGLE,
      SLIDER,
      CYCLE,
      COLOR,
      ACTION;
   }
}

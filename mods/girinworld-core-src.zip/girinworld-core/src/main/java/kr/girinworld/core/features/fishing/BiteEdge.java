package kr.girinworld.core.features.fishing;

final class BiteEdge {
   private boolean prev;

   boolean shouldPlay(boolean hasHook, boolean biting) {
      if (!hasHook) {
         this.prev = false;
         return false;
      } else {
         boolean edge = biting && !this.prev;
         this.prev = biting;
         return edge;
      }
   }
}

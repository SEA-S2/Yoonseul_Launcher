package kr.girinworld.core.features.whisper;

public record WhisperMessage(Direction direction, String text, long timeMillis) {
}

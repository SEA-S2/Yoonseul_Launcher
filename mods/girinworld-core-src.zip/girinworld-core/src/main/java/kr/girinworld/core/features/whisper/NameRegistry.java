package kr.girinworld.core.features.whisper;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import kr.girinworld.core.CoreLog;

public final class NameRegistry {
   private static final Type MAP_TYPE = (new TypeToken<Map<String, String>>() {}).getType();
   private final Map<String, String> koreanToEnglish = new HashMap<>();
   private final Map<String, String> englishLowerToKorean = new HashMap<>();
   private final Map<String, String> englishLowerToDisplay = new HashMap<>();

   public static boolean isKorean(String s) {
      if (s != null && !s.isEmpty()) {
         char c = s.charAt(0);
         return c >= '가' && c <= '힣';
      } else {
         return false;
      }
   }

   public synchronized boolean register(String korean, String english) {
      if (korean != null && english != null && !korean.isBlank() && !english.isBlank()) {
         String prev = this.koreanToEnglish.put(korean, english);
         this.englishLowerToKorean.put(english.toLowerCase(Locale.ROOT), korean);
         this.noteEnglish(english);
         return prev == null || !prev.equals(english);
      } else {
         return false;
      }
   }

   public synchronized void noteEnglish(String english) {
      if (english != null && !english.isBlank() && !isKorean(english)) {
         String lo = english.toLowerCase(Locale.ROOT);
         String cur = this.englishLowerToDisplay.get(lo);
         if (cur == null || hasUpper(english) && !hasUpper(cur)) {
            this.englishLowerToDisplay.put(lo, english);
         }
      }
   }

   public synchronized String identityKey(String name) {
      if (name == null || name.isBlank()) {
         return name;
      } else if (isKorean(name)) {
         String eng = this.koreanToEnglish.get(name);
         return eng != null ? eng.toLowerCase(Locale.ROOT) : name;
      } else {
         this.noteEnglish(name);
         return name.toLowerCase(Locale.ROOT);
      }
   }

   public synchronized String displayFor(String key) {
      if (key == null) {
         return null;
      }

      if (isKorean(key)) {
         return key;
      }

      String kor = this.englishLowerToKorean.get(key);
      if (kor != null) {
         return kor;
      }

      String disp = this.englishLowerToDisplay.get(key);
      return disp != null ? disp : key;
   }

   public synchronized boolean hasKorean(String key) {
      return key != null && !isKorean(key) && this.englishLowerToKorean.containsKey(key);
   }

   public synchronized String englishFor(String korean) {
      return this.koreanToEnglish.get(korean);
   }

   private static boolean hasUpper(String s) {
      for (int i = 0; i < s.length(); i++) {
         if (Character.isUpperCase(s.charAt(i))) {
            return true;
         }
      }

      return false;
   }

   public synchronized void load() {
      Path file = file();

      try {
         if (Files.exists(file)) {
            Map<String, String> loaded = (Map<String, String>)new Gson().fromJson(Files.readString(file), MAP_TYPE);
            if (loaded != null) {
               this.koreanToEnglish.clear();
               this.englishLowerToKorean.clear();
               this.englishLowerToDisplay.clear();

               for (Entry<String, String> e : loaded.entrySet()) {
                  if (e.getKey() != null && e.getValue() != null) {
                     this.koreanToEnglish.put(e.getKey(), e.getValue());
                     this.englishLowerToKorean.put(e.getValue().toLowerCase(Locale.ROOT), e.getKey());
                     this.noteEnglish(e.getValue());
                  }
               }

               CoreLog.info("whisper name map loaded (" + this.koreanToEnglish.size() + " entries)");
            }
         }
      } catch (Throwable t) {
         CoreLog.error("whisper name map load failed, using empty map", t);
      }
   }

   public synchronized void save() {
      Path file = file();

      try {
         Path parent = file.getParent();
         if (parent != null) {
            Files.createDirectories(parent);
         }

         Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(this.koreanToEnglish));
      } catch (Throwable t) {
         CoreLog.error("whisper name map save failed", t);
      }
   }

   private static Path file() {
      return CoreLog.baseDir().resolve("whisper_names.json");
   }
}

package kr.girinworld.core;

public final class KeyMods {
   static final int SHIFT = 1;
   static final int CTRL = 2;
   static final int ALT = 4;
   static final int SUPER = 8;
   static final int MASK = 15;

   private KeyMods() {
   }

   public static int normalize(int raw) {
      return raw & 15;
   }

   public static boolean matches(int want, int got) {
      return normalize(want) == normalize(got);
   }

   public static boolean isModifierKey(int glfwKey) {
      return glfwKey >= 340 && glfwKey <= 347;
   }

   public static int ofKey(int glfwKey) {
      return switch (glfwKey) {
         case 340, 344 -> 1;
         case 341, 345 -> 2;
         case 342, 346 -> 4;
         case 343, 347 -> 8;
         default -> 0;
      };
   }

   public static String prefix(int mods) {
      int m = normalize(mods);
      if (m == 0) {
         return "";
      }

      StringBuilder sb = new StringBuilder();
      if ((m & 2) != 0) {
         sb.append("Ctrl + ");
      }

      if ((m & 1) != 0) {
         sb.append("Shift + ");
      }

      if ((m & 4) != 0) {
         sb.append("Alt + ");
      }

      if ((m & 8) != 0) {
         sb.append("Win + ");
      }

      return sb.toString();
   }
}

package kr.girinworld.core.features.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpRequest.Builder;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;

public final class SocialClient {
   private static final String BASE = "https://api.minecraftservices.com";
   private static final String UA = "MinecraftClient-Social/1.0";
   private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).build();
   private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
      Thread t = new Thread(r, "core-social");
      t.setDaemon(true);
      return t;
   });

   private SocialClient() {
   }

   private static String token() {
      try {
         return Minecraft.getInstance().getUser().getAccessToken();
      } catch (Exception e) {
         return null;
      }
   }

   public static void loadAll(SocialData data) {
      String token = token();
      CoreLog.info("social loadAll: token " + (token == null ? "NULL" : "len=" + token.length() + " dots=" + token.chars().filter(c -> c == 46).count()));
      data.set(SocialData.Snapshot.empty(SocialData.State.LOADING, ""));
      if (token != null && !token.isEmpty()) {
         POOL.submit(() -> {
            try {
               SocialData.Snapshot base = parseFriends(getJson(token, "/friends"));
               boolean fe = false;
               boolean ai = false;
               boolean pk = false;

               try {
                  JsonObject at = getJson(token, "/player/attributes");
                  JsonObject fp = obj(at, "friendsPreferences");
                  if (fp != null) {
                     fe = "ENABLED".equals(str(fp, "friends"));
                     ai = "ENABLED".equals(str(fp, "acceptInvites"));
                     pk = true;
                  }
               } catch (Exception var8) {
               }

               data.set(new SocialData.Snapshot(SocialData.State.OK, base.friends, base.incoming, base.outgoing, fe, ai, pk, ""));
            } catch (SocialClient.SocialException e) {
               data.set(SocialData.Snapshot.empty(SocialData.State.ERROR, e.getMessage()));
            } catch (Exception e) {
               data.set(SocialData.Snapshot.empty(SocialData.State.ERROR, "친구 정보를 불러오지 못했어요."));
            }
         });
      } else {
         data.set(SocialData.Snapshot.empty(SocialData.State.ERROR, "로그인 정보를 찾을 수 없어요."));
      }
   }

   public static void sendRequest(SocialData data, String name) {
      JsonObject body = new JsonObject();
      body.addProperty("updateType", "ADD");
      body.addProperty("name", name);
      action(data, "PUT", "/friends", body, "친구 요청을 보냈어요");
   }

   public static void accept(SocialData data, String profileId) {
      JsonObject body = new JsonObject();
      body.addProperty("updateType", "ADD");
      body.addProperty("profileId", profileId);
      action(data, "PUT", "/friends", body, "친구가 됐어요!");
   }

   public static void remove(SocialData data, String profileId) {
      JsonObject body = new JsonObject();
      body.addProperty("updateType", "REMOVE");
      body.addProperty("profileId", profileId);
      action(data, "PUT", "/friends", body, null);
   }

   public static void enableFriends(SocialData data) {
      JsonObject fp = new JsonObject();
      fp.addProperty("friends", "ENABLED");
      fp.addProperty("acceptInvites", "ENABLED");
      JsonObject body = new JsonObject();
      body.add("friendsPreferences", fp);
      String token = token();
      if (token != null && !token.isEmpty()) {
         data.setBusy(true);
         POOL.submit(() -> {
            try {
               request(token, "POST", "/player/attributes", body);
               data.setToast("친구 기능을 켰어요");
               data.setBusy(false);
               loadAll(data);
            } catch (SocialClient.SocialException e) {
               data.setToast(e.getMessage());
               data.setBusy(false);
            } catch (Exception e) {
               data.setToast("친구 기능을 켜지 못했어요.");
               data.setBusy(false);
            }
         });
      }
   }

   private static void action(SocialData data, String method, String path, JsonObject body, String okToast) {
      String token = token();
      if (token != null && !token.isEmpty()) {
         data.setBusy(true);
         POOL.submit(
            () -> {
               try {
                  JsonObject res = request(token, method, path, body);
                  SocialData.Snapshot cur = data.get();
                  SocialData.Snapshot base = parseFriends(res);
                  data.set(
                     new SocialData.Snapshot(
                        SocialData.State.OK, base.friends, base.incoming, base.outgoing, cur.friendsEnabled, cur.acceptInvites, cur.prefsKnown, ""
                     )
                  );
                  if (okToast != null) {
                     data.setToast(okToast);
                  }

                  data.setBusy(false);
               } catch (SocialClient.SocialException e) {
                  data.setToast(e.getMessage());
                  data.setBusy(false);
               } catch (Exception e) {
                  data.setToast("요청에 실패했어요.");
                  data.setBusy(false);
               }
            }
         );
      } else {
         data.setToast("로그인 정보를 찾을 수 없어요.");
      }
   }

   private static JsonObject getJson(String token, String path) throws Exception {
      return request(token, "GET", path, null);
   }

   private static JsonObject request(String token, String method, String path, JsonObject body) throws Exception {
      Builder b = HttpRequest.newBuilder()
         .uri(URI.create("https://api.minecraftservices.com" + path))
         .timeout(Duration.ofSeconds(15L))
         .header("Authorization", "Bearer " + token)
         .header("User-Agent", "MinecraftClient-Social/1.0")
         .header("Accept", "application/json");
      if (body != null) {
         b.header("Content-Type", "application/json");
         b.method(method, BodyPublishers.ofString(body.toString()));
      } else {
         b.method(method, BodyPublishers.noBody());
      }

      HttpResponse<String> r = HTTP.send(b.build(), BodyHandlers.ofString());
      int sc = r.statusCode();
      if (sc != 200 && sc != 204) {
         String respBody = r.body() == null ? "" : r.body();
         CoreLog.info("social " + method + " " + path + " -> HTTP " + sc + " body=" + respBody.substring(0, Math.min(300, respBody.length())));
         throw new SocialClient.SocialException(explain(sc, respBody));
      } else {
         String s = r.body();
         if (s != null && !s.isBlank()) {
            JsonElement el = JsonParser.parseString(s);
            return el.isJsonObject() ? el.getAsJsonObject() : new JsonObject();
         } else {
            return new JsonObject();
         }
      }
   }

   private static SocialData.Snapshot parseFriends(JsonObject o) {
      return new SocialData.Snapshot(
         SocialData.State.OK, people(o, "friends"), people(o, "incomingRequests"), people(o, "outgoingRequests"), false, false, false, ""
      );
   }

   private static List<SocialData.Friend> people(JsonObject o, String key) {
      List<SocialData.Friend> out = new ArrayList<>();
      JsonArray arr = o != null && o.has(key) && o.get(key).isJsonArray() ? o.getAsJsonArray(key) : null;
      if (arr == null) {
         return out;
      }

      for (JsonElement e : arr) {
         if (e.isJsonObject()) {
            JsonObject p = e.getAsJsonObject();
            String pid = str(p, "profileId");
            if (pid != null && !pid.isEmpty()) {
               String name = str(p, "name");
               out.add(new SocialData.Friend(pid, name == null ? "" : name));
            }
         }
      }

      return out;
   }

   private static String explain(int status, String body) {
      try {
         JsonObject o = JsonParser.parseString(body).getAsJsonObject();
         JsonObject details = obj(o, "details");
         String st = details != null ? str(details, "status") : null;
         if ("INVITE_REJECTED".equals(st)) {
            return "상대가 친구 기능을 켜지 않았거나 초대를 받지 않도록 설정했어요.";
         }
      } catch (Exception var5) {
      }
      return switch (status) {
         case 400 -> "이름 또는 프로필이 존재하지 않아요.";
         case 401 -> "로그인이 만료됐어요. 게임을 재시작해 주세요.";
         case 403 -> "이 계정으로는 친구 기능을 사용할 수 없어요.";
         case 429 -> "요청이 너무 잦아요. 잠시 후 다시 시도해 주세요.";
         default -> "친구 서비스 오류 (HTTP " + status + ")";
      };
   }

   private static JsonObject obj(JsonObject o, String key) {
      return o != null && o.has(key) && o.get(key).isJsonObject() ? o.getAsJsonObject(key) : null;
   }

   private static String str(JsonObject o, String key) {
      return o != null && o.has(key) && o.get(key).isJsonPrimitive() ? o.get(key).getAsString() : null;
   }

   private static final class SocialException extends Exception {
      SocialException(String msg) {
         super(msg);
      }
   }
}

package kr.girinworld.core.features.settings;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import kr.girinworld.core.Config;

final class ClientModule {
   final String id;
   final String name;
   final String desc;
   final String category;
   private Function<Config, String> keyRead;
   private Predicate<Config> enabled;
   private BiConsumer<Config, Boolean> setEnabled;
   private Predicate<Config> inQuick;
   private BiConsumer<Config, Boolean> setInQuick;
   private Supplier<List<Opt>> schema;
   private Runnable onEnable;
   private Supplier<String> actionLabel;
   private Runnable action;

   ClientModule(String id, String name, String desc, String category) {
      this.id = id;
      this.name = name;
      this.desc = desc;
      this.category = category;
   }

   ClientModule key(Function<Config, String> keyRead) {
      this.keyRead = keyRead;
      return this;
   }

   ClientModule toggle(Predicate<Config> enabled, BiConsumer<Config, Boolean> setEnabled) {
      this.enabled = enabled;
      this.setEnabled = setEnabled;
      return this;
   }

   ClientModule quick(Predicate<Config> inQuick, BiConsumer<Config, Boolean> setInQuick) {
      this.inQuick = inQuick;
      this.setInQuick = setInQuick;
      return this;
   }

   ClientModule opts(Supplier<List<Opt>> schema) {
      this.schema = schema;
      return this;
   }

   ClientModule onEnable(Runnable onEnable) {
      this.onEnable = onEnable;
      return this;
   }

   ClientModule action(Supplier<String> label, Runnable action) {
      this.actionLabel = label;
      this.action = action;
      return this;
   }

   boolean quickable() {
      return this.inQuick != null;
   }

   boolean hasToggle() {
      return this.enabled != null;
   }

   List<Opt> opts() {
      return this.schema == null ? List.of() : this.schema.get();
   }

   boolean hasAction() {
      return this.action != null;
   }

   String actionLabel() {
      return this.actionLabel == null ? "사용" : this.actionLabel.get();
   }

   void runAction() {
      if (this.action != null) {
         this.action.run();
      }
   }

   boolean isEnabled() {
      return this.enabled != null && this.enabled.test(Config.get());
   }

   void toggleEnabled() {
      if (this.enabled != null) {
         Config c = Config.get();
         boolean turningOn = !this.enabled.test(c);
         this.setEnabled.accept(c, turningOn);
         if (turningOn && this.onEnable != null) {
            this.onEnable.run();
         }

         c.save();
      }
   }

   boolean isInQuick() {
      return this.inQuick != null && this.inQuick.test(Config.get());
   }

   void toggleInQuick() {
      if (this.inQuick != null) {
         Config c = Config.get();
         this.setInQuick.accept(c, !this.inQuick.test(c));
         c.save();
      }
   }

   String keyDisplay() {
      return this.keyRead == null ? "" : Ng.keyLabel(this.keyRead.apply(Config.get()));
   }
}

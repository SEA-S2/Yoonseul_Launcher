package kr.girinworld.core.features.world;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;
import java.util.random.RandomGenerator;
import kr.girinworld.core.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BeaconRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public final class ItemBeamController {
   private static final int RESCAN_TICKS = 5;
   private static final double BASE_Y = 0.25;
   private static final int FULL_BRIGHT = 15728880;
   private static RenderType beamType;
   private static final List<ItemBeamController.Target> TARGETS = new ArrayList<>();
   private static final RandomGenerator RANDOM = new SplittableRandom();
   private static int tickCounter;
   private static Object lastLevel;

   private static RenderType beamType() {
      if (beamType == null) {
         beamType = RenderTypes.beaconBeam(BeaconRenderer.BEAM_LOCATION, true);
      }

      return beamType;
   }

   private ItemBeamController() {
   }

   private static Config.Beam cfg() {
      return Config.get().beam;
   }

   public static void tick() {
      Config.Beam c = cfg();
      if (!c.enabled) {
         if (!TARGETS.isEmpty()) {
            TARGETS.clear();
         }
      } else {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.player != null && mc.level != null) {
            if (mc.level != lastLevel) {
               lastLevel = mc.level;
               TARGETS.clear();
               tickCounter = 0;
            }

            if (tickCounter++ % 5 == 0) {
               rescan(mc, c);
            }

            if (c.style == 1) {
               spawnParticles(mc, c);
            }
         } else {
            TARGETS.clear();
         }
      }
   }

   public static void submitBeams(PoseStack pose, SubmitNodeCollector collector) {
      Config.Beam c = cfg();
      if (c.enabled && c.style == 0 && !TARGETS.isEmpty() && pose != null && collector != null) {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.gameRenderer != null) {
            Vec3 cam = kr.girinworld.core.ClientCompat.cameraPosition(mc.gameRenderer);
            float anim = (float)(System.currentTimeMillis() % 100000L) / 1000.0F;
            float r = (float)c.thickness;
            float h = (float)c.height;
            int peak = peakAlpha(c);

            for (ItemBeamController.Target t : TARGETS) {
               ItemEntity e = t.entity();
               if (!e.isRemoved()) {
                  int rgb = t.rgb();
                  float dx = (float)(e.getX() - cam.x);
                  float dy = (float)(e.getY() + 0.25 - cam.y);
                  float dz = (float)(e.getZ() - cam.z);
                  collector.submitCustomGeometry(pose, beamType(), (p, vc) -> emitBeam(p, vc, dx, dy, dz, r, h, rgb, anim, peak));
               }
            }
         }
      }
   }

   private static void emitBeam(Pose p, VertexConsumer vc, float ox, float oy, float oz, float r, float h, int rgb, float scroll, int peak) {
      float mid = h * 0.5F;
      float[][] faces = new float[][]{
         {ox - r, oz - r, ox - r, oz + r}, {ox - r, oz + r, ox + r, oz + r}, {ox + r, oz + r, ox + r, oz - r}, {ox + r, oz - r, ox - r, oz - r}
      };

      for (float[] f : faces) {
         band(p, vc, f, oy, oy + mid, 0, peak, rgb, scroll);
         band(p, vc, f, oy + mid, oy + h, peak, 0, rgb, scroll);
      }
   }

   private static int peakAlpha(Config.Beam c) {
      return Math.max(20, Math.min(255, (int)Math.round(255.0 * Math.min(1.0, c.density))));
   }

   private static void band(Pose p, VertexConsumer vc, float[] f, float y0, float y1, int a0, int a1, int rgb, float scroll) {
      float v0 = y0 + scroll;
      float v1 = y1 + scroll;
      int c0 = a0 << 24 | rgb;
      int c1 = a1 << 24 | rgb;
      vertex(p, vc, f[0], y1, f[1], c1, 1.0F, v1);
      vertex(p, vc, f[0], y0, f[1], c0, 1.0F, v0);
      vertex(p, vc, f[2], y0, f[3], c0, 0.0F, v0);
      vertex(p, vc, f[2], y1, f[3], c1, 0.0F, v1);
      vertex(p, vc, f[2], y1, f[3], c1, 0.0F, v1);
      vertex(p, vc, f[2], y0, f[3], c0, 0.0F, v0);
      vertex(p, vc, f[0], y0, f[1], c0, 1.0F, v0);
      vertex(p, vc, f[0], y1, f[1], c1, 1.0F, v1);
   }

   private static void vertex(Pose p, VertexConsumer vc, float x, float y, float z, int argb, float u, float v) {
      vc.addVertex(p, x, y, z).setColor(argb).setUv(u, v).setOverlay(OverlayTexture.NO_OVERLAY).setLight(15728880).setNormal(p, 0.0F, 1.0F, 0.0F);
   }

   private static void rescan(Minecraft mc, Config.Beam c) {
      Player player = mc.player;
      double r = c.distance;
      AABB box = player.getBoundingBox().inflate(r);
      List<ItemEntity> found = mc.level.getEntitiesOfClass(ItemEntity.class, box, ex -> !ex.isRemoved() && passesFilter(c, ex.getItem()));
      Vec3 eye = player.getEyePosition();
      found.sort((a, b) -> Double.compare(a.distanceToSqr(eye), b.distanceToSqr(eye)));
      TARGETS.clear();
      double maxSqr = r * r;

      for (ItemEntity e : found) {
         if (TARGETS.size() >= c.maxItems) {
            break;
         }

         if (e.distanceToSqr(eye) <= maxSqr) {
            TARGETS.add(new ItemBeamController.Target(e, colorOf(c, e.getItem())));
         }
      }
   }

   private static void spawnParticles(Minecraft mc, Config.Beam c) {
      int perTick = Math.max(1, (int)Math.round(c.density));

      for (ItemBeamController.Target t : TARGETS) {
         ItemEntity e = t.entity();
         if (!e.isRemoved()) {
            int rgb = t.rgb();

            for (int i = 0; i < perTick; i++) {
               double h = RANDOM.nextDouble() * c.height;
               double dx = (RANDOM.nextDouble() - 0.5) * 2.0 * c.thickness;
               double dz = (RANDOM.nextDouble() - 0.5) * 2.0 * c.thickness;
               mc.level.addParticle(new DustParticleOptions(rgb & 16777215, 1.0F), e.getX() + dx, e.getY() + 0.25 + h, e.getZ() + dz, 0.0, 0.0, 0.0);
            }
         }
      }
   }

   static int colorOf(Config.Beam c, ItemStack stack) {
      if (c.colorMode == 1) {
         return c.color & 16777215;
      }

      Rarity rarity = stack.getRarity();
      ChatFormatting fmt = rarity == null ? null : rarity.color();
      Integer col = kr.girinworld.core.ClientCompat.formattingColor(fmt);
      return col == null ? 16777215 : col;
   }

   static boolean passesFilter(Config.Beam c, ItemStack stack) {
      if (c.filterMode == 0) {
         return true;
      }

      boolean listed = BeamFilter.matches(c.filter, itemId(stack));
      return c.filterMode == 1 ? listed : !listed;
   }

   private static String itemId(ItemStack stack) {
      try {
         return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
      } catch (Throwable t) {
         return "";
      }
   }

   public static ItemEntity focused() {
      Minecraft mc = Minecraft.getInstance();
      if (cfg().enabled && mc != null && mc.player != null && !TARGETS.isEmpty()) {
         if (mc.player.isShiftKeyDown()) {
            return TARGETS.get(0).entity();
         }

         Vec3 eye = mc.player.getEyePosition();
         Vec3 look = mc.player.getLookAngle();
         ItemEntity best = null;
         double bestDot = 0.99;

         for (ItemBeamController.Target t : TARGETS) {
            ItemEntity e = t.entity();
            if (!e.isRemoved()) {
               Vec3 to = e.position().add(0.0, 0.25, 0.0).subtract(eye);
               double len = to.length();
               if (!(len < 0.1)) {
                  double dot = to.scale(1.0 / len).dot(look);
                  if (dot > bestDot) {
                     bestDot = dot;
                     best = e;
                  }
               }
            }
         }

         return best;
      } else {
         return null;
      }
   }

   public static int trackedCount() {
      return TARGETS.size();
   }

   private record Target(ItemEntity entity, int rgb) {
   }
}

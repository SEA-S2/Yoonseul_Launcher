package kr.girinworld.core.features.fishing;

import java.lang.reflect.Field;
import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance.Attenuation;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.projectile.FishingHook;

public final class FishingController {
   private static Field soundVolume;
   private static Field bitingField;
   private static boolean reflectionInit;
   private static boolean replayBroken;
   private static boolean loggedFirstMute;
   private static boolean loggedFirstReplay;
   private static volatile SoundInstance myReplay;
   private static final BiteEdge EDGE = new BiteEdge();

   private FishingController() {
   }

   public static boolean enabled() {
      return Config.get().modules.fishing;
   }

   private static boolean active() {
      if (!enabled()) {
         return false;
      }

      initReflection();
      return !replayBroken;
   }

   public static void tick(Minecraft mc) {
      if (active() && mc != null && mc.player != null) {
         FishingHook mine = mc.player.fishing;
         boolean biting = mine != null && readBiting(mine);
         if (EDGE.shouldPlay(mine != null, biting)) {
            float volume = (float)Config.get().fishing.myBiteVolume;
            if (!(volume <= 0.0F)) {
               try {
                  SoundInstance sound = new SimpleSoundInstance(
                     SoundEvents.FISHING_BOBBER_SPLASH.location(),
                     SoundSource.NEUTRAL,
                     volume,
                     1.0F,
                     SoundInstance.createUnseededRandom(),
                     false,
                     0,
                     Attenuation.NONE,
                     0.0,
                     0.0,
                     0.0,
                     true
                  );
                  myReplay = sound;
                  mc.getSoundManager().play(sound);
                  if (!loggedFirstReplay) {
                     loggedFirstReplay = true;
                     CoreLog.info("fishing: 내 입질음 로컬 재생 (volume=" + volume + ")");
                  }
               } catch (Throwable t) {
                  CoreLog.error("fishing my-bite replay failed", t);
               }
            }
         }
      }
   }

   private static boolean readBiting(FishingHook hook) {
      if (bitingField == null) {
         return false;
      }

      try {
         return bitingField.getBoolean(hook);
      } catch (Throwable t) {
         replayBroken = true;
         CoreLog.error("fishing biting read failed — 입질음 음소거를 끕니다", t);
         return false;
      }
   }

   private static float volumeMultiplier(SoundInstance si) {
      if (si != null && si == myReplay) {
         return 1.0F;
      }

      if (active() && isBiteSplash(si)) {
         if (!loggedFirstMute) {
            loggedFirstMute = true;
            CoreLog.info("fishing: 입질음 음소거 시작 (" + si.getIdentifier() + ")");
         }

         return 0.0F;
      } else {
         return 1.0F;
      }
   }

   private static boolean isBiteSplash(SoundInstance si) {
      if (si == null) {
         return false;
      }

      Identifier id = si.getIdentifier();
      if (id == null) {
         return false;
      }

      String path = id.getPath();
      return path != null && path.endsWith("fishing_bobber.splash");
   }

   public static float modifyVolume(float vanilla, SoundInstance si) {
      return vanilla * volumeMultiplier(si);
   }

   public static SoundInstance prepareVolume(SoundInstance si) {
      if (!(si instanceof AbstractSoundInstance) || volumeMultiplier(si) >= 1.0F) {
         return si;
      }

      if (soundVolume == null) {
         return si;
      }

      try {
         soundVolume.setFloat(si, 0.0F);
      } catch (Throwable t) {
         CoreLog.error("fishing sound volume set failed", t);
      }

      return si;
   }

   private static void initReflection() {
      if (!reflectionInit) {
         reflectionInit = true;

         try {
            soundVolume = AbstractSoundInstance.class.getDeclaredField("volume");
            soundVolume.setAccessible(true);
         } catch (Throwable t) {
            replayBroken = true;
            CoreLog.error("fishing sound reflection init failed", t);
            return;
         }

         try {
            bitingField = FishingHook.class.getDeclaredField("biting");
            bitingField.setAccessible(true);
         } catch (Throwable t) {
            replayBroken = true;
            CoreLog.error("fishing biting field not found — 입질음 음소거를 끕니다", t);
         }
      }
   }
}

package kr.girinworld.core.features.social;

import java.util.List;
import java.util.Map;

public final class SocialData {
   private volatile SocialData.Snapshot snap = SocialData.Snapshot.empty(SocialData.State.IDLE, "");
   private volatile boolean busy;
   private volatile String toast = "";
   private volatile long toastUntil;
   private volatile long lastLoadMs;
   private volatile Map<String, String> presence = Map.of();

   public SocialData.Snapshot get() {
      return this.snap;
   }

   public boolean busy() {
      return this.busy;
   }

   public long lastLoadMs() {
      return this.lastLoadMs;
   }

   public String toast() {
      return System.currentTimeMillis() < this.toastUntil ? this.toast : "";
   }

   void set(SocialData.Snapshot s) {
      this.snap = s;
      if (s.state == SocialData.State.OK) {
         this.lastLoadMs = System.currentTimeMillis();
      }
   }

   void setBusy(boolean b) {
      this.busy = b;
   }

   void setToast(String msg) {
      this.toast = msg == null ? "" : msg;
      this.toastUntil = System.currentTimeMillis() + 4000L;
   }

   public String presenceOf(String profileId) {
      return profileId == null ? null : this.presence.get(profileId.replace("-", "").toLowerCase());
   }

   public record Friend(String profileId, String name) {
   }

   public static final class Snapshot {
      public final SocialData.State state;
      public final List<SocialData.Friend> friends;
      public final List<SocialData.Friend> incoming;
      public final List<SocialData.Friend> outgoing;
      public final boolean friendsEnabled;
      public final boolean acceptInvites;
      public final boolean prefsKnown;
      public final String message;

      public Snapshot(
         SocialData.State state,
         List<SocialData.Friend> friends,
         List<SocialData.Friend> incoming,
         List<SocialData.Friend> outgoing,
         boolean friendsEnabled,
         boolean acceptInvites,
         boolean prefsKnown,
         String message
      ) {
         this.state = state;
         this.friends = friends;
         this.incoming = incoming;
         this.outgoing = outgoing;
         this.friendsEnabled = friendsEnabled;
         this.acceptInvites = acceptInvites;
         this.prefsKnown = prefsKnown;
         this.message = message;
      }

      static SocialData.Snapshot empty(SocialData.State s, String msg) {
         return new SocialData.Snapshot(s, List.of(), List.of(), List.of(), false, false, false, msg);
      }
   }

   public enum State {
      IDLE,
      LOADING,
      OK,
      ERROR;
   }
}

package kr.girinworld.core.agent;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kr.girinworld.core.CoreLog;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Type;

public final class CoreTransformer implements ClassFileTransformer {
   private static final String HOOKS = "kr/girinworld/core/Hooks";
   private static final String KEYBOARD_HANDLER = "net/minecraft/client/KeyboardHandler";
   private static final String MINECRAFT = "net/minecraft/client/Minecraft";
   private static final String GUI = "net/minecraft/client/gui/Gui";
   private static final String GUI_GRAPHICS_EXTRACTOR = "net/minecraft/client/gui/GuiGraphicsExtractor";
   private static final String CAMERA = "net/minecraft/client/Camera";
   private static final String MOUSE_HANDLER = "net/minecraft/client/MouseHandler";
   private static final String KEYBOARD_INPUT = "net/minecraft/client/player/KeyboardInput";
   private static final String GAME_RENDERER = "net/minecraft/client/renderer/GameRenderer";
   private static final String CHAT_COMPONENT = "net/minecraft/client/gui/components/ChatComponent";
   private static final String LIGHTMAP_EXTRACTOR = "net/minecraft/client/renderer/LightmapRenderStateExtractor";
   private static final String SKY_RENDERER = "net/minecraft/client/renderer/SkyRenderer";
   private static final String CLIENT_CLOCK = "net/minecraft/client/ClientClockManager";
   private static final String LEVEL_RENDERER = "net/minecraft/client/renderer/LevelRenderer";
   private static final String SOUND_ENGINE = "net/minecraft/client/sounds/SoundEngine";
   private static final String ADVANCEMENT_WIDGET = "net/minecraft/client/gui/screens/advancements/AdvancementWidget";
   private static final String ADVANCEMENTS_SCREEN = "net/minecraft/client/gui/screens/advancements/AdvancementsScreen";
   private static final String MOB_EFFECT_FOG = "net/minecraft/client/renderer/fog/environment/MobEffectFogEnvironment";
   private static final String ENCHANTMENT = "net/minecraft/world/item/enchantment/Enchantment";
   private static final String PROFILE_KEY_MANAGER = "net/minecraft/client/multiplayer/AccountProfileKeyPairManager";
   private static final String USER_API_SERVICE = "com/mojang/authlib/minecraft/UserApiService";
   private static final String USER = "net/minecraft/client/User";
   private static final String ENTITY_RENDERER = "net/minecraft/client/renderer/entity/EntityRenderer";
   private static final String ENTITY_RENDER_STATE = "net/minecraft/client/renderer/entity/state/EntityRenderState";
   private static final String TTF_DEF = "net/minecraft/client/gui/font/providers/TrueTypeGlyphProviderDefinition";
   private static final Set<String> INJECTED = new LinkedHashSet<>();
   private static final Set<String> MISSING = new LinkedHashSet<>();
   private static boolean reported;

   @Override
   public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) {
      KnotExposure.ensureExposed(loader);
      if (className == null) {
         return null;
      }

      try {
         switch (className) {
            case "net/minecraft/client/KeyboardHandler": {
               byte[] out = injectHeadIntercept(
                  classfileBuffer, "keyPress", "(JILnet/minecraft/client/input/KeyEvent;)V", "kr/girinworld/core/Hooks", "onKeyPress"
               );
               CoreLog.info("transformed net/minecraft/client/KeyboardHandler.keyPress [H1]");
               return out;
            }
            case "net/minecraft/client/Minecraft": {
               byte[] out = injectTailCall(classfileBuffer, "tick", "()V", "kr/girinworld/core/Hooks", "onClientTick", "()V", List.of());
               CoreLog.info("transformed net/minecraft/client/Minecraft.tick [H2]");
               return out;
            }
            case "net/minecraft/client/gui/Hud": {
               byte[] out = injectTailCall(
                  classfileBuffer,
                  "extractRenderState",
                  "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/DeltaTracker;)V",
                  "kr/girinworld/core/Hooks",
                  "onHudRender",
                  "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;)V",
                  List.of(new CoreTransformer.ArgLoad(25, 1))
               );
               out = injectHeadIntercept(
                  out,
                  "extractEffects",
                  "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;Lnet/minecraft/client/DeltaTracker;)V",
                  "kr/girinworld/core/Hooks",
                  "onExtractEffects"
               );
               CoreLog.info("transformed net/minecraft/client/gui/Hud.extractRenderState[H3] + extractEffects[H16]");
               return out;
            }
            case "net/minecraft/client/Camera": {
               byte[] out = injectReturnTransform(classfileBuffer, "calculateFov", "(F)F", "kr/girinworld/core/Hooks", "modifyFov");
               out = injectArgRewrite(
                  out,
                  "setRotation",
                  "(FF)V",
                  List.of(
                     new CoreTransformer.ArgRewrite(1, Type.FLOAT_TYPE, "kr/girinworld/core/Hooks", "photoYaw"),
                     new CoreTransformer.ArgRewrite(2, Type.FLOAT_TYPE, "kr/girinworld/core/Hooks", "photoPitch")
                  )
               );
               out = injectArgRewrite(
                  out, "getMaxZoom", "(F)F", List.of(new CoreTransformer.ArgRewrite(1, Type.FLOAT_TYPE, "kr/girinworld/core/Hooks", "photoOrbitDistance"))
               );
               CoreLog.info("transformed net/minecraft/client/Camera.calculateFov[H4] + setRotation/getMaxZoom[H5]");
               return out;
            }
            case "net/minecraft/client/MouseHandler": {
               byte[] out = injectHeadIntercept(classfileBuffer, "onScroll", "(JDD)V", "kr/girinworld/core/Hooks", "onScroll");
               out = injectHeadIntercept(out, "onButton", "(JLnet/minecraft/client/input/MouseButtonInfo;I)V", "kr/girinworld/core/Hooks", "onMouseButton");
               out = injectHeadInterceptWithSelf(out, "turnPlayer", "(D)V", "kr/girinworld/core/Hooks", "onTurnPlayer", "net/minecraft/client/MouseHandler");
               CoreLog.info("transformed net/minecraft/client/MouseHandler.onScroll[H7] + onButton[H9] + turnPlayer[H6]");
               return out;
            }
            case "net/minecraft/client/player/KeyboardInput": {
               byte[] out = injectTailCallWithSelf(
                  classfileBuffer, "tick", "()V", "kr/girinworld/core/Hooks", "onMovementInput", "net/minecraft/client/player/KeyboardInput"
               );
               CoreLog.info("transformed net/minecraft/client/player/KeyboardInput.tick [H8]");
               return out;
            }
            case "net/minecraft/client/renderer/LevelRenderer": {
               byte[] out = injectTailCall(
                  classfileBuffer,
                  "submitEntities",
                  "(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/state/level/LevelRenderState;Lnet/minecraft/client/renderer/SubmitNodeCollector;)V",
                  "kr/girinworld/core/Hooks",
                  "onSubmitEntities",
                  "(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;)V",
                  List.of(new CoreTransformer.ArgLoad(25, 1), new CoreTransformer.ArgLoad(25, 3))
               );
               CoreLog.info("transformed net/minecraft/client/renderer/LevelRenderer.submitEntities [H23]");
               return out;
            }
            case "net/minecraft/client/renderer/entity/EntityRenderer": {
               byte[] out = injectTailCall(
                  classfileBuffer,
                  "extractRenderState",
                  "(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V",
                  "kr/girinworld/core/Hooks",
                  "onEntityExtract",
                  "(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/client/renderer/entity/state/EntityRenderState;F)V",
                  List.of(new CoreTransformer.ArgLoad(25, 1), new CoreTransformer.ArgLoad(25, 2), new CoreTransformer.ArgLoad(23, 3))
               );
               CoreLog.info("transformed net/minecraft/client/renderer/entity/EntityRenderer.extractRenderState [H27]");
               return out;
            }
            case "net/minecraft/client/gui/screens/advancements/AdvancementWidget": {
               byte[] out = injectHeadInterceptWithSelf(
                  classfileBuffer,
                  "setProgress",
                  "(Lnet/minecraft/advancements/AdvancementProgress;)V",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementProgress",
                  "net/minecraft/client/gui/screens/advancements/AdvancementWidget"
               );
               out = injectTailCallWithSelf(
                  out,
                  "extractHover",
                  "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIFII)V",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementHover",
                  "net/minecraft/client/gui/screens/advancements/AdvancementWidget"
               );
               out = injectTailCall(
                  out,
                  "<init>",
                  "(Lnet/minecraft/client/gui/screens/advancements/AdvancementTab;Lnet/minecraft/client/Minecraft;Lnet/minecraft/advancements/AdvancementNode;Lnet/minecraft/advancements/DisplayInfo;)V",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementWidget",
                  "(Lnet/minecraft/client/gui/screens/advancements/AdvancementWidget;Lnet/minecraft/advancements/DisplayInfo;)V",
                  List.of(new CoreTransformer.ArgLoad(25, 0), new CoreTransformer.ArgLoad(25, 4))
               );
               CoreLog.info("transformed net/minecraft/client/gui/screens/advancements/AdvancementWidget.setProgress[H30] + extractHover[H31] + <init>[H33]");
               return out;
            }
            case "net/minecraft/client/gui/screens/advancements/AdvancementsScreen": {
               byte[] out = injectTailCall(
                  classfileBuffer,
                  "extractRenderState",
                  "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;IIF)V",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementsScreen",
                  "(Lnet/minecraft/client/gui/GuiGraphicsExtractor;II)V",
                  List.of(new CoreTransformer.ArgLoad(25, 1), new CoreTransformer.ArgLoad(21, 2), new CoreTransformer.ArgLoad(21, 3))
               );
               out = injectReturnTransformWithArg(
                  out,
                  "mouseClicked",
                  "(Lnet/minecraft/client/input/MouseButtonEvent;Z)Z",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementsClick",
                  "(ZLnet/minecraft/client/input/MouseButtonEvent;)Z",
                  new CoreTransformer.ArgLoad(25, 1)
               );
               out = injectReturnTransformWithArg(
                  out,
                  "mouseReleased",
                  "(Lnet/minecraft/client/input/MouseButtonEvent;)Z",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementsRelease",
                  "(ZLnet/minecraft/client/input/MouseButtonEvent;)Z",
                  new CoreTransformer.ArgLoad(25, 1)
               );
               out = injectTailCall(
                  out,
                  "<init>",
                  "(Lnet/minecraft/client/multiplayer/ClientAdvancements;Lnet/minecraft/client/gui/screens/Screen;)V",
                  "kr/girinworld/core/Hooks",
                  "onAdvancementsScreenCreate",
                  "(Lnet/minecraft/client/gui/screens/advancements/AdvancementsScreen;Lnet/minecraft/client/gui/screens/Screen;)V",
                  List.of(new CoreTransformer.ArgLoad(25, 0), new CoreTransformer.ArgLoad(25, 2))
               );
               CoreLog.info(
                  "transformed net/minecraft/client/gui/screens/advancements/AdvancementsScreen.extractRenderState[H32] + mouseClicked[H34] + mouseReleased[H35] + <init>[H36]"
               );
               return out;
            }
            case "net/minecraft/client/renderer/fog/environment/MobEffectFogEnvironment": {
               byte[] out = injectReturnTransformWithArg(
                  classfileBuffer,
                  "isApplicable",
                  "(Lnet/minecraft/world/level/material/FogType;Lnet/minecraft/world/entity/Entity;)Z",
                  "kr/girinworld/core/Hooks",
                  "fogApplicable",
                  "(ZLnet/minecraft/client/renderer/fog/environment/MobEffectFogEnvironment;)Z",
                  new CoreTransformer.ArgLoad(25, 0)
               );
               CoreLog.info("transformed net/minecraft/client/renderer/fog/environment/MobEffectFogEnvironment.isApplicable [H25]");
               return out;
            }
            case "net/minecraft/world/item/enchantment/Enchantment": {
               byte[] out = injectReturnTransformWithArg(
                  classfileBuffer,
                  "getFullname",
                  "(Lnet/minecraft/core/Holder;I)Lnet/minecraft/network/chat/Component;",
                  "kr/girinworld/core/Hooks",
                  "enchantName",
                  "(Lnet/minecraft/network/chat/Component;Lnet/minecraft/core/Holder;I)Lnet/minecraft/network/chat/Component;",
                  new CoreTransformer.ArgLoad(25, 0),
                  new CoreTransformer.ArgLoad(21, 1)
               );
               CoreLog.info("transformed net/minecraft/world/item/enchantment/Enchantment.getFullname [H26]");
               return out;
            }
            case "net/minecraft/client/multiplayer/AccountProfileKeyPairManager": {
               byte[] out = injectArgRewrite(
                  classfileBuffer,
                  "fetchProfileKeyPair",
                  "(Lcom/mojang/authlib/minecraft/UserApiService;)Lnet/minecraft/world/entity/player/ProfileKeyPair;",
                  List.of(
                     new CoreTransformer.ArgRewrite(
                        1, Type.getObjectType("com/mojang/authlib/minecraft/UserApiService"), "kr/girinworld/core/Hooks", "profileKeyApi"
                     )
                  )
               );
               CoreLog.info("transformed net/minecraft/client/multiplayer/AccountProfileKeyPairManager.fetchProfileKeyPair [H28]");
               return out;
            }
            case "net/minecraft/client/User": {
               byte[] out = injectReturnTransform(classfileBuffer, "getAccessToken", "()Ljava/lang/String;", "kr/girinworld/core/Hooks", "accessToken");
               CoreLog.info("transformed net/minecraft/client/User.getAccessToken [H29]");
               return out;
            }
            case "net/minecraft/client/ClientClockManager": {
               byte[] out = injectReturnTransform(
                  classfileBuffer, "getTotalTicks", "(Lnet/minecraft/core/Holder;)J", "kr/girinworld/core/Hooks", "skyClockTime"
               );
               CoreLog.info("transformed net/minecraft/client/ClientClockManager.getTotalTicks [H20]");
               return out;
            }
            case "net/minecraft/client/renderer/GameRenderer": {
               byte[] out = injectTailCall(
                  classfileBuffer, "render", "(Lnet/minecraft/client/DeltaTracker;Z)V", "kr/girinworld/core/Hooks", "onFrameEnd", "()V", List.of()
               );
               String extractDesc = "(Lnet/minecraft/client/DeltaTracker;Z)V";
               out = injectHeadIntercept(out, "extract", extractDesc, "kr/girinworld/core/Hooks", "onExtractBegin");
               out = injectTailCall(out, "extract", extractDesc, "kr/girinworld/core/Hooks", "onExtractEnd", "()V", List.of());
               CoreLog.info("transformed net/minecraft/client/renderer/GameRenderer.render[H10] + extract[H19]");
               return out;
            }
            case "net/minecraft/client/gui/components/ChatComponent": {
               byte[] out = injectTailCall(
                  classfileBuffer,
                  "addMessage",
                  "(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
                  "kr/girinworld/core/Hooks",
                  "onChatMessage",
                  "(Lnet/minecraft/network/chat/Component;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;)V",
                  List.of(new CoreTransformer.ArgLoad(25, 1), new CoreTransformer.ArgLoad(25, 3))
               );
               out = injectReturnTransform(out, "getWidth", "()I", "kr/girinworld/core/Hooks", "chatWidth");
               out = injectReturnTransform(out, "getHeight", "()I", "kr/girinworld/core/Hooks", "chatHeight");
               out = injectReturnTransform(out, "getScale", "()D", "kr/girinworld/core/Hooks", "chatScale");
               out = injectArgRewrite(
                  out,
                  "addMessage",
                  "(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
                  List.of(
                     new CoreTransformer.ArgRewrite(
                        1, Type.getObjectType("net/minecraft/network/chat/Component"), "kr/girinworld/core/Hooks", "decorateChatLine"
                     )
                  )
               );
               CoreLog.info("transformed net/minecraft/client/gui/components/ChatComponent.addMessage[H11·H18] + getWidth/getHeight/getScale[H17]");
               return out;
            }
            case "net/minecraft/client/renderer/LightmapRenderStateExtractor": {
               String desc = "(Lnet/minecraft/client/renderer/state/LightmapRenderState;F)V";
               byte[] out = injectHeadInterceptWithSelf(
                  classfileBuffer,
                  "extract",
                  desc,
                  "kr/girinworld/core/Hooks",
                  "onLightmapExtractBegin",
                  "net/minecraft/client/renderer/LightmapRenderStateExtractor"
               );
               out = injectTailCall(
                  out,
                  "extract",
                  desc,
                  "kr/girinworld/core/Hooks",
                  "onLightmapExtract",
                  "(Lnet/minecraft/client/renderer/state/LightmapRenderState;)V",
                  List.of(new CoreTransformer.ArgLoad(25, 1))
               );
               CoreLog.info("transformed net/minecraft/client/renderer/LightmapRenderStateExtractor.extract [H12·H21]");
               return out;
            }
            case "net/minecraft/client/sounds/SoundEngine": {
               byte[] out = injectReturnTransformWithArg(
                  classfileBuffer,
                  "calculateVolume",
                  "(Lnet/minecraft/client/resources/sounds/SoundInstance;)F",
                  "kr/girinworld/core/Hooks",
                  "modifyFishingVolume",
                  "(FLnet/minecraft/client/resources/sounds/SoundInstance;)F",
                  new CoreTransformer.ArgLoad(25, 1)
               );
               out = injectArgRewrite(
                  out,
                  "play",
                  "(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;",
                  List.of(
                     new CoreTransformer.ArgRewrite(
                        1, Type.getObjectType("net/minecraft/client/resources/sounds/SoundInstance"), "kr/girinworld/core/Hooks", "prepareSound"
                     )
                  )
               );
               CoreLog.info("transformed net/minecraft/client/sounds/SoundEngine.calculateVolume [H13] + play [H15]");
               return out;
            }
            case "net/minecraft/client/gui/font/providers/TrueTypeGlyphProviderDefinition": {
               byte[] out = injectArgRewrite(
                  classfileBuffer,
                  "<init>",
                  "(Lnet/minecraft/resources/Identifier;FFLnet/minecraft/client/gui/font/providers/TrueTypeGlyphProviderDefinition$Shift;Ljava/lang/String;)V",
                  List.of(
                     new CoreTransformer.ArgRewrite(
                        2,
                        Type.FLOAT_TYPE,
                        "kr/girinworld/core/Hooks",
                        "fontSize",
                        List.of(new CoreTransformer.ArgLoad(25, 1)),
                        "Lnet/minecraft/resources/Identifier;"
                     )
                  )
               );
               CoreLog.info("transformed net/minecraft/client/gui/font/providers/TrueTypeGlyphProviderDefinition.<init> [H24]");
               return out;
            }
            default:
               return null;
         }
      } catch (Throwable t) {
         CoreLog.error("transform failed for " + className + ", returning original bytes", t);
         return null;
      }
   }

   static byte[] injectHeadIntercept(byte[] input, String targetMethod, String targetDesc, String hookOwner, String hookName) {
      if (Type.getReturnType(targetDesc).getSort() != 0) {
         throw new IllegalArgumentException("head-intercept target must be void: " + targetDesc);
      }

      Type[] args = Type.getArgumentTypes(targetDesc);
      StringBuilder desc = new StringBuilder("(");

      for (Type a : args) {
         desc.append(a.getDescriptor());
      }

      desc.append(")Z");
      String hookDesc = desc.toString();
      return rewrite(input, targetMethod, targetDesc, mv -> new CoreTransformer.HeadInterceptor(mv, hookOwner, hookName, hookDesc, args));
   }

   static byte[] injectReturnTransform(byte[] input, String targetMethod, String targetDesc, String hookOwner, String hookName) {
      Type ret = Type.getReturnType(targetDesc);
      String hookDesc = "(" + ret.getDescriptor() + ")" + ret.getDescriptor();
      int returnOpcode = ret.getOpcode(172);
      return rewrite(input, targetMethod, targetDesc, mv -> new CoreTransformer.ReturnTransformer(mv, hookOwner, hookName, hookDesc, returnOpcode));
   }

   static byte[] injectReturnTransformWithArg(
      byte[] input, String targetMethod, String targetDesc, String hookOwner, String hookName, String hookDesc, CoreTransformer.ArgLoad... extra
   ) {
      Type ret = Type.getReturnType(targetDesc);
      int returnOpcode = ret.getOpcode(172);
      return rewrite(
         input, targetMethod, targetDesc, mv -> new CoreTransformer.ReturnTransformerWithArg(mv, hookOwner, hookName, hookDesc, returnOpcode, extra)
      );
   }

   static byte[] injectTailCall(
      byte[] input, String targetMethod, String targetDesc, String hookOwner, String hookName, String hookDesc, List<CoreTransformer.ArgLoad> args
   ) {
      return rewrite(input, targetMethod, targetDesc, mv -> new CoreTransformer.TailInjector(mv, hookOwner, hookName, hookDesc, args));
   }

   static byte[] injectTailCallWithSelf(byte[] input, String targetMethod, String targetDesc, String hookOwner, String hookName, String selfInternalName) {
      Type[] args = Type.getArgumentTypes(targetDesc);
      StringBuilder desc = new StringBuilder("(L").append(selfInternalName).append(";");

      for (Type a : args) {
         desc.append(a.getDescriptor());
      }

      desc.append(")V");
      String hookDesc = desc.toString();
      return rewrite(input, targetMethod, targetDesc, mv -> new CoreTransformer.TailInjectorWithSelf(mv, hookOwner, hookName, hookDesc, args));
   }

   static byte[] injectHeadInterceptWithSelf(byte[] input, String targetMethod, String targetDesc, String hookOwner, String hookName, String selfInternalName) {
      if (Type.getReturnType(targetDesc).getSort() != 0) {
         throw new IllegalArgumentException("head-intercept target must be void: " + targetDesc);
      }

      Type[] args = Type.getArgumentTypes(targetDesc);
      StringBuilder desc = new StringBuilder("(L").append(selfInternalName).append(";");

      for (Type a : args) {
         desc.append(a.getDescriptor());
      }

      desc.append(")Z");
      String hookDesc = desc.toString();
      return rewrite(input, targetMethod, targetDesc, mv -> new CoreTransformer.HeadInterceptorWithSelf(mv, hookOwner, hookName, hookDesc, args));
   }

   static byte[] injectArgRewrite(byte[] input, String targetMethod, String targetDesc, List<CoreTransformer.ArgRewrite> rewrites) {
      return rewrite(input, targetMethod, targetDesc, mv -> new CoreTransformer.ArgRewriter(mv, rewrites));
   }

   public static synchronized void logBootReport() {
      if (!reported) {
         reported = true;
         int total = INJECTED.size() + MISSING.size();
         CoreLog.info("hook boot report: " + INJECTED.size() + "/" + total + " injected");
         if (!MISSING.isEmpty()) {
            CoreLog.error("hook boot report: MISSING " + MISSING + " — 해당 기능만 비활성(게임은 정상). 26.2 업데이트면 후킹 지점을 갱신할 것", null);
         }
      }
   }

   private static byte[] rewrite(byte[] input, final String targetMethod, final String targetDesc, final CoreTransformer.MethodRewriter rewriter) {
      ClassReader cr = new ClassReader(input);
      ClassWriter cw = new ClassWriter(cr, 1);
      final boolean[] matched = new boolean[]{false};
      ClassVisitor cv = new ClassVisitor(589824, cw) {
         @Override
         public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
            MethodVisitor mv = super.visitMethod(access, name, descriptor, signature, exceptions);
            if (name.equals(targetMethod) && descriptor.equals(targetDesc)) {
               matched[0] = true;
               return rewriter.wrap(mv);
            } else {
               return mv;
            }
         }
      };
      cr.accept(cv, 0);
      String id = simpleName(cr.getClassName()) + "." + targetMethod;
      if (!matched[0]) {
         MISSING.add(id);
         CoreLog.error("HOOK MISSING: " + targetMethod + " " + targetDesc + " not found; feature disabled (bytecode unchanged)", null);
         return input;
      } else {
         INJECTED.add(id);
         return cw.toByteArray();
      }
   }

   private static String simpleName(String internalName) {
      int slash = internalName.lastIndexOf(47);
      return slash < 0 ? internalName : internalName.substring(slash + 1);
   }

   record ArgLoad(int opcode, int slot) {
   }

   record ArgRewrite(int slot, Type type, String hookOwner, String hookName, List<CoreTransformer.ArgLoad> extra, String extraDesc) {
      ArgRewrite(int slot, Type type, String hookOwner, String hookName) {
         this(slot, type, hookOwner, hookName, List.of(), "");
      }
   }

   private static final class ArgRewriter extends MethodVisitor {
      private final List<CoreTransformer.ArgRewrite> rewrites;

      ArgRewriter(MethodVisitor mv, List<CoreTransformer.ArgRewrite> rewrites) {
         super(589824, mv);
         this.rewrites = rewrites;
      }

      @Override
      public void visitCode() {
         super.visitCode();

         for (CoreTransformer.ArgRewrite r : this.rewrites) {
            String d = r.type().getDescriptor();
            this.mv.visitVarInsn(r.type().getOpcode(21), r.slot());

            for (CoreTransformer.ArgLoad a : r.extra()) {
               this.mv.visitVarInsn(a.opcode(), a.slot());
            }

            this.mv.visitMethodInsn(184, r.hookOwner(), r.hookName(), "(" + d + r.extraDesc() + ")" + d, false);
            this.mv.visitVarInsn(r.type().getOpcode(54), r.slot());
         }
      }
   }

   private static final class HeadInterceptor extends MethodVisitor {
      private final String hookOwner;
      private final String hookName;
      private final String hookDesc;
      private final Type[] args;

      HeadInterceptor(MethodVisitor mv, String hookOwner, String hookName, String hookDesc, Type[] args) {
         super(589824, mv);
         this.hookOwner = hookOwner;
         this.hookName = hookName;
         this.hookDesc = hookDesc;
         this.args = args;
      }

      @Override
      public void visitCode() {
         super.visitCode();
         int slot = 1;

         for (Type a : this.args) {
            this.mv.visitVarInsn(a.getOpcode(21), slot);
            slot += a.getSize();
         }

         this.mv.visitMethodInsn(184, this.hookOwner, this.hookName, this.hookDesc, false);
         Label cont = new Label();
         this.mv.visitJumpInsn(153, cont);
         this.mv.visitInsn(177);
         this.mv.visitLabel(cont);
         this.mv.visitFrame(3, 0, null, 0, null);
      }
   }

   private static final class HeadInterceptorWithSelf extends MethodVisitor {
      private final String hookOwner;
      private final String hookName;
      private final String hookDesc;
      private final Type[] args;

      HeadInterceptorWithSelf(MethodVisitor mv, String hookOwner, String hookName, String hookDesc, Type[] args) {
         super(589824, mv);
         this.hookOwner = hookOwner;
         this.hookName = hookName;
         this.hookDesc = hookDesc;
         this.args = args;
      }

      @Override
      public void visitCode() {
         super.visitCode();
         this.mv.visitVarInsn(25, 0);
         int slot = 1;

         for (Type a : this.args) {
            this.mv.visitVarInsn(a.getOpcode(21), slot);
            slot += a.getSize();
         }

         this.mv.visitMethodInsn(184, this.hookOwner, this.hookName, this.hookDesc, false);
         Label cont = new Label();
         this.mv.visitJumpInsn(153, cont);
         this.mv.visitInsn(177);
         this.mv.visitLabel(cont);
         this.mv.visitFrame(3, 0, null, 0, null);
      }
   }

   private interface MethodRewriter {
      MethodVisitor wrap(MethodVisitor var1);
   }

   private static final class ReturnTransformer extends MethodVisitor {
      private final String hookOwner;
      private final String hookName;
      private final String hookDesc;
      private final int returnOpcode;

      ReturnTransformer(MethodVisitor mv, String hookOwner, String hookName, String hookDesc, int returnOpcode) {
         super(589824, mv);
         this.hookOwner = hookOwner;
         this.hookName = hookName;
         this.hookDesc = hookDesc;
         this.returnOpcode = returnOpcode;
      }

      @Override
      public void visitInsn(int opcode) {
         if (opcode == this.returnOpcode) {
            this.mv.visitMethodInsn(184, this.hookOwner, this.hookName, this.hookDesc, false);
         }

         super.visitInsn(opcode);
      }
   }

   private static final class ReturnTransformerWithArg extends MethodVisitor {
      private final String hookOwner;
      private final String hookName;
      private final String hookDesc;
      private final int returnOpcode;
      private final CoreTransformer.ArgLoad[] extra;

      ReturnTransformerWithArg(MethodVisitor mv, String hookOwner, String hookName, String hookDesc, int returnOpcode, CoreTransformer.ArgLoad[] extra) {
         super(589824, mv);
         this.hookOwner = hookOwner;
         this.hookName = hookName;
         this.hookDesc = hookDesc;
         this.returnOpcode = returnOpcode;
         this.extra = extra;
      }

      @Override
      public void visitInsn(int opcode) {
         if (opcode == this.returnOpcode) {
            for (CoreTransformer.ArgLoad a : this.extra) {
               this.mv.visitVarInsn(a.opcode(), a.slot());
            }

            this.mv.visitMethodInsn(184, this.hookOwner, this.hookName, this.hookDesc, false);
         }

         super.visitInsn(opcode);
      }
   }

   private static final class TailInjector extends MethodVisitor {
      private final String hookOwner;
      private final String hookName;
      private final String hookDesc;
      private final List<CoreTransformer.ArgLoad> args;

      TailInjector(MethodVisitor mv, String hookOwner, String hookName, String hookDesc, List<CoreTransformer.ArgLoad> args) {
         super(589824, mv);
         this.hookOwner = hookOwner;
         this.hookName = hookName;
         this.hookDesc = hookDesc;
         this.args = args;
      }

      @Override
      public void visitInsn(int opcode) {
         if (opcode == 177) {
            for (CoreTransformer.ArgLoad a : this.args) {
               this.mv.visitVarInsn(a.opcode(), a.slot());
            }

            this.mv.visitMethodInsn(184, this.hookOwner, this.hookName, this.hookDesc, false);
         }

         super.visitInsn(opcode);
      }
   }

   private static final class TailInjectorWithSelf extends MethodVisitor {
      private final String hookOwner;
      private final String hookName;
      private final String hookDesc;
      private final Type[] args;

      TailInjectorWithSelf(MethodVisitor mv, String hookOwner, String hookName, String hookDesc, Type[] args) {
         super(589824, mv);
         this.hookOwner = hookOwner;
         this.hookName = hookName;
         this.hookDesc = hookDesc;
         this.args = args;
      }

      @Override
      public void visitInsn(int opcode) {
         if (opcode == 177) {
            this.mv.visitVarInsn(25, 0);
            int slot = 1;

            for (Type a : this.args) {
               this.mv.visitVarInsn(a.getOpcode(21), slot);
               slot += a.getSize();
            }

            this.mv.visitMethodInsn(184, this.hookOwner, this.hookName, this.hookDesc, false);
         }

         super.visitInsn(opcode);
      }
   }
}

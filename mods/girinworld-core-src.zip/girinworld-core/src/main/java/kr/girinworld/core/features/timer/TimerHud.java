package kr.girinworld.core.features.timer;

import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.features.hud.HudLayoutScreen;
import kr.girinworld.core.features.hud.HudUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2fStack;

public final class TimerHud {
   private static final float BASE_SCALE = 0.8F;
   static final int MARGIN = 6;

   private TimerHud() {
   }

   static boolean shouldRender() {
      return Config.get().timer.hudEnabled && !TimerManager.timers().isEmpty();
   }

   public static void render(GuiGraphicsExtractor graphics) {
      Config.Timer cfg = Config.get().timer;
      if (cfg.hudEnabled) {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null) {
            if (!(kr.girinworld.core.ClientCompat.screen(mc) instanceof HudLayoutScreen)) {
               List<Timer> timers = TimerManager.timers();
               if (!timers.isEmpty()) {
                  Font font = mc.font;
                  float scale = effectiveScale();
                  int[] size = contentSize(font, timers, scale);
                  int screenW = mc.getWindow().getGuiScaledWidth();
                  int screenH = mc.getWindow().getGuiScaledHeight();
                  int x = anchorX(screenW, size[0], cfg.hudX);
                  int y = anchorY(screenH, size[1], cfg.hudY);
                  drawStack(graphics, font, timers, x, y, scale, alpha());
               }
            }
         }
      }
   }

   static int anchorX(int screenW, int contentW, double hudX) {
      return HudUtil.anchorX(screenW, contentW, hudX);
   }

   static int anchorY(int screenH, int contentH, double hudY) {
      return HudUtil.anchorY(screenH, contentH, hudY);
   }

   static int span(int screen, int content) {
      return HudUtil.span(screen, content);
   }

   public static float effectiveScale() {
      return (float)clampScale(Config.get().timer.hudScale) * 0.8F;
   }

   public static int alpha() {
      return (int)Math.round(clampOpacity(Config.get().timer.hudOpacity) * 255.0);
   }

   public static int[] contentSize(Font font, List<Timer> timers, float scale) {
      int lh = 9;
      int maxW = 0;
      int lines = 0;

      for (Timer t : timers) {
         maxW = Math.max(maxW, font.width(format(t.displayNanos())));
         if (!t.name().isEmpty()) {
            maxW = Math.max(maxW, font.width(t.name()));
            lines += 2;
         } else {
            lines++;
         }
      }

      int gap = lh / 2;
      int w = Math.round(maxW * scale);
      int h = Math.round((lines * lh + Math.max(0, timers.size() - 1) * gap) * scale);
      return new int[]{w, h};
   }

   public static void drawStack(GuiGraphicsExtractor graphics, Font font, List<Timer> timers, int x, int y, float scale, int alpha) {
      int lh = 9;
      int gap = lh / 2;
      int maxW = 0;

      for (Timer t : timers) {
         maxW = Math.max(maxW, font.width(format(t.displayNanos())));
         if (!t.name().isEmpty()) {
            maxW = Math.max(maxW, font.width(t.name()));
         }
      }

      Matrix3x2fStack pose = graphics.pose();
      pose.pushMatrix();
      pose.translate(x, y);
      if (scale != 1.0F) {
         pose.scale(scale);
      }

      int cy = 0;

      for (Timer t : timers) {
         boolean finished = t.state() == Timer.State.FINISHED;
         int blockLines = t.name().isEmpty() ? 1 : 2;
         if (!finished || !t.blinkHidden()) {
            int rgb = finished ? 16733525 : t.color() & 16777215;
            String time = format(t.displayNanos());
            int tx = (maxW - font.width(time)) / 2;
            graphics.text(font, time, tx, cy, alpha << 24 | rgb);
            if (!t.name().isEmpty()) {
               int na = (int)Math.round(alpha * 0.82);
               int nx = (maxW - font.width(t.name())) / 2;
               graphics.text(font, t.name(), nx, cy + lh, na << 24 | 14474460, false);
            }
         }

         cy += blockLines * lh + gap;
      }

      pose.popMatrix();
   }

   private static double clampScale(double v) {
      return HudUtil.clampScale(v);
   }

   private static double clampOpacity(double v) {
      return HudUtil.clampOpacity(v);
   }

   static String format(long nanos) {
      long totalSeconds = nanos / 1000000000L;
      long hours = totalSeconds / 3600L;
      long minutes = totalSeconds % 3600L / 60L;
      long seconds = totalSeconds % 60L;
      return hours > 0L ? String.format("%d:%02d:%02d", hours, minutes, seconds) : String.format("%02d:%02d", minutes, seconds);
   }
}

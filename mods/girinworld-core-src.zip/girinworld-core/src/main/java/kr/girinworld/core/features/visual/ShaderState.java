package kr.girinworld.core.features.visual;

import java.lang.reflect.Method;
import kr.girinworld.core.CoreLog;

public final class ShaderState {
   private static Method getInstance;
   private static Method isInUse;
   private static boolean resolved;
   private static boolean irisPresent;

   private ShaderState() {
   }

   public static boolean shaderPackInUse() {
      try {
         if (!resolve()) {
            return false;
         }

         Object api = getInstance.invoke(null);
         return api != null && (Boolean)isInUse.invoke(api);
      } catch (Throwable t) {
         return false;
      }
   }

   public static boolean irisPresent() {
      resolve();
      return irisPresent;
   }

   private static synchronized boolean resolve() {
      if (resolved) {
         return isInUse != null;
      }

      resolved = true;

      try {
         Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi", false, ShaderState.class.getClassLoader());
         getInstance = api.getMethod("getInstance");
         isInUse = api.getMethod("isShaderPackInUse");
         irisPresent = true;
         CoreLog.info("Iris detected — shader-aware brightness enabled");
      } catch (Throwable t) {
         CoreLog.info("Iris not present (vanilla lightmap path only)");
      }

      return isInUse != null;
   }
}

package kr.girinworld.core;

import net.minecraft.locale.Language;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.util.FormattedCharSequence;

final class InjectedLanguage extends Language {
   private final Language delegate;
   private final String key;
   private final String value;

   InjectedLanguage(Language delegate, String key, String value) {
      this.delegate = delegate;
      this.key = key;
      this.value = value;
   }

   public String getOrDefault(String k, String fallback) {
      return this.key.equals(k) ? this.value : this.delegate.getOrDefault(k, fallback);
   }

   public boolean has(String k) {
      return this.key.equals(k) || this.delegate.has(k);
   }

   public boolean isDefaultRightToLeft() {
      return this.delegate.isDefaultRightToLeft();
   }

   public FormattedCharSequence getVisualOrder(FormattedText text) {
      return this.delegate.getVisualOrder(text);
   }
}

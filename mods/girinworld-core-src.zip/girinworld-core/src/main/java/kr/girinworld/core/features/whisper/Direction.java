package kr.girinworld.core.features.whisper;

public enum Direction {
   INCOMING,
   OUTGOING,
   SYSTEM;
}

package kr.girinworld.core;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.ChatFormatting;
import net.minecraft.world.phys.Vec3;

/**
 * Compatibility bridge for names Mojang changed between 26.1 and 26.2.
 * Resolution by type keeps the core usable even when a named member moves.
 */
public final class ClientCompat {
    private static volatile Method screenSetter;
    private static volatile Field screenField;
    private static volatile Field hideGuiField;
    private static volatile Screen activeCoreScreen;

    private ClientCompat() {}

    public static void setScreen(Minecraft minecraft, Screen screen) {
        if (minecraft == null) return;
        try {
            Method method = screenSetter;
            if (method == null) {
                // 26.2 keeps more than one Minecraft method that accepts a Screen
                // (including the friends overlay). Resolve the actual main-screen
                // setter by its mapped name before considering a structural fallback.
                for (String name : new String[]{
                        "setScreen", "setScreenForNextFrame", "setScreenAndShow",
                        "setScreenForNextTick", "scheduleScreen"}) {
                    try {
                        Method candidate = Minecraft.class.getDeclaredMethod(name, Screen.class);
                        if (candidate.getReturnType() == void.class) {
                            candidate.setAccessible(true);
                            method = candidate;
                            screenSetter = candidate;
                            CoreLog.info("26.2 screen setter resolved: " + candidate.getName());
                            break;
                        }
                    } catch (NoSuchMethodException ignored) {
                    }
                }
            }
            if (method == null) {
                for (Method candidate : Minecraft.class.getDeclaredMethods()) {
                    Class<?>[] parameters = candidate.getParameterTypes();
                    String name = candidate.getName().toLowerCase();
                    if (parameters.length == 1 && Screen.class.isAssignableFrom(parameters[0])
                            && candidate.getReturnType() == void.class
                            && !name.contains("friend") && !name.contains("overlay")
                            && !name.contains("social")) {
                        candidate.setAccessible(true);
                        method = candidate;
                        screenSetter = candidate;
                        CoreLog.info("26.2 screen setter fallback: " + candidate.getName());
                        break;
                    }
                }
            }
            if (method == null) throw new NoSuchMethodException("Minecraft screen setter");
            method.invoke(minecraft, screen);
            activeCoreScreen = screen instanceof CoreScreen ? screen : null;

            if (screen != null) {
                for (Field candidate : Minecraft.class.getDeclaredFields()) {
                    if (!Screen.class.isAssignableFrom(candidate.getType())) continue;
                    candidate.setAccessible(true);
                    if (candidate.get(minecraft) == screen) {
                        screenField = candidate;
                        break;
                    }
                }
            }
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("26.2 화면을 열 수 없습니다", exception);
        }
    }

    public static boolean hasActiveCoreScreen() {
        return activeCoreScreen != null;
    }

    public static void coreScreenRemoved(Screen screen) {
        if (activeCoreScreen == screen) activeCoreScreen = null;
    }

    public static Screen screen(Minecraft minecraft) {
        if (minecraft == null) return null;
        try {
            Screen guiScreen = minecraft.gui.screen();
            if (guiScreen != null) return guiScreen;
        } catch (Throwable ignored) {
        }
        try {
            Field field = screenField;
            if (field != null) {
                Screen current = (Screen) field.get(minecraft);
                if (current != null) return current;
            }

            // 26.2 has more than one Screen-typed field. Do not permanently
            // cache the first null field: while chat is open, find the field
            // that actually contains the active screen.
            for (String name : new String[]{"currentScreen", "screen"}) {
                try {
                    Field candidate = Minecraft.class.getDeclaredField(name);
                    if (Screen.class.isAssignableFrom(candidate.getType())) {
                        candidate.setAccessible(true);
                        Screen current = (Screen) candidate.get(minecraft);
                        if (current != null) {
                            screenField = candidate;
                            return current;
                        }
                    }
                } catch (NoSuchFieldException ignored) {
                }
            }

            for (Field candidate : Minecraft.class.getDeclaredFields()) {
                if (Screen.class.isAssignableFrom(candidate.getType())) {
                    candidate.setAccessible(true);
                    Screen current = (Screen) candidate.get(minecraft);
                    if (current != null) {
                        screenField = candidate;
                        return current;
                    }
                }
            }
            return null;
        } catch (ReflectiveOperationException exception) {
            return null;
        }
    }

    public static boolean hideGui(Options options) {
        if (options == null) return false;
        try {
            Field field = resolveHideGui(options);
            return field != null && field.getBoolean(options);
        } catch (ReflectiveOperationException exception) {
            return false;
        }
    }

    public static void setHideGui(Options options, boolean value) {
        if (options == null) return;
        try {
            Field field = resolveHideGui(options);
            if (field != null) field.setBoolean(options, value);
        } catch (ReflectiveOperationException ignored) {
        }
    }

    private static Field resolveHideGui(Options options) {
        if (hideGuiField != null) return hideGuiField;
        for (String name : new String[]{"hideGui", "hideHud"}) {
            try {
                Field field = options.getClass().getDeclaredField(name);
                field.setAccessible(true);
                hideGuiField = field;
                return field;
            } catch (NoSuchFieldException ignored) {
            }
        }
        return null;
    }

    public static Vec3 cameraPosition(GameRenderer renderer) {
        if (renderer == null) return Vec3.ZERO;
        try {
            for (Method method : renderer.getClass().getMethods()) {
                if (method.getParameterCount() == 0
                        && method.getReturnType().getSimpleName().equals("Camera")) {
                    Object camera = method.invoke(renderer);
                    if (camera == null) continue;
                    for (Method candidate : camera.getClass().getMethods()) {
                        if (candidate.getParameterCount() == 0
                                && Vec3.class.isAssignableFrom(candidate.getReturnType())) {
                            return (Vec3) candidate.invoke(camera);
                        }
                    }
                }
            }
        } catch (ReflectiveOperationException ignored) {
        }
        return Vec3.ZERO;
    }

    public static Integer formattingColor(ChatFormatting formatting) {
        if (formatting == null) return null;
        try {
            for (Method method : ChatFormatting.class.getMethods()) {
                if (method.getParameterCount() == 0
                        && (method.getReturnType() == Integer.class || method.getReturnType() == int.class)
                        && method.getName().toLowerCase().contains("color")) {
                    return (Integer) method.invoke(formatting);
                }
            }
        } catch (ReflectiveOperationException ignored) {
        }
        return null;
    }
}

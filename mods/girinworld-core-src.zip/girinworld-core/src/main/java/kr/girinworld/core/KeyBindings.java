package kr.girinworld.core;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping.Category;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.locale.Language;
import net.minecraft.resources.Identifier;

public final class KeyBindings {
   private static final Identifier CATEGORY_ID = Identifier.fromNamespaceAndPath("core", "client");
   private static final String CATEGORY_LANG_KEY = CATEGORY_ID.toLanguageKey("key.category");
   private static final String CATEGORY_LABEL = "클라이언트 기능";
   private static final int UNBOUND = InputConstants.UNKNOWN.getValue();
   private static final int GLFW_KEY_C = 67;
   private static final int GLFW_KEY_RIGHT_SHIFT = 344;
   private static final int GLFW_KEY_Z = 90;
   private static final KeyBindings.Bind QUICKMENU = new KeyBindings.Bind("quickmenu", "퀵메뉴 열기", 67, c -> c.keys.quickmenu, (c, v) -> c.keys.quickmenu = v);
   private static final KeyBindings.Bind SETTINGS = new KeyBindings.Bind("settings", "클라이언트 허브", 344, c -> c.keys.settings, (c, v) -> c.keys.settings = v);
   private static final KeyBindings.Bind CAMERA = new KeyBindings.Bind("camera", "프리뷰 카메라", UNBOUND, c -> c.keys.photoToggle, (c, v) -> c.keys.photoToggle = v);
   private static final KeyBindings.Bind CALC = new KeyBindings.Bind("calc", "계산기 열기", UNBOUND, c -> c.keys.calc, (c, v) -> c.keys.calc = v);
   private static final KeyBindings.Bind TIMER = new KeyBindings.Bind("timer", "타이머 열기", UNBOUND, c -> c.keys.timer, (c, v) -> c.keys.timer = v);
   private static final KeyBindings.Bind WHISPER = new KeyBindings.Bind("whisper", "귓속말 열기", UNBOUND, c -> c.keys.whisper, (c, v) -> c.keys.whisper = v);
   private static final KeyBindings.Bind MACRO = new KeyBindings.Bind("macro", "단축어 열기", UNBOUND, c -> c.keys.macro, (c, v) -> c.keys.macro = v);
   private static final KeyBindings.Bind TIMER_RECENT = new KeyBindings.Bind(
      "timer_recent", "최근 타이머 시작", UNBOUND, c -> c.keys.timerRecent, (c, v) -> c.keys.timerRecent = v
   );
   private static final KeyBindings.Bind AUTOSPRINT = new KeyBindings.Bind(
      "autosprint", "자동 달리기 토글", UNBOUND, c -> c.keys.autoSprint, (c, v) -> c.keys.autoSprint = v
   );
   private static final KeyBindings.Bind BRIGHTNESS = new KeyBindings.Bind(
      "brightness", "밝기 조절 토글", UNBOUND, c -> c.keys.brightness, (c, v) -> c.keys.brightness = v
   );
   private static final KeyBindings.Bind INV_HOLD = new KeyBindings.Bind(
      "inventory", "인벤토리 HUD (홀드)", UNBOUND, c -> c.keys.invHold, (c, v) -> c.keys.invHold = v
   );
   private static final KeyBindings.Bind TIME_PRESET = new KeyBindings.Bind(
      "time", "시간 프리셋 순환", UNBOUND, c -> c.keys.timePreset, (c, v) -> c.keys.timePreset = v
   );
   private static final KeyBindings.Bind ZOOM = new KeyBindings.Bind("zoom", "줌 (홀드)", 90, c -> c.keys.zoom, (c, v) -> c.keys.zoom = v);
   private static final KeyBindings.Bind[] ALL = new KeyBindings.Bind[]{
      QUICKMENU, SETTINGS, CAMERA, CALC, TIMER, TIMER_RECENT, WHISPER, MACRO, AUTOSPRINT, BRIGHTNESS, INV_HOLD, TIME_PRESET, ZOOM
   };
   private static Category category;
   private static boolean registered = false;
   private static final long POLL_NANOS = 2000000000L;
   private static long lastPoll;

   private KeyBindings() {
   }

   public static void tick(Minecraft mc) {
      try {
         if (!registered) {
            register(mc);
            return;
         }

         boolean screenOpen = kr.girinworld.core.ClientCompat.screen(mc) != null;
         long now = System.nanoTime();
         if (!screenOpen && now - lastPoll < 2000000000L) {
            return;
         }

         lastPoll = now;
         if (!Language.getInstance().has(CATEGORY_LANG_KEY)) {
            injectCategoryLabel();
         }

         for (KeyBindings.Bind b : ALL) {
            if (b.mapping != null) {
               String s = b.mapping.saveString();
               if (!s.equals(b.lastSave)) {
                  b.lastSave = s;
                  Config c = Config.get();
                  b.write.accept(c, s);
                  c.save();
                  Hooks.invalidateKeyCaches();
               }
            }
         }
      } catch (Throwable t) {
         CoreLog.error("KeyBindings.tick failed", t);
      }
   }

   private static void register(Minecraft mc) {
      registered = true;

      try {
         Category cat = ensureCategory();

         for (KeyBindings.Bind b : ALL) {
            b.mapping = new KeyMapping(b.label, b.defaultKey, cat);
            applySaved(b.mapping, b.read.apply(Config.get()));
            b.lastSave = b.mapping.saveString();
         }

         Field field = mc.options.getClass().getField("keyMappings");
         field.setAccessible(true);
         KeyMapping[] current = (KeyMapping[])field.get(mc.options);
         KeyMapping[] extended = Arrays.copyOf(current, current.length + ALL.length);

         for (int i = 0; i < ALL.length; i++) {
            extended[current.length + i] = ALL[i].mapping;
         }

         field.set(mc.options, extended);
         CoreLog.info("key bindings registered in vanilla controls (" + ALL.length + " binds)");
      } catch (Throwable t) {
         for (KeyBindings.Bind b : ALL) {
            b.mapping = null;
         }

         CoreLog.error("key binding registration failed; falling back to config keys", t);
      }
   }

   private static Category ensureCategory() {
      if (category != null) {
         return category;
      }

      try {
         category = Category.register(CATEGORY_ID);
         injectCategoryLabel();
      } catch (Throwable t) {
         CoreLog.error("custom key category registration failed, falling back to MISC", t);
         category = Category.MISC;
      }

      return category;
   }

   private static void injectCategoryLabel() {
      try {
         Language current = Language.getInstance();
         if (current instanceof InjectedLanguage) {
            return;
         }

         Language.inject(new InjectedLanguage(current, CATEGORY_LANG_KEY, "클라이언트 기능"));
      } catch (Throwable t) {
         CoreLog.error("category label injection failed", t);
      }
   }

   private static void applySaved(KeyMapping mapping, String saved) {
      try {
         if (saved != null && !saved.isBlank()) {
            mapping.setKey(InputConstants.getKey(saved));
         }
      } catch (Throwable var3) {
      }
   }

   public static boolean matchesQuickmenu(KeyEvent event) {
      return QUICKMENU.mapping != null ? matchesKey(QUICKMENU.id, event) : event.key() == Hooks.quickmenuGlfwKey();
   }

   public static boolean matchesSettings(KeyEvent event) {
      if (SETTINGS.mapping != null) {
         return matchesKey(SETTINGS.id, event);
      }

      try {
         return event.key() == InputConstants.getKey(Config.get().keys.settings).getValue();
      } catch (Throwable t) {
         return event.key() == 344;
      }
   }

   public static boolean matchesPhotoToggle(KeyEvent event) {
      return matchesKey(CAMERA.id, event);
   }

   public static boolean matchesCalc(KeyEvent event) {
      return matchesKey(CALC.id, event);
   }

   public static boolean matchesTimer(KeyEvent event) {
      return matchesKey(TIMER.id, event);
   }

   public static boolean matchesWhisper(KeyEvent event) {
      return matchesKey(WHISPER.id, event);
   }

   public static boolean matchesTimerRecent(KeyEvent event) {
      return matchesKey(TIMER_RECENT.id, event);
   }

   public static boolean matchesMacro(KeyEvent event) {
      return matchesKey(MACRO.id, event);
   }

   public static boolean matchesAutoSprint(KeyEvent event) {
      return matchesKey(AUTOSPRINT.id, event);
   }

   public static boolean matchesBrightness(KeyEvent event) {
      return matchesKey(BRIGHTNESS.id, event);
   }

   public static boolean matchesTimePreset(KeyEvent event) {
      return matchesKey(TIME_PRESET.id, event);
   }

   public static boolean invHoldActive() {
      KeyMapping m = INV_HOLD.mapping;
      return m != null && !m.isUnbound() ? m.isDown() : true;
   }

   private static KeyBindings.Bind find(String id) {
      for (KeyBindings.Bind b : ALL) {
         if (b.id.equals(id)) {
            return b;
         }
      }

      return null;
   }

   public static boolean assignable(String id) {
      KeyBindings.Bind b = find(id);
      return b != null && b.mapping != null;
   }

   public static boolean matchesKey(String id, KeyEvent event) {
      KeyBindings.Bind b = find(id);
      return b != null && b.mapping != null && event != null ? b.mapping.matches(event) : false;
   }

   public static boolean matchesMouse(String id, MouseButtonInfo info) {
      KeyBindings.Bind b = find(id);
      if (b != null && b.mapping != null && info != null) {
         String want = b.mapping.saveString();
         if (want != null && want.startsWith("key.mouse.")) {
            String got = Type.MOUSE.getOrCreate(info.button()).getName();
            return want.equals(got);
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static String displayOf(String id) {
      KeyBindings.Bind b = find(id);
      return b == null ? "" : keyName(b.read.apply(Config.get()));
   }

   public static String keyName(String cfg) {
      if (cfg == null || cfg.contains("unknown")) {
         return "미지정";
      }

      if (cfg.startsWith("key.mouse.")) {
         String b = cfg.substring("key.mouse.".length());

         return switch (b) {
            case "left" -> "마우스 좌클릭";
            case "right" -> "마우스 우클릭";
            case "middle" -> "마우스 휠클릭";
            default -> "마우스 " + b;
         };
      } else {
         return cfg.replace("key.keyboard.", "").replace('.', ' ').toUpperCase();
      }
   }

   public static boolean assign(String id, Key key) {
      KeyBindings.Bind b = find(id);
      if (b != null && b.mapping != null && key != null) {
         try {
            b.mapping.setKey(key);
            KeyMapping.resetMapping();
            String saved = b.mapping.saveString();
            Config c = Config.get();
            b.write.accept(c, saved);
            b.lastSave = saved;
            c.save();
            Hooks.invalidateKeyCaches();
            CoreLog.info("key assigned: " + b.id + " -> " + saved);
            return true;
         } catch (Throwable t) {
            CoreLog.error("key assign failed: " + id, t);
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean unbind(String id) {
      return assign(id, InputConstants.UNKNOWN);
   }

   public static boolean resetToDefault(String id) {
      KeyBindings.Bind b = find(id);
      return b != null && b.mapping != null && assign(id, b.mapping.getDefaultKey());
   }

   public static String conflictLabel(String id, Key key) {
      if (key != null && !key.equals(InputConstants.UNKNOWN)) {
         KeyBindings.Bind self = find(id);
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.options != null) {
            try {
               for (KeyMapping m : mc.options.keyMappings) {
                  if (m != null && (self == null || m != self.mapping) && key.getName().equals(m.saveString())) {
                     return Language.getInstance().getOrDefault(m.getName());
                  }
               }
            } catch (Throwable var8) {
            }

            return null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   public static void reapply() {
      for (KeyBindings.Bind b : ALL) {
         if (b.mapping != null) {
            applySaved(b.mapping, b.read.apply(Config.get()));
            b.lastSave = b.mapping.saveString();
         }
      }
   }

   private static final class Bind {
      final String id;
      final String label;
      final int defaultKey;
      final Function<Config, String> read;
      final BiConsumer<Config, String> write;
      KeyMapping mapping;
      String lastSave = "";

      Bind(String id, String label, int defaultKey, Function<Config, String> read, BiConsumer<Config, String> write) {
         this.id = id;
         this.label = label;
         this.defaultKey = defaultKey;
         this.read = read;
         this.write = write;
      }
   }
}

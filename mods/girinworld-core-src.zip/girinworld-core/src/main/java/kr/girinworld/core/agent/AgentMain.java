package kr.girinworld.core.agent;

import java.lang.instrument.Instrumentation;
import kr.girinworld.core.CoreLog;

public final class AgentMain {
   private AgentMain() {
   }

   public static void premain(String args, Instrumentation inst) {
      try {
         CoreLog.init();
         CoreLog.info("agent starting (ClientCore 0.2.0, target MC 26.2)");
         inst.addTransformer(new CoreTransformer());
         CoreLog.info("agent loaded - targets (H1~H13,H15; 실제 주입은 transformed 로그 참조)");
         scheduleBootReport();
      } catch (Throwable var5) {
         Throwable t = var5;

         try {
            CoreLog.error("premain failed; continuing vanilla", t);
         } catch (Throwable var4) {
         }

         System.err.println("[ClientCore] premain failed: " + var5);
      }
   }

   private static void scheduleBootReport() {
      Thread t = new Thread(() -> {
         try {
            Thread.sleep(20000L);
            CoreTransformer.logBootReport();
         } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
         } catch (Throwable var2) {
         }
      }, "core-boot-report");
      t.setDaemon(true);
      t.start();
   }
}

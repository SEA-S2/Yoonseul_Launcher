package kr.girinworld.core.features.timer;

import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import java.io.BufferedInputStream;
import java.io.InputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public final class TimerSound {
   private static final long REPLAY_GAP_NANOS = 1_000_000_000L;
   private static volatile long nextAllowedNanos;

   private TimerSound() {
   }

   public static void playFinish() {
      try {
         Config.Timer cfg = Config.get().timer;
         if (!cfg.sound || cfg.alarmVolume <= 0.0) {
            return;
         }

         long now = System.nanoTime();
         if (now < nextAllowedNanos) return;

         float volume = (float)Math.min(1.0, cfg.alarmVolume);
         long durationNanos = playCustom(volume);
         if (durationNanos > 0L) {
            nextAllowedNanos = now + durationNanos + REPLAY_GAP_NANOS;
         } else {
            nextAllowedNanos = now + REPLAY_GAP_NANOS;
            playFallback(volume);
         }
      } catch (Throwable t) {
         CoreLog.error("timer finish sound failed", t);
      }
   }

   private static long playCustom(float volume) {
      InputStream raw = null;
      Object audio = null;
      Object clip = null;
      try {
         raw = TimerSound.class.getResourceAsStream("timer_alarm.wav");
         if (raw == null) return 0L;

         // Keep javax.sound classes out of this class's constant pool. The core
         // is preloaded as a Java agent before the desktop audio module is ready;
         // resolving those types during preload can terminate Minecraft. They
         // are loaded reflectively only when a timer actually finishes.
         Class<?> audioSystemClass = Class.forName("javax.sound.sampled.AudioSystem");
         Class<?> audioInputClass = Class.forName("javax.sound.sampled.AudioInputStream");
         Class<?> clipClass = Class.forName("javax.sound.sampled.Clip");
         Class<?> controlTypeClass = Class.forName("javax.sound.sampled.Control$Type");
         Class<?> floatControlClass = Class.forName("javax.sound.sampled.FloatControl");
         Class<?> floatControlTypeClass = Class.forName("javax.sound.sampled.FloatControl$Type");

         audio = audioSystemClass.getMethod("getAudioInputStream", InputStream.class)
                 .invoke(null, new BufferedInputStream(raw));
         clip = audioSystemClass.getMethod("getClip").invoke(null);
         clipClass.getMethod("open", audioInputClass).invoke(clip, audio);

         Object gainType = floatControlTypeClass.getField("MASTER_GAIN").get(null);
         boolean supported = (Boolean) clipClass.getMethod("isControlSupported", controlTypeClass)
                 .invoke(clip, gainType);
         if (supported) {
            Object gain = clipClass.getMethod("getControl", controlTypeClass).invoke(clip, gainType);
            float minimum = (Float) floatControlClass.getMethod("getMinimum").invoke(gain);
            float maximum = (Float) floatControlClass.getMethod("getMaximum").invoke(gain);
            float db = volume <= 0.0F ? minimum : (float)(20.0 * Math.log10(volume));
            floatControlClass.getMethod("setValue", float.class)
                    .invoke(gain, Math.max(minimum, Math.min(maximum, db)));
         }

         long durationMicros = (Long) clipClass.getMethod("getMicrosecondLength").invoke(clip);
         clipClass.getMethod("start").invoke(clip);
         final Object openedClip = clip;
         final Object openedAudio = audio;
         Thread cleanup = new Thread(() -> {
            try {
               Thread.sleep(Math.max(500L, durationMicros / 1000L + 250L));
               clipClass.getMethod("close").invoke(openedClip);
               ((AutoCloseable) openedAudio).close();
            } catch (Throwable ignored) {
            }
         }, "girinworld-timer-sound-cleanup");
         cleanup.setDaemon(true);
         cleanup.start();
         return durationMicros * 1000L;
      } catch (Throwable t) {
         CoreLog.error("custom timer sound failed; using bell", t);
         try { if (clip != null) clip.getClass().getMethod("close").invoke(clip); } catch (Throwable ignored) {}
         try { if (audio instanceof AutoCloseable c) c.close(); } catch (Throwable ignored) {}
         try { if (raw != null) raw.close(); } catch (Throwable ignored) {}
         return 0L;
      }
   }

   private static void playFallback(float volume) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null) {
         mc.getSoundManager().play(SimpleSoundInstance.forUI((SoundEvent)SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, volume));
      }
   }
}

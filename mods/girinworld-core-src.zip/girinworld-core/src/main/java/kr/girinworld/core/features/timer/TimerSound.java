package kr.girinworld.core.features.timer;

import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import java.io.BufferedInputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public final class TimerSound {
   private TimerSound() {
   }

   public static void playFinish() {
      try {
         Config.Timer cfg = Config.get().timer;
         if (!cfg.sound || cfg.alarmVolume <= 0.0) {
            return;
         }

         float volume = (float)Math.min(1.0, cfg.alarmVolume);
         if (!playCustom(volume)) {
            playFallback(volume);
         }
      } catch (Throwable t) {
         CoreLog.error("timer finish sound failed", t);
      }
   }

   private static boolean playCustom(float volume) {
      try {
         var raw = TimerSound.class.getResourceAsStream("timer_alarm.wav");
         if (raw == null) return false;
         AudioInputStream in = AudioSystem.getAudioInputStream(new BufferedInputStream(raw));
         Clip clip = AudioSystem.getClip();
         clip.open(in);
         if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
            FloatControl gain = (FloatControl)clip.getControl(FloatControl.Type.MASTER_GAIN);
            float db = volume <= 0.0F ? gain.getMinimum() : (float)(20.0 * Math.log10(volume));
            gain.setValue(Math.max(gain.getMinimum(), Math.min(gain.getMaximum(), db)));
         }
         clip.addLineListener(event -> {
            if (event.getType() == javax.sound.sampled.LineEvent.Type.STOP) {
               clip.close();
               try { in.close(); } catch (Exception ignored) {}
            }
         });
         clip.start();
         return true;
      } catch (Throwable t) {
         CoreLog.error("custom timer sound failed; using bell", t);
         return false;
      }
   }

   private static void playFallback(float volume) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null) {
         mc.getSoundManager().play(SimpleSoundInstance.forUI((SoundEvent)SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, volume));
      }
   }
}

package kr.girinworld.core.features.timer;

import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public final class TimerSound {
   private TimerSound() {
   }

   public static void playFinish() {
      try {
         Config.Timer cfg = Config.get().timer;
         if (!cfg.sound || cfg.alarmVolume <= 0.0) {
            return;
         }

         Minecraft mc = Minecraft.getInstance();
         if (mc == null) {
            return;
         }

         float volume = (float)Math.min(1.0, cfg.alarmVolume);
         mc.getSoundManager().play(SimpleSoundInstance.forUI((SoundEvent)SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, volume));
      } catch (Throwable t) {
         CoreLog.error("timer finish sound failed", t);
      }
   }
}

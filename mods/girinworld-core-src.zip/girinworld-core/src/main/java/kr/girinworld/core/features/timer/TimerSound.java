package kr.girinworld.core.features.timer;

import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public final class TimerSound {
   private TimerSound() {
   }

   public static void playFinish() {
      try {
         Config.Timer cfg = Config.get().timer;
         if (!cfg.sound || cfg.alarmVolume <= 0.0) {
            return;
         }

         playCustom((float)Math.min(1.0, cfg.alarmVolume));
      } catch (Throwable t) {
         CoreLog.error("timer finish sound failed", t);
      }
   }

   private static void playCustom(float volume) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null) {
         try {
            Identifier id = Identifier.fromNamespaceAndPath("girinworld", "timer_alarm");
            SoundEvent event = SoundEvent.createVariableRangeEvent(id);
            mc.getSoundManager().play(SimpleSoundInstance.forUI(event, 1.0F, volume));
         } catch (Throwable t) {
            CoreLog.error("custom timer sound failed; using bell", t);
            mc.getSoundManager().play(SimpleSoundInstance.forUI((SoundEvent)SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, volume));
         }
      }
   }
}

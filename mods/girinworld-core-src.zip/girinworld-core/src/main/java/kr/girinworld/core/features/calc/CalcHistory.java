package kr.girinworld.core.features.calc;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public final class CalcHistory {
   private static final int MAX = 5;
   private static final CalcHistory INSTANCE = new CalcHistory();
   private final Deque<CalcHistory.Entry> entries = new ArrayDeque<>();

   private CalcHistory() {
   }

   public static CalcHistory get() {
      return INSTANCE;
   }

   public void add(String expression, String result) {
      this.entries.addFirst(new CalcHistory.Entry(expression, result));

      while (this.entries.size() > 5) {
         this.entries.removeLast();
      }
   }

   public List<CalcHistory.Entry> recent() {
      return new ArrayList<>(this.entries);
   }

   public record Entry(String expression, String result) {
   }
}

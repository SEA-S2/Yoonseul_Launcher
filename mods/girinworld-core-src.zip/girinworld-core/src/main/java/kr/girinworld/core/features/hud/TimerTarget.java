package kr.girinworld.core.features.hud;

import kr.girinworld.core.Config;
import kr.girinworld.core.features.timer.TimerHud;
import kr.girinworld.core.features.timer.TimerManager;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import org.joml.Matrix3x2fStack;

final class TimerTarget implements HudTarget {
   @Override
   public String label() {
      return "타이머";
   }

   private boolean idle() {
      return TimerManager.timers().isEmpty();
   }

   @Override
   public String moduleId() {
      return "timer";
   }

   @Override
   public boolean enabled() {
      return Config.get().timer.hudEnabled;
   }

   @Override
   public void setEnabled(boolean on) {
      Config.get().timer.hudEnabled = on;
   }

   @Override
   public int[] size(Font font) {
      float s = TimerHud.effectiveScale();
      return this.idle() ? new int[]{Math.round(font.width(this.label()) * s), Math.round(9.0F * s)} : TimerHud.contentSize(font, TimerManager.timers(), s);
   }

   @Override
   public void draw(GuiGraphicsExtractor graphics, Font font, int x, int y) {
      float s = TimerHud.effectiveScale();
      if (!this.idle()) {
         TimerHud.drawStack(graphics, font, TimerManager.timers(), x, y, s, TimerHud.alpha());
      } else {
         Matrix3x2fStack pose = graphics.pose();
         pose.pushMatrix();
         pose.translate(x, y);
         if (s != 1.0F) {
            pose.scale(s);
         }

         graphics.text(font, this.label(), 0, 0, TimerHud.alpha() << 24 | 16777215);
         pose.popMatrix();
      }
   }

   @Override
   public double x() {
      return Config.get().timer.hudX;
   }

   @Override
   public double y() {
      return Config.get().timer.hudY;
   }

   @Override
   public void setPos(double x, double y) {
      Config c = Config.get();
      c.timer.hudX = x;
      c.timer.hudY = y;
   }

   @Override
   public double scale() {
      return Config.get().timer.hudScale;
   }

   @Override
   public void setScale(double scale) {
      Config.get().timer.hudScale = HudUtil.clampScale(scale);
   }

   @Override
   public void resetLayout() {
      Config.Timer def = new Config.Timer();
      Config.Timer cfg = Config.get().timer;
      cfg.hudX = def.hudX;
      cfg.hudY = def.hudY;
      cfg.hudScale = def.hudScale;
      cfg.hudOpacity = def.hudOpacity;
   }
}

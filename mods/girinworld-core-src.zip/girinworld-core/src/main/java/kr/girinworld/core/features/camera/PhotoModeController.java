package kr.girinworld.core.features.camera;

import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;

public final class PhotoModeController {
   private static final float PITCH_LIMIT = 89.9F;
   private static final float SENSITIVITY = 0.15F;
   private static final float MIN_ORBIT = 1.0F;
   private static final float MAX_ORBIT = 15.0F;
   private static volatile boolean active = false;
   private static volatile float camYaw = 0.0F;
   private static volatile float camPitch = 0.0F;
   private static volatile float orbitDistance = 4.0F;
   private static volatile boolean gridlines = false;
   private static CameraType savedCameraType = CameraType.FIRST_PERSON;
   private static boolean savedHideGui = false;

   private PhotoModeController() {
   }

   public static boolean isActive() {
      return active;
   }

   public static float camYaw() {
      return camYaw;
   }

   public static float camPitch() {
      return camPitch;
   }

   public static float orbitDistance() {
      return orbitDistance;
   }

   public static boolean isGridlines() {
      return gridlines;
   }

   public static void toggleGridlines() {
      gridlines = !gridlines;
   }

   public static void toggle() {
      if (active) {
         exit();
      } else {
         enter();
      }
   }

   public static void setActive(boolean on) {
      if (on != active) {
         toggle();
      }
   }

   private static void enter() {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.player != null && mc.level != null) {
         if (!mc.player.isSpectator()) {
            camYaw = mc.player.getYRot();
            camPitch = mc.player.getXRot();
            orbitDistance = 4.0F;
            Options options = mc.options;
            savedCameraType = options.getCameraType();
            options.setCameraType(CameraType.THIRD_PERSON_BACK);
            savedHideGui = kr.girinworld.core.ClientCompat.hideGui(options);
            kr.girinworld.core.ClientCompat.setHideGui(options, true);
            gridlines = Config.get().photo.gridlinesDefault;
            active = true;
            CoreLog.info("photo mode ON (yaw=" + camYaw + " pitch=" + camPitch + ")");
         }
      }
   }

   private static void exit() {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null) {
         Options options = mc.options;
         options.setCameraType(savedCameraType);
         kr.girinworld.core.ClientCompat.setHideGui(options, savedHideGui);
      }

      active = false;
      CoreLog.info("photo mode OFF");
   }

   public static void applyMouseDelta(double dx, double dy) {
      camYaw += (float)(dx * 0.15F);
      float p = camPitch + (float)(dy * 0.15F);
      camPitch = Math.max(-89.9F, Math.min(89.9F, p));
   }

   public static boolean onScroll(double yScroll) {
      if (!active) {
         return false;
      }

      float d = orbitDistance - (float)yScroll;
      orbitDistance = Math.max(1.0F, Math.min(15.0F, d));
      return true;
   }

   public static void tick() {
      if (active) {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null && mc.player != null) {
            LocalPlayer player = mc.player;
            if (player.isSpectator()) {
               exit();
            }
         } else {
            exit();
         }
      }
   }
}

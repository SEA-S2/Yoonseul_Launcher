package kr.girinworld.core.features.hud;

public final class CpsCounter {
   private static final long WINDOW_NANOS = 1000000000L;
   private static final int CAP = 64;
   private static final long[][] TIMES = new long[][]{new long[64], new long[64]};
   private static final int[] NEXT = new int[2];

   private CpsCounter() {
   }

   public static void onClick(int button) {
      if (button >= 0 && button <= 1) {
         TIMES[button][NEXT[button]] = System.nanoTime();
         NEXT[button] = (NEXT[button] + 1) % 64;
      }
   }

   public static int cps(int button) {
      if (button >= 0 && button <= 1) {
         long cutoff = System.nanoTime() - 1000000000L;
         int n = 0;

         for (long t : TIMES[button]) {
            if (t > cutoff) {
               n++;
            }
         }

         return n;
      } else {
         return 0;
      }
   }
}

package kr.girinworld.core.features.calc;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public final class CalcEngine {
   private static final MathContext MC = new MathContext(16);

   private CalcEngine() {
   }

   public static CalcResult evaluate(String input) {
      try {
         List<CalcEngine.Token> tokens = tokenize(input == null ? "" : input.replace(",", ""));
         if (tokens.isEmpty()) {
            return CalcResult.error("빈 수식입니다.");
         }

         List<CalcEngine.Token> rpn = toRpn(tokens);
         return CalcResult.ok(evalRpn(rpn));
      } catch (CalcEngine.CalcException e) {
         return CalcResult.error(e.getMessage());
      }
   }

   private static List<CalcEngine.Token> tokenize(String input) {
      List<CalcEngine.Token> out = new ArrayList<>();
      int i = 0;
      int n = input.length();

      while (i < n) {
         char c = input.charAt(i);
         if (Character.isWhitespace(c)) {
            i++;
         } else if (c == '(') {
            out.add(new CalcEngine.Token(CalcEngine.Type.LPAREN));
            i++;
         } else if (c == ')') {
            out.add(new CalcEngine.Token(CalcEngine.Type.RPAREN));
            i++;
         } else if (c == '+') {
            out.add(new CalcEngine.Token(CalcEngine.Type.PLUS));
            i++;
         } else if (c == '-') {
            out.add(new CalcEngine.Token(CalcEngine.Type.MINUS));
            i++;
         } else if (c == '*') {
            out.add(new CalcEngine.Token(CalcEngine.Type.MUL));
            i++;
         } else if (c == '/') {
            out.add(new CalcEngine.Token(CalcEngine.Type.DIV));
            i++;
         } else if (c == '%') {
            out.add(new CalcEngine.Token(CalcEngine.Type.MOD));
            i++;
         } else {
            if (c != '.' && !Character.isDigit(c)) {
               throw new CalcEngine.CalcException("알 수 없는 문자: '" + c + "'");
            }

            i = readNumber(input, i, out);
         }
      }

      return out;
   }

   private static int readNumber(String input, int start, List<CalcEngine.Token> out) {
      int i = start;
      int n = input.length();
      boolean seenDot = false;

      while (i < n) {
         char d = input.charAt(i);
         if (Character.isDigit(d)) {
            i++;
         } else {
            if (d != '.') {
               break;
            }

            if (seenDot) {
               throw new CalcEngine.CalcException("숫자에 소수점이 두 개 있습니다.");
            }

            seenDot = true;
            i++;
         }
      }

      String numStr = input.substring(start, i);
      if (numStr.equals(".")) {
         throw new CalcEngine.CalcException("잘못된 숫자: '.'");
      }

      BigDecimal value;
      try {
         value = new BigDecimal(numStr);
      } catch (NumberFormatException e) {
         throw new CalcEngine.CalcException("잘못된 숫자: " + numStr);
      }

      if (i < n) {
         BigDecimal mult = suffixMultiplier(input.charAt(i));
         if (mult != null) {
            value = value.multiply(mult);
            i++;
         }
      }

      out.add(new CalcEngine.Token(CalcEngine.Type.NUM, value));
      return i;
   }

   private static BigDecimal suffixMultiplier(char c) {
      return switch (Character.toLowerCase(c)) {
         case 'b' -> new BigDecimal("1000000000");
         case 'k' -> new BigDecimal("1000");
         case 'm' -> new BigDecimal("1000000");
         default -> null;
      };
   }

   private static List<CalcEngine.Token> toRpn(List<CalcEngine.Token> tokens) {
      List<CalcEngine.Token> output = new ArrayList<>();
      Deque<CalcEngine.Token> ops = new ArrayDeque<>();
      boolean expectOperand = true;

      for (CalcEngine.Token t : tokens) {
         switch (t.type) {
            case NUM:
               if (!expectOperand) {
                  throw new CalcEngine.CalcException("연산자가 필요합니다.");
               }

               output.add(t);
               expectOperand = false;
               break;
            case PLUS:
            case MINUS:
            case MUL:
            case DIV:
            case MOD:
               CalcEngine.Type opType = t.type;
               if (expectOperand) {
                  if (opType != CalcEngine.Type.MINUS) {
                     throw new CalcEngine.CalcException("피연산자가 필요합니다.");
                  }

                  opType = CalcEngine.Type.UMINUS;
               }

               CalcEngine.Token op = new CalcEngine.Token(opType);

               while (!ops.isEmpty() && ops.peek().type != CalcEngine.Type.LPAREN && shouldPop(op.type, ops.peek().type)) {
                  output.add(ops.pop());
               }

               ops.push(op);
               expectOperand = true;
               break;
            case UMINUS:
            default:
               throw new CalcEngine.CalcException("내부 오류: " + t.type);
            case LPAREN:
               if (!expectOperand) {
                  throw new CalcEngine.CalcException("'(' 앞에 연산자가 필요합니다.");
               }

               ops.push(t);
               expectOperand = true;
               break;
            case RPAREN:
               if (expectOperand) {
                  throw new CalcEngine.CalcException("')' 앞에 피연산자가 없습니다.");
               }

               boolean matched = false;

               while (true) {
                  if (!ops.isEmpty()) {
                     if (ops.peek().type != CalcEngine.Type.LPAREN) {
                        output.add(ops.pop());
                        continue;
                     }

                     matched = true;
                  }

                  if (!matched) {
                     throw new CalcEngine.CalcException("괄호가 맞지 않습니다.");
                  }

                  ops.pop();
                  expectOperand = false;
                  break;
               }
         }
      }

      if (expectOperand) {
         throw new CalcEngine.CalcException("수식이 완성되지 않았습니다.");
      }

      while (!ops.isEmpty()) {
         CalcEngine.Token top = ops.pop();
         if (top.type == CalcEngine.Type.LPAREN) {
            throw new CalcEngine.CalcException("괄호가 맞지 않습니다.");
         }

         output.add(top);
      }

      return output;
   }

   private static int precedence(CalcEngine.Type t) {
      return switch (t) {
         case PLUS, MINUS -> 2;
         case MUL, DIV, MOD -> 3;
         case UMINUS -> 4;
         default -> 0;
      };
   }

   private static boolean shouldPop(CalcEngine.Type incoming, CalcEngine.Type top) {
      int pi = precedence(incoming);
      int pt = precedence(top);
      boolean rightAssociative = incoming == CalcEngine.Type.UMINUS;
      return rightAssociative ? pt > pi : pt >= pi;
   }

   private static BigDecimal evalRpn(List<CalcEngine.Token> rpn) {
      Deque<BigDecimal> stack = new ArrayDeque<>();

      for (CalcEngine.Token t : rpn) {
         switch (t.type) {
            case NUM:
               stack.push(t.value);
               break;
            case PLUS:
            case MINUS:
            case MUL:
            case DIV:
            case MOD:
               if (stack.size() < 2) {
                  throw new CalcEngine.CalcException("수식 오류");
               }

               BigDecimal b = stack.pop();
               BigDecimal a = stack.pop();
               stack.push(apply(t.type, a, b));
               break;
            case UMINUS:
               if (stack.isEmpty()) {
                  throw new CalcEngine.CalcException("수식 오류");
               }

               stack.push(stack.pop().negate());
               break;
            default:
               throw new CalcEngine.CalcException("내부 오류: " + t.type);
         }
      }

      if (stack.size() != 1) {
         throw new CalcEngine.CalcException("수식 오류");
      } else {
         return stack.pop();
      }
   }

   private static BigDecimal apply(CalcEngine.Type op, BigDecimal a, BigDecimal b) {
      return switch (op) {
         case PLUS -> a.add(b);
         case MINUS -> a.subtract(b);
         case MUL -> a.multiply(b);
         case DIV -> {
            if (b.signum() == 0) {
               throw new CalcEngine.CalcException("0으로 나눌 수 없습니다.");
            }

            yield a.divide(b, MC);
         }
         case MOD -> {
            if (b.signum() == 0) {
               throw new CalcEngine.CalcException("0으로 나눌 수 없습니다.");
            }

            yield a.remainder(b, MC);
         }
         default -> throw new CalcEngine.CalcException("내부 오류: " + op);
      };
   }

   private static final class CalcException extends RuntimeException {
      CalcException(String message) {
         super(message);
      }
   }

   private static final class Token {
      final CalcEngine.Type type;
      final BigDecimal value;

      Token(CalcEngine.Type type, BigDecimal value) {
         this.type = type;
         this.value = value;
      }

      Token(CalcEngine.Type type) {
         this(type, null);
      }
   }

   private enum Type {
      NUM,
      PLUS,
      MINUS,
      MUL,
      DIV,
      MOD,
      UMINUS,
      LPAREN,
      RPAREN;
   }
}

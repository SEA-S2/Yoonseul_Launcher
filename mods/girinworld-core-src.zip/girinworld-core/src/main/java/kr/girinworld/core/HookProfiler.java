package kr.girinworld.core;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class HookProfiler {
   public static final boolean ON = resolveEnabled();
   private static final long REPORT_NANOS = 5000000000L;
   private static final Map<String, HookProfiler.Stat> STATS = new ConcurrentHashMap<>();
   private static volatile boolean reporterStarted;

   private static boolean resolveEnabled() {
      if (Boolean.getBoolean("girinworld.profile")) {
         return true;
      }

      try {
         return Config.get().debug.profile;
      } catch (Throwable t) {
         return false;
      }
   }

   private HookProfiler() {
   }

   public static long start() {
      return ON ? System.nanoTime() : 0L;
   }

   public static void end(String name, long t0) {
      if (ON && t0 != 0L) {
         long dt = System.nanoTime() - t0;
         HookProfiler.Stat s = STATS.computeIfAbsent(name, k -> new HookProfiler.Stat());
         s.calls++;
         s.total += dt;
         if (dt > s.max) {
            s.max = dt;
         }

         ensureReporter();
      }
   }

   private static synchronized void ensureReporter() {
      if (!reporterStarted) {
         reporterStarted = true;
         Thread t = new Thread(() -> {
            while (true) {
               try {
                  Thread.sleep(5000L);
                  report();
               } catch (InterruptedException e) {
                  Thread.currentThread().interrupt();
                  return;
               } catch (Throwable var2) {
               }
            }
         }, "core-profiler");
         t.setDaemon(true);
         t.start();
      }
   }

   private static void report() {
      StringBuilder sb = new StringBuilder("profile(5s):");
      STATS.entrySet().stream().sorted((a, b) -> Long.compare(b.getValue().max, a.getValue().max)).forEach(e -> {
         HookProfiler.Stat s = e.getValue();
         if (s.calls != 0L) {
            sb.append(String.format(" %s[n=%d avg=%.0fus max=%.0fus]", e.getKey(), s.calls, s.total / 1000.0 / s.calls, s.max / 1000.0));
            s.calls = 0L;
            s.total = 0L;
            s.max = 0L;
         }
      });
      CoreLog.info(sb.toString());
   }

   private static final class Stat {
      long calls;
      long total;
      long max;
   }
}

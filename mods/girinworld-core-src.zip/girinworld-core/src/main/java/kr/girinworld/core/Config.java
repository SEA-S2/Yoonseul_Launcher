package kr.girinworld.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Config {
   public static final int CURRENT_VERSION = 4;
   public int version = 4;
   private transient boolean migrated;
   public Config.Keys keys = new Config.Keys();
   public Config.Timer timer = new Config.Timer();
   public Config.Calc calc = new Config.Calc();
   public Config.Photo photo = new Config.Photo();
   public Config.Modules modules = new Config.Modules();
   public Config.Brightness brightness = new Config.Brightness();
   public Config.Font font = new Config.Font();
   public Config.Hud hud = new Config.Hud();
   public Config.Fishing fishing = new Config.Fishing();
   public Config.Chat chat = new Config.Chat();
   public Config.Macro macro = new Config.Macro();
   public Config.Time time = new Config.Time();
   public Config.Beam beam = new Config.Beam();
   public Config.HealthTag healthTag = new Config.HealthTag();
   public Config.Visual visual = new Config.Visual();
   public Config.Debug debug = new Config.Debug();
   private static volatile Config instance;

   public static Config get() {
      Config c = instance;
      if (c == null) {
         synchronized (Config.class) {
            c = instance;
            if (c == null) {
               c = load();
               instance = c;
            }
         }
      }

      return c;
   }

   private void migrate() {
      if (this.version < 4) {
         Config.Beam d = new Config.Beam();
         if (this.version < 2 && (this.beam.height == 3.0 || this.beam.thickness == 0.12)) {
            if (this.beam.height == 3.0) {
               this.beam.height = d.height;
            }

            if (this.beam.thickness == 0.12) {
               this.beam.thickness = d.thickness;
            }
         }

         if (this.version < 3) {
            if (this.beam.height == 2.0) {
               this.beam.height = d.height;
            }

            if (this.beam.thickness == 0.05) {
               this.beam.thickness = d.thickness;
            }
         }

         if (this.version < 4 && Double.compare(this.timer.alarmVolume, 0.25) == 0) {
            this.timer.alarmVolume = 1.0;
         }

         this.version = 4;
         this.migrated = true;
      }
   }

   static Config load() {
      Path file = CoreLog.baseDir().resolve("mod_config.json");

      try {
         if (Files.exists(file)) {
            Config c = (Config)new Gson().fromJson(Files.readString(file), Config.class);
            if (c != null) {
               c.normalize();
               CoreLog.info("config loaded from " + file);
               if (c.migrated) {
                  c.save();
                  CoreLog.info("config migrated to version 4");
               }

               return c;
            }
         }
      } catch (Throwable t) {
         CoreLog.error("config load failed, falling back to defaults", t);
      }

      CoreLog.info("config defaults in use");
      return new Config();
   }

   private void normalize() {
      if (this.keys == null) {
         this.keys = new Config.Keys();
      }

      if (this.timer == null) {
         this.timer = new Config.Timer();
      }

      if (this.calc == null) {
         this.calc = new Config.Calc();
      }

      if (this.photo == null) {
         this.photo = new Config.Photo();
      }

      if (this.modules == null) {
         this.modules = new Config.Modules();
      }

      if (this.brightness == null) {
         this.brightness = new Config.Brightness();
      }

      if (this.hud == null) {
         this.hud = new Config.Hud();
      }

      if (this.fishing == null) {
         this.fishing = new Config.Fishing();
      }

      if (this.chat == null) {
         this.chat = new Config.Chat();
      }

      if (this.macro == null) {
         this.macro = new Config.Macro();
      }

      if (this.time == null) {
         this.time = new Config.Time();
      }

      if (this.beam == null) {
         this.beam = new Config.Beam();
      }

      if (this.healthTag == null) {
         this.healthTag = new Config.HealthTag();
      }

      if (this.visual == null) {
         this.visual = new Config.Visual();
      }

      if (this.debug == null) {
         this.debug = new Config.Debug();
      }

      this.migrate();
      this.beam.normalize();
      this.font.normalize();
      this.fishing.normalize();
      this.chat.normalize();
      this.macro.normalize();
      this.time.normalize();
      this.timer.normalize();
      this.hud.normalize();
   }

   public void save() {
      Path file = CoreLog.baseDir().resolve("mod_config.json");

      try {
         Path parent = file.getParent();
         if (parent != null) {
            Files.createDirectories(parent);
         }

         Files.writeString(file, new GsonBuilder().setPrettyPrinting().create().toJson(this));
      } catch (Throwable t) {
         CoreLog.error("config save failed", t);
      }
   }

   public static void reset() {
      synchronized (Config.class) {
         instance = new Config();
         instance.save();
      }
   }

   public static final class Beam {
      public boolean enabled = false;
      public int style = 0;
      public double height = 1.7;
      public double thickness = 0.03;
      public double density = 1.0;
      public int distance = 32;
      public int maxItems = 64;
      public int colorMode = 0;
      public int color = -171;
      public int filterMode = 0;
      public String filter = "";

      void normalize() {
         this.style = Math.max(0, Math.min(1, this.style));
         this.height = clamp(this.height, 0.5, 10.0);
         this.thickness = clamp(this.thickness, 0.01, 0.5);
         this.density = clamp(this.density, 0.2, 4.0);
         this.distance = Math.max(4, Math.min(96, this.distance));
         this.maxItems = Math.max(4, Math.min(256, this.maxItems));
         this.colorMode = Math.max(0, Math.min(1, this.colorMode));
         this.filterMode = Math.max(0, Math.min(2, this.filterMode));
         if (this.filter == null) {
            this.filter = "";
         }
      }

      private static double clamp(double v, double lo, double hi) {
         return v < lo ? lo : (v > hi ? hi : v);
      }
   }

   public static final class Brightness {
      public boolean enabled = false;
      public double level = 300.0;
   }

   public static final class Calc {
      public boolean thousandsSeparator = true;
      public boolean kmbNotation = true;
   }

   public static final class Chat {
      public boolean enabled = false;
      public double width = 1.0;
      public double heightFocused = 1.0;
      public double heightUnfocused = 1.0;
      public double scale = 1.0;
      public boolean timestamp = false;
      public int timeFormat = 0;

      void normalize() {
         this.width = clampFactor(this.width);
         this.heightFocused = clampFactor(this.heightFocused);
         this.heightUnfocused = clampFactor(this.heightUnfocused);
         this.scale = clampFactor(this.scale);
         this.timeFormat = Math.max(0, Math.min(2, this.timeFormat));
      }

      private static double clampFactor(double v) {
         return v >= 0.3 && v <= 2.0 ? v : 1.0;
      }
   }

   public static final class Debug {
      public boolean profile = false;
   }

   public static final class Fishing {
      public double myBiteVolume = 1.0;

      void normalize() {
         this.myBiteVolume = clamp01(this.myBiteVolume);
      }

      private static double clamp01(double v) {
         return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v);
      }
   }

   public static final class Font {
      public boolean enabled = false;
      public Map<String, Double> scale = new LinkedHashMap<>();

      void normalize() {
         if (this.scale == null) {
            this.scale = new LinkedHashMap<>();
         } else {
            this.scale.entrySet().removeIf(e -> e.getValue() == null);
            this.scale.replaceAll((k, v) -> v < 0.5 ? 0.5 : (v > 1.5 ? 1.5 : v));
         }
      }
   }

   public static final class HealthTag {
      public boolean enabled = false;
      public int target = 0;
      public int distance = 16;
   }

   public static final class Hud {
      public Config.Hud.Elem fps = new Config.Hud.Elem(0.0, 0.0);
      public Config.Hud.Elem ping = new Config.Hud.Elem(0.0, 0.06);
      public Config.Hud.Elem system = new Config.Hud.Elem(0.0, 0.12);
      public Config.Hud.Elem gameTime = new Config.Hud.Elem(0.5, 0.0);
      public Config.Hud.Elem clock = new Config.Hud.Elem(0.5, 0.04);
      public Config.Hud.Elem potion = new Config.Hud.Elem(1.0, 0.06);
      public Config.Hud.Elem armor = new Config.Hud.Elem(0.31, 0.86);
      public Config.Hud.Elem tool = new Config.Hud.Elem(0.69, 0.88);
      public Config.Hud.Speed speed = new Config.Hud.Speed(0.85, 0.86);
      public Config.Hud.Elem inventory = new Config.Hud.Elem(0.5, 0.84);
      public Config.Hud.Elem slots = new Config.Hud.Elem(0.42, 0.66);
      public Config.Hud.Elem itemName = new Config.Hud.Elem(0.5, 0.6);
      public boolean invHoldOnly = false;
      public Config.Hud.Held heldCount = new Config.Hud.Held(0.5, 0.56);
      public Config.Hud.Keystrokes keystrokes = new Config.Hud.Keystrokes(0.16, 0.86);

      void normalize() {
         Config.Hud d = new Config.Hud();
         if (this.fps == null) {
            this.fps = d.fps;
         }

         if (this.clock == null) {
            this.clock = d.clock;
         }

         if (this.gameTime == null) {
            this.gameTime = d.gameTime;
         }

         if (this.ping == null) {
            this.ping = d.ping;
         }

         if (this.armor == null) {
            this.armor = d.armor;
         }

         if (this.tool == null) {
            this.tool = d.tool;
         }

         if (this.system == null) {
            this.system = d.system;
         }

         if (this.potion == null) {
            this.potion = d.potion;
         }

         if (this.speed == null) {
            this.speed = d.speed;
         }

         if (this.inventory == null) {
            this.inventory = d.inventory;
         }

         if (this.slots == null) {
            this.slots = d.slots;
         }

         if (this.itemName == null) {
            this.itemName = d.itemName;
         }

         this.itemName.normalize();
         if (this.heldCount == null) {
            this.heldCount = d.heldCount;
         }

         if (this.keystrokes == null) {
            this.keystrokes = d.keystrokes;
         }

         this.fps.normalize();
         this.clock.normalize();
         this.gameTime.normalize();
         this.ping.normalize();
         this.armor.normalize();
         this.tool.normalize();
         this.system.normalize();
         this.potion.normalize();
         this.inventory.normalize();
         this.slots.normalize();
         this.speed.normalize();
         this.speed.decimals = Math.max(0, Math.min(2, this.speed.decimals));
         this.speed.unit = Math.max(0, Math.min(1, this.speed.unit));
         this.heldCount.normalize();
         this.heldCount.preset = Math.max(0, Math.min(2, this.heldCount.preset));
         this.keystrokes.normalize();
      }

      public static class Elem {
         public boolean enabled = false;
         public double x = 0.0;
         public double y = 0.0;
         public double opacity = 1.0;
         public boolean bgEnabled = true;
         public double bgOpacity = 0.35;
         public double scale = 1.0;
         public boolean horizontal = false;

         public Elem() {
         }

         Elem(double x, double y) {
            this.x = x;
            this.y = y;
         }

         void normalize() {
            this.x = Math.max(0.0, Math.min(1.0, this.x));
            this.y = Math.max(0.0, Math.min(1.0, this.y));
            if (!(this.opacity >= 0.1) || !(this.opacity <= 1.0)) {
               this.opacity = 1.0;
            }

            if (!(this.bgOpacity >= 0.0) || !(this.bgOpacity <= 1.0)) {
               this.bgOpacity = 0.35;
            }

            if (!(this.scale >= 0.5) || !(this.scale <= 3.0)) {
               this.scale = 1.0;
            }
         }
      }

      public static final class Held extends Config.Hud.Elem {
         public boolean showDelta = true;
         public int preset = 1;

         public Held() {
         }

         Held(double x, double y) {
            super(x, y);
         }
      }

      public static final class Keystrokes extends Config.Hud.Elem {
         public boolean wasd = true;
         public boolean mouse = true;
         public boolean cps = true;
         public boolean space = true;
         public boolean sneak = true;
         public boolean sprint = true;
         public int bgColor = -16777216;
         public int pressColor = -1;
         public int textColor = -1;

         public Keystrokes() {
         }

         Keystrokes(double x, double y) {
            super(x, y);
         }
      }

      public static final class Speed extends Config.Hud.Elem {
         public int unit;
         public int decimals = 1;
         public boolean showUnit = true;

         public Speed() {
         }

         Speed(double x, double y) {
            super(x, y);
         }
      }
   }

   public static final class Keys {
      public String quickmenu = "key.keyboard.c";
      public String settings = "key.keyboard.right.shift";
      public String photoToggle = "key.keyboard.unknown";
      public String calc = "key.keyboard.unknown";
      public String timer = "key.keyboard.unknown";
      public String whisper = "key.keyboard.unknown";
      public String zoom = "key.keyboard.z";
      public String gridlines = "key.keyboard.g";
      public String autoSprint = "key.keyboard.unknown";
      public String brightness = "key.keyboard.unknown";
      public String invHold = "key.keyboard.unknown";
      public String timePreset = "key.keyboard.unknown";
      public String macro = "key.keyboard.unknown";
      public String timerRecent = "key.keyboard.unknown";
   }

   public static final class Macro {
      public List<Config.Macro.Entry> list = new ArrayList<>();

      void normalize() {
         if (this.list == null) {
            this.list = new ArrayList<>();
         } else {
            this.list.removeIf(ex -> ex == null || ex.text == null || ex.text.isBlank());

            for (Config.Macro.Entry e : this.list) {
               if (e.name == null) {
                  e.name = "";
               }

               if (e.key == null) {
                  e.key = "";
               }
            }
         }
      }

      public static final class Entry {
         public String name = "";
         public String text = "";
         public String key = "";
         public int mods = 0;
      }
   }

   public static final class Modules {
      public boolean zoom = true;
      public boolean fishing = true;
      public boolean quickCalc = true;
      public boolean quickTimer = true;
      public boolean quickWhisper = true;
      public boolean quickCamera = true;
   }

   public static final class Photo {
      public double zoomFov = 30.0;
      public boolean smoothFollow = true;
      public boolean hideHud = true;
      public boolean gridlinesDefault = false;
   }

   public static final class Time {
      public boolean enabled = false;
      public int mode = 0;
      public int fixed = 6000;

      void normalize() {
         this.mode = Math.max(0, Math.min(1, this.mode));
         this.fixed = Math.floorMod(this.fixed, 24000);
      }
   }

   public static final class Timer {
      public String hudCorner = "TOP_RIGHT";
      public boolean sound = true;
      public String soundId = "block.note_block.bell";
      public int alarmSeconds = 5;
      public double alarmVolume = 1.0;
      public boolean hudEnabled = true;
      public double hudOpacity = 1.0;
      public double hudScale = 1.0;
      public double hudX = 1.0;
      public double hudY = 0.0;
      public List<Config.Timer.Recent> recents = new ArrayList<>();

      void normalize() {
         this.alarmSeconds = Math.max(1, Math.min(60, this.alarmSeconds));
         this.alarmVolume = Math.max(0.0, Math.min(1.0, this.alarmVolume));
         if (this.recents == null) this.recents = new ArrayList<>();
      }

      public static final class Recent {
         public String name = "";
         public long seconds = 0L;
         public int color = 16777215;
         public boolean countdown = true;
      }
   }

   public static final class Visual {
      public boolean noDarkness = false;
      public boolean enchantColors = false;
      public boolean advancementDetails = true;
   }
}

package kr.girinworld.core.features.camera;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

public final class GridlinesHud {
   private static final int LINE_COLOR = 1627389951;

   private GridlinesHud() {
   }

   public static void render(GuiGraphicsExtractor graphics) {
      if (PhotoModeController.isActive() && PhotoModeController.isGridlines()) {
         Minecraft mc = Minecraft.getInstance();
         if (mc != null) {
            int w = mc.getWindow().getGuiScaledWidth();
            int h = mc.getWindow().getGuiScaledHeight();
            int x1 = w / 3;
            int x2 = 2 * w / 3;
            int y1 = h / 3;
            int y2 = 2 * h / 3;
            graphics.fill(x1, 0, x1 + 1, h, 1627389951);
            graphics.fill(x2, 0, x2 + 1, h, 1627389951);
            graphics.fill(0, y1, w, y1 + 1, 1627389951);
            graphics.fill(0, y2, w, y2 + 1, 1627389951);
         }
      }
   }
}

package kr.girinworld.core.features.whisper;

import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

public final class WhisperScreen extends CoreScreen {
   private static final int GAP = 6;
   private static final int MAX_ROWS = 7;
   private static final int ROW_H = 19;
   private static final int NAME_COLOR = -12635614;
   private static final int PREVIEW_COLOR = -8754611;
   private static final int TIME_COLOR = -6517911;
   private static final int BADGE_BG = -4701140;
   private static final int BADGE_FG = -201749;
   private static final int INCOMING_COLOR = -12635614;
   private static final int OUTGOING_COLOR = -15179867;
   private static final int SYSTEM_COLOR = -6517911;
   private static final int SELECT_BG = 867714092;
   private static final int GLFW_KEY_ENTER = 257;
   private static final int GLFW_KEY_KP_ENTER = 335;
   private final Screen parent;
   private final List<WhisperStore.Conversation> rows = new ArrayList<>();
   private String selectedKey;
   private EditBox newNick;
   private EditBox msgInput;
   private int scroll;
   private int leftX;
   private int rightX;
   private int bookY;
   private int rowsTop;
   private int logTop;
   private int logBottom;

   public WhisperScreen(Screen parent) {
      super(Component.literal("귓속말"));
      this.parent = parent;
   }

   protected void init() {
      int totalW = 390;
      this.leftX = this.width / 2 - totalW / 2;
      this.rightX = this.leftX + 192 + 6;
      int clusterTop = Math.max(2, (this.height - 240) / 2);
      int backY = clusterTop;
      this.bookY = clusterTop + 20;
      this.rowsTop = this.bookY + 24;
      this.logTop = this.bookY + 24;
      this.logBottom = this.bookY + 166;
      int barY = this.bookY + 192 + 6;
      this.addRenderableWidget(Button.builder(Component.literal("닫기"), b -> this.back()).bounds(this.leftX, backY, 70, 16).build());
      this.newNick = new EditBox(this.font, this.leftX, barY, 192, 16, Component.literal("새 귓속말"));
      this.newNick.setMaxLength(32);
      this.newNick.setHint(Component.literal("닉네임 입력 후 Enter"));
      this.addRenderableWidget(this.newNick);
      int sendW = 44;
      this.msgInput = new EditBox(this.font, this.rightX, barY, 192 - sendW - 4, 16, Component.literal("메시지"));
      this.msgInput.setMaxLength(100);
      this.msgInput.setHint(Component.literal("메시지 입력…"));
      this.addRenderableWidget(this.msgInput);
      this.addRenderableWidget(Button.builder(Component.literal("전송"), b -> this.send()).bounds(this.rightX + 192 - sendW, barY, sendW, 16).build());
      this.refreshRows();
      if (this.selectedKey != null) {
         WhisperService.setOpen(this.selectedKey);
      }
   }

   private void refreshRows() {
      this.rows.clear();
      List<WhisperStore.Conversation> recent = WhisperService.store().recent();

      for (int i = 0; i < recent.size() && i < 7; i++) {
         this.rows.add(recent.get(i));
      }
   }

   private void back() {
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), this.parent);
   }

   private void select(String key) {
      this.selectedKey = key;
      this.scroll = 0;
      WhisperService.setOpen(key);
   }

   private void openNick() {
      String nick = this.newNick.getValue().strip();
      if (!nick.isEmpty() && WhisperService.sendable(nick)) {
         String key = WhisperService.canonicalKey(nick);
         WhisperService.store().getOrCreate(key, key);
         this.newNick.setValue("");
         this.refreshRows();
         this.select(key);
         this.setFocused(this.msgInput);
      }
   }

   private void send() {
      if (this.selectedKey != null) {
         WhisperService.send(this.selectedKey, this.msgInput.getValue());
         this.msgInput.setValue("");
      }
   }

   private void followMerge() {
      if (this.selectedKey != null) {
         String resolved = WhisperService.resolveKey(this.selectedKey);
         if (!resolved.equals(this.selectedKey) && WhisperService.store().get(resolved) != null) {
            this.selectedKey = resolved;
            WhisperService.setOpen(this.selectedKey);
         }
      }
   }

   public boolean mouseClicked(MouseButtonEvent event, boolean doubled) {
      if (event.button() == 0) {
         int idx = this.rowAt(event.x(), event.y());
         if (idx >= 0) {
            this.select(this.rows.get(idx).key);
            this.setFocused(this.msgInput);
            return true;
         }
      }

      return super.mouseClicked(event, doubled);
   }

   private int rowAt(double mx, double my) {
      int left = this.leftX + 34;
      int right = left + 112;
      if (!(mx < left) && !(mx > right)) {
         for (int i = 0; i < this.rows.size(); i++) {
            int y = this.rowsTop + i * 19;
            if (my >= y && my < y + 19) {
               return i;
            }
         }

         return -1;
      } else {
         return -1;
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (scrollY > 0.0) {
         this.scroll++;
      } else if (scrollY < 0.0) {
         this.scroll = Math.max(0, this.scroll - 1);
      }

      return true;
   }

   public boolean keyPressed(KeyEvent event) {
      int key = event.key();
      if (key == 257 || key == 335) {
         if (this.getFocused() == this.newNick) {
            this.openNick();
            return true;
         }

         if (this.getFocused() == this.msgInput) {
            this.send();
            return true;
         }
      }

      return super.keyPressed(event);
   }

   public void onClose() {
      this.back();
   }

   public void removed() {
      if (this.selectedKey != null) {
         WhisperService.clearOpen(this.selectedKey);
      }

      super.removed();
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      WhisperBook.drawAt(graphics, this.leftX, this.bookY);
      WhisperBook.drawAt(graphics, this.rightX, this.bookY);
      super.extractRenderState(graphics, mouseX, mouseY, partialTick);
      this.followMerge();
      this.refreshRows();
      if (this.selectedKey != null) {
         WhisperService.store().clearUnread(this.selectedKey);
      }

      Font f = this.font;
      this.renderList(graphics, f);
      this.renderChat(graphics, f);
   }

   private void renderList(GuiGraphicsExtractor graphics, Font f) {
      int left = this.leftX + 34;
      int right = left + 112;
      String title = "귓속말";
      graphics.text(f, title, this.leftX + 96 - f.width(title) / 2, this.bookY + 12, -12635614, false);
      if (this.rows.isEmpty()) {
         String empty = "대화 없음";
         graphics.text(f, empty, this.leftX + 96 - f.width(empty) / 2, this.rowsTop + 20, -8754611, false);
      } else {
         for (int i = 0; i < this.rows.size(); i++) {
            WhisperStore.Conversation c = this.rows.get(i);
            int y = this.rowsTop + i * 19;
            if (c.key.equals(this.selectedKey)) {
               graphics.fill(left - 2, y - 2, right + 2, y + 19 - 3, 867714092);
            }

            String name = WhisperBook.trimToWidth(f, c.displayName, 90);
            graphics.text(f, name, left, y, -12635614, false);
            if (c.unread > 0) {
               String badge = String.valueOf(c.unread);
               int bw = f.width(badge) + 6;
               int bx = right - bw;
               graphics.fill(bx, y - 1, bx + bw, y + 9, -4701140);
               graphics.text(f, badge, bx + 3, y, -201749, false);
            } else {
               WhisperMessage last = c.last();
               if (last != null) {
                  String time = WhisperBook.hhmm(last.timeMillis());
                  graphics.text(f, time, right - f.width(time), y, -6517911, false);
               }
            }

            WhisperMessage last = c.last();
            if (last != null) {
               String preview = WhisperBook.trimToWidth(f, last.text(), 112);
               graphics.text(f, preview, left, y + 9, -8754611, false);
            }
         }
      }
   }

   private void renderChat(GuiGraphicsExtractor graphics, Font f) {
      WhisperStore.Conversation c = this.selectedKey != null ? WhisperService.store().get(this.selectedKey) : null;
      String header = c != null ? c.displayName : (this.selectedKey != null ? this.selectedKey : "대화 선택");
      graphics.text(f, header, this.rightX + 96 - f.width(header) / 2, this.bookY + 12, -12635614, false);
      if (this.selectedKey == null) {
         String hint = "왼쪽에서 대화를 선택하세요";
         hint = WhisperBook.trimToWidth(f, hint, 112);
         graphics.text(f, hint, this.rightX + 96 - f.width(hint) / 2, this.logTop + 30, -8754611, false);
      } else {
         List<WhisperScreen.Line> lines = c != null ? this.buildLines(f, c) : List.of();
         this.renderLog(graphics, f, lines);
      }
   }

   private List<WhisperScreen.Line> buildLines(Font f, WhisperStore.Conversation c) {
      List<WhisperScreen.Line> out = new ArrayList<>();

      for (WhisperMessage m : c.messages) {
         int color;
         int align;
         String body;
         switch (m.direction()) {
            case INCOMING:
               color = -12635614;
               align = 0;
               body = m.text() + "  " + WhisperBook.hhmm(m.timeMillis());
               break;
            case OUTGOING:
               color = -15179867;
               align = 1;
               body = WhisperBook.hhmm(m.timeMillis()) + "  " + m.text();
               break;
            default:
               color = -6517911;
               align = 2;
               body = m.text();
         }

         for (FormattedCharSequence seq : f.split(Component.literal(body), 112)) {
            out.add(new WhisperScreen.Line(seq, f.width(seq), color, align));
         }
      }

      return out;
   }

   private void renderLog(GuiGraphicsExtractor graphics, Font f, List<WhisperScreen.Line> lines) {
      int left = this.rightX + 34;
      int right = left + 112;
      int lineH = 9 + 1;
      int visible = Math.max(1, (this.logBottom - this.logTop) / lineH);
      int maxScroll = Math.max(0, lines.size() - visible);
      if (this.scroll > maxScroll) {
         this.scroll = maxScroll;
      }

      int firstShown = Math.max(0, lines.size() - visible - this.scroll);
      int lastShown = Math.min(lines.size(), firstShown + visible);
      int y = this.logTop;

      for (int i = firstShown; i < lastShown; i++) {
         WhisperScreen.Line ln = lines.get(i);

         int x = switch (ln.align()) {
            case 1 -> right - ln.width();
            case 2 -> left + (112 - ln.width()) / 2;
            default -> left;
         };
         graphics.text(f, ln.seq(), x, y, ln.color(), false);
         y += lineH;
      }
   }

   private record Line(FormattedCharSequence seq, int width, int color, int align) {
   }
}

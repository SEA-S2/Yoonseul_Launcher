package kr.girinworld.core.features.macro;

import com.mojang.blaze3d.platform.InputConstants.Key;
import com.mojang.blaze3d.platform.InputConstants.Type;
import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.KeyBindings;
import kr.girinworld.core.KeyMods;
import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

public final class MacroEditScreen extends CoreScreen {
   private static final int PANEL_W = 280;
   private static final int GLFW_ESCAPE = 256;
   private static final int GLFW_DELETE = 261;
   private static final int GLFW_BACKSPACE = 259;
   private final Screen parent;
   private final int index;
   private EditBox nameBox;
   private EditBox textBox;
   private Button keyButton;
   private String key;
   private int mods;
   private boolean awaitKey;
   private String conflict;
   private int left;
   private int titleY;
   private int nameLabelY;
   private int textLabelY;
   private int keyLabelY;
   private int hintY;

   public MacroEditScreen(Screen parent, int index) {
      super(Component.literal(index < 0 ? "단축어 추가" : "단축어 편집"));
      this.parent = parent;
      this.index = index;
      Config.Macro.Entry e = this.entry();
      this.key = e == null ? "" : e.key;
      this.mods = e == null ? 0 : e.mods;
   }

   private Config.Macro.Entry entry() {
      List<Config.Macro.Entry> list = MacroController.list();
      return this.index >= 0 && this.index < list.size() ? list.get(this.index) : null;
   }

   protected void init() {
      this.left = this.width / 2 - 140;
      int y = this.height / 2 - 90;
      this.titleY = y;
      y += 16;
      this.nameLabelY = y;
      y += 11;
      int nameY = y;
      y += 26;
      this.textLabelY = y;
      y += 11;
      int textY = y;
      y += 26;
      this.keyLabelY = y;
      y += 11;
      int keyY = y;
      y += 26;
      this.hintY = y;
      y += 16;
      int btnY = y;
      Config.Macro.Entry e = this.entry();
      this.nameBox = new EditBox(this.font, this.left, nameY, 280, 20, Component.literal(""));
      this.nameBox.setMaxLength(16);
      this.textBox = new EditBox(this.font, this.left, textY, 280, 20, Component.literal(""));
      this.textBox.setMaxLength(256);
      if (e != null) {
         this.nameBox.setValue(e.name);
         this.textBox.setValue(e.text);
      }

      this.addRenderableWidget(this.nameBox);
      this.addRenderableWidget(this.textBox);
      this.setInitialFocus(this.textBox);
      this.keyButton = Button.builder(Component.literal(this.keyLabel()), b -> {
         this.awaitKey = true;
         this.setFocused(null);
         b.setMessage(Component.literal("> 키를 누르세요 <"));
      }).bounds(this.left, keyY, 280, 20).build();
      this.addRenderableWidget(this.keyButton);
      int third = 88;
      this.addRenderableWidget(Button.builder(Component.literal("저장"), b -> this.save()).bounds(this.left, btnY, third, 20).build());
      Button del = Button.builder(Component.literal("삭제"), b -> this.delete()).bounds(this.left + third + 8, btnY, third, 20).build();
      del.active = this.index >= 0;
      this.addRenderableWidget(del);
      this.addRenderableWidget(Button.builder(Component.literal("취소"), b -> this.onClose()).bounds(this.left + 2 * (third + 8), btnY, third, 20).build());
      this.conflict = this.conflictOf(this.key);
   }

   private String keyLabel() {
      Key k = MacroController.parse(this.key);
      return "키: " + (k == null ? "미지정" : KeyMods.prefix(this.mods) + k.getDisplayName().getString());
   }

   private String conflictOf(String saved) {
      Key k = MacroController.parse(saved);
      if (k == null) {
         return null;
      }

      List<Config.Macro.Entry> list = MacroController.list();

      for (int i = 0; i < list.size(); i++) {
         if (i != this.index && saved.equals(list.get(i).key)) {
            String n = list.get(i).name;
            return "단축어 " + (n.isBlank() ? "#" + (i + 1) : n);
         }
      }

      return KeyBindings.conflictLabel("", k);
   }

   private void save() {
      String text = this.textBox.getValue();
      if (!MacroController.normalize(text).isEmpty()) {
         Config c = Config.get();
         Config.Macro.Entry e = this.entry();
         if (e == null) {
            if (c.macro.list.size() >= 30) {
               return;
            }

            e = new Config.Macro.Entry();
            c.macro.list.add(e);
         }

         e.name = this.nameBox.getValue().trim();
         e.text = text.trim();
         e.key = this.key;
         e.mods = this.mods;
         c.save();
         this.onClose();
      }
   }

   private void delete() {
      if (this.index >= 0 && this.index < MacroController.list().size()) {
         MacroController.list().remove(this.index);
         Config.get().save();
      }

      this.onClose();
   }

   public boolean keyPressed(KeyEvent event) {
      if (this.awaitKey) {
         int k = event.key();
         if (KeyMods.isModifierKey(k)) {
            this.mods = KeyMods.ofKey(k);
            this.keyButton.setMessage(Component.literal("> " + KeyMods.prefix(this.mods) + "? <"));
            return true;
         }

         this.awaitKey = false;
         if (k == 261 || k == 259) {
            this.key = "";
            this.mods = 0;
         } else if (k != 256) {
            this.key = Type.KEYSYM.getOrCreate(k).getName();
            this.mods = KeyMods.normalize(event.modifiers());
         } else {
            this.mods = this.entry() == null ? 0 : this.entry().mods;
         }

         this.conflict = this.conflictOf(this.key);
         this.keyButton.setMessage(Component.literal(this.keyLabel()));
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      Font f = this.font;
      String title = this.getTitle().getString();
      g.text(f, title, this.width / 2 - f.width(title) / 2, this.titleY, -1);
      g.text(f, "이름 (비우면 내용이 그대로 보입니다)", this.left, this.nameLabelY, -5592406, false);
      g.text(f, "보낼 한 줄 ( / 로 시작하면 명령 )", this.left, this.textLabelY, -5592406, false);
      g.text(f, "지정 키 (Ctrl·Shift·Alt 조합 가능 · Delete = 해제 · ESC = 취소)", this.left, this.keyLabelY, -5592406, false);
      if (this.conflict != null) {
         g.text(f, "⚠ " + this.conflict + " 와 겹칩니다", this.left, this.hintY, -21965, false);
      } else {
         g.text(f, "인게임에서 키를 누르면 그 줄이 그대로 전송됩니다", this.left, this.hintY, -10066330, false);
      }
   }

   public void onClose() {
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), this.parent);
   }
}

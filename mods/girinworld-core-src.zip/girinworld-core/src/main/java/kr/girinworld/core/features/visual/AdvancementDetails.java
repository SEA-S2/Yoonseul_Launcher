package kr.girinworld.core.features.visual;

import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import kr.girinworld.core.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.advancements.AdvancementWidget;
import net.minecraft.client.gui.screens.advancements.AdvancementsScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.joml.Vector2i;

public final class AdvancementDetails {
   private static final String[] NAME_KINDS = new String[]{"biome", "entity", "item", "block", "effect", "enchantment"};
   private static final double CLICK_SLOP = 4.0;
   private static final Map<AdvancementsScreen, Screen> OPENED_FROM = new WeakHashMap<>();
   private static final Map<AdvancementWidget, DisplayInfo> DISPLAY = new WeakHashMap<>();
   private static final Map<AdvancementWidget, AdvancementProgress> PROGRESS = new WeakHashMap<>();
   private static AdvancementWidget hovered;
   private static AdvancementWidget lastHovered;
   private static AdvancementWidget pressed;
   private static double pressX;
   private static double pressY;

   private AdvancementDetails() {
   }

   public static void onScreenCreate(AdvancementsScreen screen, Screen openedFrom) {
      OPENED_FROM.put(screen, openedFrom);
   }

   static void back(Screen previous) {
      Minecraft mc = Minecraft.getInstance();
      if (previous instanceof AdvancementsScreen old && mc.getConnection() != null) {
         kr.girinworld.core.ClientCompat.setScreen(mc, new AdvancementsScreen(mc.getConnection().getAdvancements(), OPENED_FROM.get(old)));
      } else {
         kr.girinworld.core.ClientCompat.setScreen(mc, previous);
      }
   }

   public static void onCreate(AdvancementWidget widget, DisplayInfo display) {
      DISPLAY.put(widget, display);
   }

   public static void onProgress(AdvancementWidget widget, AdvancementProgress progress) {
      PROGRESS.put(widget, progress);
   }

   public static void onHover(AdvancementWidget widget) {
      hovered = widget;
   }

   public static void onScreenRender(GuiGraphicsExtractor g, int mouseX, int mouseY) {
      lastHovered = hovered;
      hovered = null;
      AdvancementProgress p = detailable(lastHovered);
      if (p != null) {
         int done = count(p.getCompletedCriteria());
         int total = done + count(p.getRemainingCriteria());
         Component hint = Component.literal("조건 " + done + " / " + total + " · ")
            .withStyle(ChatFormatting.GOLD)
            .append(Component.literal("클릭해서 자세히").withStyle(ChatFormatting.YELLOW));
         g.setTooltipForNextFrame(
            Minecraft.getInstance().font,
            List.of(hint.getVisualOrderText()),
            (sw, sh, x, y, tw, th) -> new Vector2i(x < sw / 2 ? sw - tw - 8 : 8, sh - th - 8),
            mouseX,
            mouseY,
            false
         );
      }
   }

   public static boolean onMouseClicked(boolean handled, MouseButtonEvent e) {
      pressed = e.button() == 0 ? lastHovered : null;
      pressX = e.x();
      pressY = e.y();
      return handled;
   }

   public static boolean onMouseReleased(boolean handled, MouseButtonEvent e) {
      AdvancementWidget w = pressed;
      pressed = null;
      if (w != null && e.button() == 0 && w == lastHovered && !(Math.abs(e.x() - pressX) > 4.0) && !(Math.abs(e.y() - pressY) > 4.0)) {
         AdvancementProgress p = detailable(w);
         DisplayInfo d = DISPLAY.get(w);
         if (p != null && d != null) {
            Minecraft mc = Minecraft.getInstance();
            kr.girinworld.core.ClientCompat.setScreen(mc, new AdvancementDetailScreen(kr.girinworld.core.ClientCompat.screen(mc), d, p));
            return true;
         } else {
            return handled;
         }
      } else {
         return handled;
      }
   }

   private static AdvancementProgress detailable(AdvancementWidget w) {
      if (w != null && Config.get().visual.advancementDetails) {
         AdvancementProgress p = PROGRESS.get(w);
         return p != null && count(p.getCompletedCriteria()) + count(p.getRemainingCriteria()) > 1 ? p : null;
      } else {
         return null;
      }
   }

   private static int count(Iterable<String> it) {
      int n = 0;

      for (String ignored : it) {
         n++;
      }

      return n;
   }

   static Component displayName(String key) {
      Identifier id = Identifier.tryParse(key);
      if (id != null) {
         Language lang = Language.getInstance();
         String suffix = id.getNamespace() + "." + id.getPath().replace('/', '.');

         for (String kind : NAME_KINDS) {
            if (lang.has(kind + "." + suffix)) {
               return Component.translatable(kind + "." + suffix);
            }
         }

         if ("minecraft".equals(id.getNamespace())) {
            return Component.literal(id.getPath());
         }
      }

      return Component.literal(key);
   }
}

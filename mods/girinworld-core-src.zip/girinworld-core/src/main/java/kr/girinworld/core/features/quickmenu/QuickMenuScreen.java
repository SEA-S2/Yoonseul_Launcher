package kr.girinworld.core.features.quickmenu;

import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.Config;
import kr.girinworld.core.KeyBindings;
import kr.girinworld.core.features.CoreScreen;
import kr.girinworld.core.features.calc.CalcScreen;
import kr.girinworld.core.features.camera.CameraScreen;
import kr.girinworld.core.features.timer.TimerScreen;
import kr.girinworld.core.features.whisper.WhisperScreen;
import kr.girinworld.core.features.whisper.WhisperService;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

public final class QuickMenuScreen extends CoreScreen {
   private static final int GLFW_KEY_1 = 49;
   private static final int MAX_ENTRIES = 9;
   private static final int PER_ROW = 4;
   private static final int BTN_W = 90;
   private static final int BTN_H = 20;
   private static final int GAP = 8;
   private final List<QuickMenuScreen.Entry> entries = new ArrayList<>();
   private Button whisperBtn;
   private int gridTop;

   public QuickMenuScreen() {
      super(Component.literal("즐겨찾기"));
   }

   private void buildEntries() {
      this.entries.clear();
      Minecraft mc = Minecraft.getInstance();
      Config.Modules m = Config.get().modules;
      if (m.quickCalc) {
         this.entries.add(new QuickMenuScreen.Entry("계산기", () -> kr.girinworld.core.ClientCompat.setScreen(mc, new CalcScreen(this)), false));
      }

      if (m.quickTimer) {
         this.entries.add(new QuickMenuScreen.Entry("타이머", () -> kr.girinworld.core.ClientCompat.setScreen(mc, new TimerScreen(this)), false));
      }

      if (m.quickWhisper) {
         this.entries.add(new QuickMenuScreen.Entry("귓속말", () -> kr.girinworld.core.ClientCompat.setScreen(mc, new WhisperScreen(this)), true));
      }

      if (m.quickCamera) {
         this.entries.add(new QuickMenuScreen.Entry("프리뷰 카메라", () -> kr.girinworld.core.ClientCompat.setScreen(mc, new CameraScreen(this)), false));
      }

      if (this.entries.size() > 9) {
         this.entries.subList(9, this.entries.size()).clear();
      }
   }

   protected void init() {
      this.buildEntries();
      this.whisperBtn = null;
      this.gridTop = this.height / 2 - 10;
      if (!this.entries.isEmpty()) {
         int n = this.entries.size();
         int rows = (n + 4 - 1) / 4;
         this.gridTop = this.height / 2 - (rows * 20 + (rows - 1) * 8) / 2;

         for (int i = 0; i < n; i++) {
            QuickMenuScreen.Entry e = this.entries.get(i);
            int row = i / 4;
            int col = i % 4;
            int inRow = Math.min(4, n - row * 4);
            int left = this.width / 2 - (inRow * 90 + (inRow - 1) * 8) / 2;
            Button b = Button.builder(Component.literal(e.label()), btn -> e.action().run()).bounds(left + col * 98, this.gridTop + row * 28, 90, 20).build();
            this.addRenderableWidget(b);
            if (e.isWhisper()) {
               this.whisperBtn = b;
            }
         }
      }
   }

   public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(graphics, mouseX, mouseY, partialTick);
      Font font = this.font;
      String title = this.getTitle().getString();
      graphics.text(font, title, this.width / 2 - font.width(title) / 2, this.gridTop - 24, -1);
      if (this.entries.isEmpty()) {
         String hint = "즐겨찾기 항목이 없습니다 — RShift 클라이언트 허브에서 추가하세요";
         graphics.text(font, hint, this.width / 2 - font.width(hint) / 2, this.gridTop + 6, -5197648);
      } else {
         int unread = WhisperService.store().totalUnread();
         if (unread > 0 && this.whisperBtn != null) {
            String num = String.valueOf(unread);
            int bw = font.width(num) + 6;
            int bx = this.whisperBtn.getX() + this.whisperBtn.getWidth() - bw - 2;
            int by = this.whisperBtn.getY() - 4;
            graphics.fill(bx, by, bx + bw, by + 11, -4701140);
            graphics.text(font, num, bx + 3, by + 2, -201749, false);
         }
      }
   }

   public boolean keyPressed(KeyEvent event) {
      int key = event.key();

      try {
         if (KeyBindings.matchesQuickmenu(event)) {
            this.onClose();
            return true;
         }
      } catch (Throwable var4) {
      }

      int idx = key - 49;
      if (idx >= 0 && idx < this.entries.size()) {
         this.entries.get(idx).action().run();
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   private record Entry(String label, Runnable action, boolean isWhisper) {
   }
}

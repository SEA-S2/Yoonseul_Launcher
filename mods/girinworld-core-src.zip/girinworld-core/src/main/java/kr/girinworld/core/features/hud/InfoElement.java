package kr.girinworld.core.features.hud;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import kr.girinworld.core.Config;
import kr.girinworld.core.CoreLog;
import kr.girinworld.core.features.world.ItemBeamController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public enum InfoElement {
   FPS("FPS", "hud_fps"),
   CLOCK("실시간 시계", "hud_clock"),
   GAME_TIME("인게임 시각", "hud_gametime"),
   PING("핑", "hud_ping"),
   SYSTEM("시스템", "hud_system"),
   POTION("물약 효과", "hud_potion"),
   ARMOR("장비 내구도", "hud_armor"),
   TOOL("도구 내구도", "hud_tool"),
   SPEED("이동 속도", "hud_speed"),
   HELD_COUNT("아이템 개수", "hud_held"),
   SLOTS("남은 슬롯 · 화살", "inventory"),
   ITEM_NAME("아이템 이름", "beam");

   private static final String[] ROMAN = new String[]{"", " II", " III", " IV", " V"};
   private static final DateTimeFormatter CLOCK_FMT = DateTimeFormatter.ofPattern("HH:mm");
   private static ItemStack arrowIcon;
   private final String label;
   private final String moduleId;
   private static final Map<InfoElement, List<HudRow>> PLACEHOLDERS = new EnumMap<>(InfoElement.class);
   private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
   private static long armorDiagAt;

   private static ItemStack arrowIcon() {
      if (arrowIcon == null) {
         arrowIcon = new ItemStack(Items.ARROW);
      }

      return arrowIcon;
   }

   InfoElement(String label, String moduleId) {
      this.label = label;
      this.moduleId = moduleId;
   }

   public String label() {
      return this.label;
   }

   public String moduleId() {
      return this.moduleId;
   }

   public boolean supportsLayout() {
      return this == ARMOR || this == TOOL;
   }

   public boolean horizontal() {
      return this == SLOTS || this.supportsLayout() && this.cfg().horizontal;
   }

   public boolean iconBased() {
      return this == ARMOR || this == TOOL || this == SLOTS || this == HELD_COUNT || this == ITEM_NAME;
   }

   List<HudRow> placeholderRows() {
      return PLACEHOLDERS.computeIfAbsent(this, InfoElement::buildPlaceholder);
   }

   private static List<HudRow> buildPlaceholder(InfoElement e) {
      return switch (e) {
         case ARMOR -> List.of(
            new HudRow(new ItemStack(Items.IRON_HELMET), "165"),
            new HudRow(new ItemStack(Items.IRON_CHESTPLATE), "528"),
            new HudRow(new ItemStack(Items.IRON_LEGGINGS), "105"),
            new HudRow(new ItemStack(Items.IRON_BOOTS), "481")
         );
         case TOOL -> List.of(new HudRow(new ItemStack(Items.IRON_SWORD), "59"), new HudRow(new ItemStack(Items.IRON_PICKAXE), "131"));
         default -> List.of(HudRow.of(e.label()));
         case HELD_COUNT -> List.of(new HudRow(new ItemStack(Items.COBBLESTONE), "64"));
         case ITEM_NAME -> List.of(new HudRow(new ItemStack(Items.DIAMOND), "다이아몬드 ×3"));
      };
   }

   public boolean autoStacks() {
      return this != ARMOR && this != TOOL && this != HELD_COUNT;
   }

   public Config.Hud.Elem cfg() {
      return this.cfg(Config.get().hud);
   }

   public Config.Hud.Elem cfg(Config.Hud h) {
      return switch (this) {
         case FPS -> h.fps;
         case CLOCK -> h.clock;
         case GAME_TIME -> h.gameTime;
         case PING -> h.ping;
         case SYSTEM -> h.system;
         case POTION -> h.potion;
         case ARMOR -> h.armor;
         case TOOL -> h.tool;
         case SPEED -> h.speed;
         case HELD_COUNT -> h.heldCount;
         case SLOTS -> h.slots;
         case ITEM_NAME -> h.itemName;
      };
   }

   public boolean inInventoryGroup() {
      return this == SLOTS;
   }

   public List<HudRow> rows(Minecraft mc) {
      return switch (this) {
         case FPS -> List.of(HudRow.of(mc.getFps() + " FPS"));
         case CLOCK -> List.of(HudRow.of(LocalTime.now().format(CLOCK_FMT)));
         case GAME_TIME -> gameTimeRows(mc);
         case PING -> pingRows(mc);
         case SYSTEM -> systemRows();
         case POTION -> potionRows(mc);
         case ARMOR -> armorRows(mc);
         case TOOL -> toolRows(mc);
         case SPEED -> speedRows();
         case HELD_COUNT -> heldRows(mc);
         case SLOTS -> slotRows(mc);
         case ITEM_NAME -> itemNameRows();
      };
   }

   private static List<HudRow> itemNameRows() {
      ItemEntity e = ItemBeamController.focused();
      if (e == null) {
         return List.of();
      }

      ItemStack stack = e.getItem();
      String name = stack.getHoverName().getString();
      if (stack.getCount() > 1) {
         name = name + " ×" + stack.getCount();
      }

      return List.of(new HudRow(stack, name));
   }

   private static List<HudRow> slotRows(Minecraft mc) {
      if (mc.player == null) {
         return List.of();
      }

      Inventory inv = mc.player.getInventory();
      HudRow slots = HudRow.of("빈 칸 " + InventoryHud.emptySlots(inv));
      int arrows = InventoryHud.arrows(inv);
      if (arrows <= 0) {
         return List.of(slots);
      }

      HudRow arrowRow = new HudRow(arrowIcon(), Integer.toString(arrows));
      return SLOTS.cfg().x <= 0.5 ? List.of(slots, arrowRow) : List.of(arrowRow, slots);
   }

   private static List<HudRow> speedRows() {
      Config.Hud.Speed c = Config.get().hud.speed;
      double v = SpeedTracker.blocksPerSecond();
      if (c.unit == 1) {
         v *= 3.6;
      }

      String txt = String.format("%." + Math.max(0, Math.min(2, c.decimals)) + "f", v);
      if (c.showUnit) {
         txt = txt + (c.unit == 1 ? " km/h" : " b/s");
      }

      return List.of(HudRow.of(txt));
   }

   private static List<HudRow> heldRows(Minecraft mc) {
      if (mc.player != null && HeldCountTracker.hasItem()) {
         String txt = Integer.toString(HeldCountTracker.total());
         int d = HeldCountTracker.recentDelta();
         if (d != 0) {
            txt = txt + (d > 0 ? "  +" + d : "  " + d);
         }

         return List.of(new HudRow(mc.player.getInventory().getSelectedItem(), txt));
      } else {
         return List.of();
      }
   }

   private static List<HudRow> pingRows(Minecraft mc) {
      if (mc.player != null && mc.getConnection() != null) {
         PlayerInfo info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
         return info == null ? List.of() : List.of(HudRow.of(info.getLatency() + " ms"));
      } else {
         return List.of();
      }
   }

   private static List<HudRow> systemRows() {
      List<HudRow> out = new ArrayList<>();
      out.add(HudRow.of("RAM " + SystemStats.usedMb() + "/" + SystemStats.maxMb() + "MB"));
      int cpu = SystemStats.cpuPercent();
      if (cpu >= 0) {
         out.add(HudRow.of("CPU " + cpu + "%"));
      }

      return out;
   }

   private static List<HudRow> potionRows(Minecraft mc) {
      if (mc.player == null) {
         return List.of();
      }

      List<HudRow> out = new ArrayList<>();

      for (MobEffectInstance e : mc.player.getActiveEffects()) {
         String name = ((MobEffect)e.getEffect().value()).getDisplayName().getString();
         int amp = e.getAmplifier();
         String lvl = amp >= 0 && amp < ROMAN.length ? ROMAN[amp] : " " + (amp + 1);
         String left = e.isInfiniteDuration() ? "∞" : formatTicks(e.getDuration());
         out.add(HudRow.of(name + lvl + " " + left));
      }

      return out;
   }

   private static String formatTicks(int ticks) {
      long total = Math.max(0, ticks) / 20L;
      long h = total / 3600L;
      long m = total % 3600L / 60L;
      long s = total % 60L;
      return h > 0L ? String.format("%d:%02d:%02d", h, m, s) : String.format("%d:%02d", m, s);
   }

   private static List<HudRow> gameTimeRows(Minecraft mc) {
      if (mc.level == null) {
         return List.of();
      }

      long t = Math.floorMod(mc.level.getOverworldClockTime(), 24000L);
      long hour = (t / 1000L + 6L) % 24L;
      long minute = t % 1000L * 60L / 1000L;
      boolean night = t >= 13000L && t < 23000L;
      return List.of(HudRow.of(String.format("%02d:%02d", hour, minute) + (night ? " · 밤" : " · 낮")));
   }

   private static List<HudRow> armorRows(Minecraft mc) {
      if (mc.player == null) {
         return List.of();
      }

      List<HudRow> out = new ArrayList<>();

      for (EquipmentSlot slot : ARMOR_SLOTS) {
         addDurable(out, mc.player.getItemBySlot(slot));
      }

      if (!out.isEmpty()) {
         return out;
      }

      for (int i = 0; i < 4; i++) {
         addDurable(out, menuArmor(mc.player, i));
      }

      if (out.isEmpty()) {
         diagnoseArmor(mc.player);
      }

      return out;
   }

   private static ItemStack menuArmor(Player player, int index) {
      try {
         int i = 5 + index;
         return player.inventoryMenu != null && i < player.inventoryMenu.slots.size() ? player.inventoryMenu.getSlot(i).getItem() : null;
      } catch (Throwable t) {
         return null;
      }
   }

   private static void diagnoseArmor(Player player) {
      long now = System.nanoTime();
      if (armorDiagAt == 0L || now - armorDiagAt >= 60000000000L) {
         armorDiagAt = now;
         StringBuilder sb = new StringBuilder("armor hud: nothing damageable found — equip[");

         for (EquipmentSlot slot : ARMOR_SLOTS) {
            sb.append(slot.getName()).append('=').append(describe(player.getItemBySlot(slot))).append(' ');
         }

         sb.append("] menu[");

         for (int i = 0; i < 4; i++) {
            sb.append(i).append('=').append(describe(menuArmor(player, i))).append(' ');
         }

         CoreLog.info(sb.append(']').toString());
      }
   }

   private static String describe(ItemStack s) {
      return s != null && !s.isEmpty()
         ? s.getItem() + (s.isDamageableItem() ? "(dmg " + s.getDamageValue() + "/" + s.getMaxDamage() + ")" : "(no-durability)")
         : "empty";
   }

   private static List<HudRow> toolRows(Minecraft mc) {
      if (mc.player == null) {
         return List.of();
      }

      List<HudRow> out = new ArrayList<>();
      addDurable(out, mc.player.getItemBySlot(EquipmentSlot.MAINHAND));
      addDurable(out, mc.player.getItemBySlot(EquipmentSlot.OFFHAND));
      return out;
   }

   private static void addDurable(List<HudRow> out, ItemStack stack) {
      if (stack != null && !stack.isEmpty() && stack.isDamageableItem()) {
         int max = stack.getMaxDamage();
         if (max > 0) {
            int left = Math.max(0, max - stack.getDamageValue());
            out.add(new HudRow(stack, Integer.toString(left), durabilityRgb((double)left / max)));
         }
      }
   }

   private static int durabilityRgb(double ratio) {
      if (ratio <= 0.1) {
         return 16733525;
      } else {
         return ratio <= 0.25 ? 16777045 : 16777215;
      }
   }
}

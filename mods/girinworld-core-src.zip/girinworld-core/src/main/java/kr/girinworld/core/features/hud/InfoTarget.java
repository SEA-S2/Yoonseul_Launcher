package kr.girinworld.core.features.hud;

import java.util.List;
import kr.girinworld.core.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

final class InfoTarget extends Widget {
   private final InfoElement element;

   InfoTarget(InfoElement element) {
      this.element = element;
   }

   @Override
   protected Config.Hud.Elem cfg(Config.Hud hud) {
      return this.element.cfg(hud);
   }

   @Override
   public String label() {
      return this.element.label();
   }

   @Override
   public String moduleId() {
      return this.element.moduleId();
   }

   private List<HudRow> rows() {
      return InfoHud.previewRows(this.element, Minecraft.getInstance());
   }

   private boolean horizontal() {
      return this.element.horizontal();
   }

   @Override
   public int[] size(Font font) {
      return InfoHud.contentSize(font, this.rows(), InfoHud.scaleOf(this.element.cfg()), this.horizontal());
   }

   @Override
   public void draw(GuiGraphicsExtractor graphics, Font font, int x, int y) {
      Config.Hud.Elem cfg = this.element.cfg();
      int[] size = this.size(font);
      HudUtil.background(graphics, cfg, x, y, size[0], size[1]);
      InfoHud.draw(graphics, font, this.rows(), x, y, InfoHud.scaleOf(cfg), InfoHud.alphaOf(cfg), this.horizontal());
   }
}

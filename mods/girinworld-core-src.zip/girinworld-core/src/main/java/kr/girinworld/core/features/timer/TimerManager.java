package kr.girinworld.core.features.timer;

import java.util.ArrayList;
import java.util.List;
import kr.girinworld.core.Config;

public final class TimerManager {
   public static final int MAX = 4;
   private static final int MAX_RECENTS = 8;
   private static final List<Timer> active = new ArrayList<>();

   private TimerManager() {
   }

   public static synchronized List<Timer> timers() {
      return active;
   }

   public static synchronized boolean canAdd() {
      return active.size() < 4;
   }

   public static synchronized Timer add(boolean countdown, long durationNanos, String name, int color) {
      Timer t = new Timer(countdown, durationNanos, name, color);
      if (active.size() >= 4) {
         active.remove(0);
      }

      active.add(t);
      recordRecent(name, countdown ? durationNanos / 1000000000L : 0L, color, countdown);
      return t;
   }

   public static synchronized void remove(Timer t) {
      active.remove(t);
   }

   public static synchronized void update() {
      long now = System.nanoTime();
      active.removeIf(t -> t.update(now));
   }

   public static synchronized List<Config.Timer.Recent> recents() {
      return Config.get().timer.recents;
   }

   public static synchronized boolean startRecent() {
      List<Config.Timer.Recent> list = recents();
      if (list.isEmpty()) {
         return false;
      }

      Config.Timer.Recent r = list.get(0);
      add(r.countdown, r.seconds * 1000000000L, r.name, r.color);
      return true;
   }

   private static void recordRecent(String name, long seconds, int color, boolean countdown) {
      Config c = Config.get();
      List<Config.Timer.Recent> list = c.timer.recents;
      String nm = name == null ? "" : name;
      Config.Timer.Recent existing = null;

      for (Config.Timer.Recent r : list) {
         if (r.seconds == seconds && r.countdown == countdown) {
            existing = r;
            break;
         }
      }

      if (existing != null) {
         existing.name = nm;
         existing.color = color;
         list.remove(existing);
         list.add(0, existing);
      } else {
         Config.Timer.Recent r = new Config.Timer.Recent();
         r.name = nm;
         r.seconds = seconds;
         r.color = color;
         r.countdown = countdown;
         list.add(0, r);

         while (list.size() > 8) {
            list.remove(list.size() - 1);
         }
      }

      c.save();
   }
}

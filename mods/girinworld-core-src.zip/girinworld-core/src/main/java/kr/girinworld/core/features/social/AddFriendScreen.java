package kr.girinworld.core.features.social;

import kr.girinworld.core.features.CoreScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

public final class AddFriendScreen extends CoreScreen {
   private static final int PANEL_W = 220;
   private static final int GLFW_ENTER = 257;
   private static final int GLFW_KP_ENTER = 335;
   private final Screen parent;
   private final SocialData data;
   private EditBox nameBox;
   private int left;
   private int titleY;
   private int labelY;

   public AddFriendScreen(Screen parent, SocialData data) {
      super(Component.literal("친구 추가"));
      this.parent = parent;
      this.data = data;
   }

   protected void init() {
      this.left = this.width / 2 - 110;
      int y = this.height / 2 - 40;
      this.titleY = y;
      y += 15;
      this.labelY = y;
      y += 11;
      int boxY = y;
      y += 30;
      int btnY = y;
      this.nameBox = new EditBox(this.font, this.left, boxY, 220, 20, Component.literal(""));
      this.nameBox.setMaxLength(16);
      this.addRenderableWidget(this.nameBox);
      this.setInitialFocus(this.nameBox);
      int half = 106;
      this.addRenderableWidget(Button.builder(Component.literal("친구 요청"), b -> this.submit()).bounds(this.left, btnY, half, 20).build());
      this.addRenderableWidget(Button.builder(Component.literal("취소"), b -> this.onClose()).bounds(this.left + half + 8, btnY, half, 20).build());
   }

   private void submit() {
      String name = this.nameBox.getValue().trim();
      if (!name.isEmpty()) {
         SocialClient.sendRequest(this.data, name);
      }

      this.onClose();
   }

   public boolean keyPressed(KeyEvent event) {
      if ((event.key() == 257 || event.key() == 335) && this.getFocused() == this.nameBox) {
         this.submit();
         return true;
      } else {
         return super.keyPressed(event);
      }
   }

   public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
      super.extractRenderState(g, mouseX, mouseY, partialTick);
      Font f = this.font;
      g.text(f, "친구 추가", this.left, this.titleY, -1);
      g.text(f, "마인크래프트 닉네임", this.left, this.labelY, -5592406);
   }

   public void onClose() {
      kr.girinworld.core.ClientCompat.setScreen(Minecraft.getInstance(), this.parent);
   }
}
